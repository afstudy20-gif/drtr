// Vidown - Standalone Progress Page
// Opened as a tab when user starts an HLS/DASH download. Reads jobId from
// URL hash, attaches to chrome.storage.session for live updates, and exposes
// pause/cancel controls. Survives popup close, tab focus changes — only
// closes when the user explicitly closes the tab or the download completes.

(function () {
  "use strict";

  const params = new URLSearchParams(window.location.hash.slice(1));
  const jobId = params.get("jobId");
  const filename = params.get("filename") || "video";
  const kind = params.get("kind") || "hls";

  const titleEl = document.getElementById("pg-title");
  const fnameEl = document.getElementById("pg-fname");
  const barEl = document.getElementById("pg-bar");
  const segEl = document.getElementById("pg-segments");
  const sizeEl = document.getElementById("pg-size");
  const speedEl = document.getElementById("pg-speed");
  const cancelBtn = document.getElementById("pg-cancel");
  const pauseBtn = document.getElementById("pg-pause");
  const pauseIcon = document.getElementById("pg-pause-icon");
  const playIcon = document.getElementById("pg-play-icon");
  const errorEl = document.getElementById("pg-error");
  const statusEl = document.getElementById("pg-status");

  titleEl.textContent = kind === "dash"
    ? "DASH (MPD) Video Downloader"
    : "M3U8 Video Downloader";
  fnameEl.textContent = filename;

  let paused = false;

  function formatBytes(bytes) {
    if (!bytes) return "0 B";
    if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(2) + " GB";
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + " MB";
    if (bytes >= 1024) return (bytes / 1024).toFixed(0) + " KB";
    return bytes + " B";
  }

  function setError(msg) {
    if (msg) {
      errorEl.style.display = "block";
      errorEl.textContent = "Error: " + msg;
    } else {
      errorEl.style.display = "none";
    }
  }

  function applyJobStatus(msg) {
    if (msg.status === "phase") {
      if (msg.phase === "playlist") statusEl.textContent = "Loading playlist...";
      else if (msg.phase === "init") statusEl.textContent = "Init segment...";
      else if (msg.phase === "merging") statusEl.textContent = "Merging...";
      else if (msg.phase === "transmux") statusEl.textContent = "Transmuxing TS → MP4...";
      else if (msg.phase === "audio") statusEl.textContent = "Downloading audio track...";
      else if (msg.phase === "subtitles") statusEl.textContent = "Downloading subtitles...";
      else if (msg.phase === "segments") statusEl.textContent = "Downloading...";
    } else if (msg.status === "progress") {
      const pct = msg.total > 0 ? (msg.completed / msg.total) * 100 : 0;
      barEl.style.width = pct.toFixed(2) + "%";
      segEl.textContent = `${msg.completed}/${msg.total}`;
      if (msg.phase !== "transmux") {
        sizeEl.textContent = formatBytes(msg.bytes);
        speedEl.textContent = formatBytes(msg.speed) + "/s";
      }
    } else if (msg.status === "done") {
      barEl.style.width = "100%";
      statusEl.textContent = `Done — ${msg.filename || filename}${msg.audioTrack ? " + audio" : ""}${msg.subtitleCount ? ` + ${msg.subtitleCount} subtitles` : ""}`;
      sizeEl.textContent = formatBytes(msg.bytes);
      speedEl.textContent = "";
      cancelBtn.disabled = true;
      pauseBtn.disabled = true;
      // Auto-close tab 4s after success
      setTimeout(() => window.close(), 4000);
    } else if (msg.status === "error") {
      setError(msg.error || "Unknown error");
      cancelBtn.disabled = true;
      pauseBtn.disabled = true;
    } else if (msg.status === "cancelled") {
      setError("Cancelled");
      cancelBtn.disabled = true;
      pauseBtn.disabled = true;
    } else if (msg.status === "starting") {
      statusEl.textContent = "Starting...";
    }
  }

  function attach() {
    if (!jobId) {
      setError("No jobId in URL");
      return;
    }
    const key = `hls_dl_${jobId}`;
    chrome.storage.session.get(key, (s) => {
      const msg = s?.[key];
      if (msg) applyJobStatus(msg);
    });
    chrome.storage.session.onChanged.addListener((changes) => {
      if (!changes[key]) return;
      const msg = changes[key].newValue;
      if (!msg) return;
      applyJobStatus(msg);
    });
  }

  cancelBtn.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "BG_JOB_CANCEL", jobId });
  });

  pauseBtn.addEventListener("click", () => {
    paused = !paused;
    pauseIcon.style.display = paused ? "none" : "";
    playIcon.style.display = paused ? "" : "none";
    chrome.runtime.sendMessage({ type: "BG_JOB_PAUSE", jobId, paused });
  });

  attach();
})();
