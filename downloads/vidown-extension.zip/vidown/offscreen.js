// Vidown - Offscreen Document Worker
// Runs HLS/DASH downloads independently of the popup. Messages come in via
// chrome.runtime.onMessage from the background service worker; progress is
// reported back through chrome.storage.session so any open popup can pick up
// the live state, exactly like the yt-dlp progress channel.

(function () {
  "use strict";

  const activeJobs = new Map(); // jobId -> { abort, paused }

  function postStatus(jobId, payload) {
    // Route via background — chrome.storage may not be accessible from
    // offscreen documents in all browsers (Edge restricts it).
    try {
      const p = chrome.runtime.sendMessage({
        type: "OFFSCREEN_JOB_STATUS",
        jobId,
        payload: { ...payload, ts: Date.now() },
      });
      if (p && typeof p.catch === "function") p.catch(() => {});
    } catch (e) {
      console.warn("[vidown offscreen] postStatus failed:", e);
    }
  }

  async function runHlsJob(jobId, params) {
    const ctrl = new AbortController();
    const state = { abort: ctrl, paused: false };
    activeJobs.set(jobId, state);

    postStatus(jobId, { id: jobId, status: "starting", kind: "hls" });

    try {
      const result = await window.HLSDownloader.download({
        url: params.url,
        variantUrl: params.variantUrl || null,
        concurrency: params.concurrency || 6,
        outputFormat: params.outputFormat || "auto",
        signal: ctrl.signal,
        isPaused: () => state.paused,
        onPhase: (phase) => postStatus(jobId, { id: jobId, status: "phase", phase, kind: "hls" }),
        onProgress: (p) => postStatus(jobId, {
          id: jobId,
          status: "progress",
          completed: p.completed,
          total: p.total,
          bytes: p.bytes,
          speed: p.speed,
          phase: p.phase,
          kind: "hls",
        }),
      });

      let audioTrack = null;
      try {
        postStatus(jobId, { id: jobId, status: "phase", phase: "audio", kind: "hls" });
        audioTrack = await window.HLSDownloader.downloadAudioForVariant({
          url: params.url,
          variantUrl: params.variantUrl || null,
          concurrency: params.concurrency || 6,
          signal: ctrl.signal,
          isPaused: () => state.paused,
        });
      } catch (e) {
        postStatus(jobId, {
          id: jobId,
          status: "audio-warning",
          error: e?.message || String(e),
          kind: "hls",
        });
      }

      let subtitles = [];
      try {
        postStatus(jobId, { id: jobId, status: "phase", phase: "subtitles", kind: "hls" });
        subtitles = await window.HLSDownloader.downloadSubtitles({
          url: params.url,
          variantUrl: params.variantUrl || null,
          signal: ctrl.signal,
        });
        const detected = await downloadDetectedSubtitles(params.subtitles || [], ctrl.signal);
        const seen = new Set(subtitles.map((s) => normalizeUrl(s.url)));
        for (const sub of detected) {
          const key = normalizeUrl(sub.url);
          if (!seen.has(key)) {
            seen.add(key);
            subtitles.push(sub);
          }
        }
      } catch (e) {
        postStatus(jobId, {
          id: jobId,
          status: "subtitle-warning",
          error: e?.message || String(e),
          kind: "hls",
        });
      }

      const blobUrl = URL.createObjectURL(result.blob);
      const baseName = sanitize(params.filename);
      const filename = baseName + "." + result.ext;
      chrome.runtime.sendMessage(
        { type: "DOWNLOAD", url: blobUrl, filename, saveAs: true },
        (response) => {
          setTimeout(() => URL.revokeObjectURL(blobUrl), 60000);
          if (response && response.success) {
            if (audioTrack?.blob) {
              const audioUrl = URL.createObjectURL(audioTrack.blob);
              const audioName = `${baseName}_audio.${audioTrack.ext || "ts"}`;
              chrome.runtime.sendMessage(
                { type: "DOWNLOAD", url: audioUrl, filename: audioName, saveAs: false },
                () => setTimeout(() => URL.revokeObjectURL(audioUrl), 60000)
              );
            }
            for (const sub of subtitles) {
              const subBlob = new Blob([sub.text], {
                type: sub.ext === "srt" ? "application/x-subrip" : "text/vtt",
              });
              const subUrl = URL.createObjectURL(subBlob);
              const subName = `${baseName}_sub_${sanitize(sub.safeName || sub.lang || sub.name)}.${sub.ext || "vtt"}`;
              chrome.runtime.sendMessage(
                { type: "DOWNLOAD", url: subUrl, filename: subName, saveAs: false },
                () => setTimeout(() => URL.revokeObjectURL(subUrl), 60000)
              );
            }
            postStatus(jobId, {
              id: jobId,
              status: "done",
              filename,
              bytes: result.bytes,
              segmentCount: result.segmentCount,
              audioTrack: !!audioTrack,
              subtitleCount: subtitles.length,
            });
          } else {
            postStatus(jobId, { id: jobId, status: "error", error: response?.error || "Download failed" });
          }
        }
      );
    } catch (e) {
      const msg = e?.message || String(e);
      const aborted = ctrl.signal.aborted || msg === "Cancelled";
      postStatus(jobId, { id: jobId, status: aborted ? "cancelled" : "error", error: msg });
    } finally {
      activeJobs.delete(jobId);
    }
  }

  function normalizeUrl(url) {
    try {
      const u = new URL(url);
      u.hash = "";
      return u.toString();
    } catch {
      return String(url || "");
    }
  }

  async function fetchSubtitleText(url, signal) {
    const res = await fetch(url, {
      credentials: "include",
      cache: "no-store",
      signal,
    });
    if (!res.ok) throw new Error(`Subtitle HTTP ${res.status}`);
    return await res.text();
  }

  function subtitleExt(url, text) {
    if (/\.srt(\?|#|$)/i.test(url)) return "srt";
    if (/\.ttml(\?|#|$)|\.dfxp(\?|#|$)/i.test(url)) return "ttml";
    if (/^\s*\d+\s*\r?\n\d\d:\d\d:/m.test(text || "")) return "srt";
    return "vtt";
  }

  async function downloadDetectedSubtitles(items, signal) {
    const out = [];
    const seen = new Set();
    for (const item of items || []) {
      const url = typeof item === "string" ? item : item?.url;
      if (!url || seen.has(normalizeUrl(url))) continue;
      seen.add(normalizeUrl(url));
      try {
        const text = await fetchSubtitleText(url, signal);
        const ext = subtitleExt(url, text);
        out.push({
          url,
          text,
          ext,
          safeName: sanitize((item?.quality || item?.lang || item?.name || ext).replace(/\.[a-z0-9]+$/i, "")),
          lang: item?.lang || "",
          name: item?.quality || item?.name || "subtitle",
        });
      } catch (e) {
        console.warn("[vidown offscreen] subtitle fetch failed", url, e);
      }
    }
    return out;
  }

  async function runDashJob(jobId, params) {
    const ctrl = new AbortController();
    const state = { abort: ctrl, paused: false };
    activeJobs.set(jobId, state);

    postStatus(jobId, { id: jobId, status: "starting", kind: "dash" });

    try {
      const result = await window.DASHDownloader.download({
        url: params.url,
        videoId: params.videoId || null,
        audioId: params.audioId || null,
        concurrency: params.concurrency || 6,
        signal: ctrl.signal,
        isPaused: () => state.paused,
        onPhase: (phase) => postStatus(jobId, { id: jobId, status: "phase", phase, kind: "dash" }),
        onProgress: (p) => postStatus(jobId, {
          id: jobId,
          status: "progress",
          completed: p.completed,
          total: p.total,
          bytes: p.bytes,
          speed: p.speed,
          kind: "dash",
        }),
      });

      const baseName = sanitize(params.filename);
      const filename = `${baseName}.${result.ext}`;
      const videoUrl = URL.createObjectURL(result.blob);
      chrome.runtime.sendMessage(
        { type: "DOWNLOAD", url: videoUrl, filename, saveAs: true },
        (response) => {
          setTimeout(() => URL.revokeObjectURL(videoUrl), 60000);

          if (result.multiTrack && result.audioBlob) {
            const audioUrl = URL.createObjectURL(result.audioBlob);
            chrome.runtime.sendMessage(
              { type: "DOWNLOAD", url: audioUrl, filename: `${baseName}_audio.m4a`, saveAs: false },
              () => setTimeout(() => URL.revokeObjectURL(audioUrl), 60000)
            );
          }

          if (response && response.success) {
            postStatus(jobId, {
              id: jobId,
              status: "done",
              filename,
              bytes: result.bytes,
              segmentCount: result.segmentCount,
              multiTrack: !!result.multiTrack,
            });
          } else {
            postStatus(jobId, {
              id: jobId,
              status: "error",
              error: response?.error || "Download failed"
            });
          }
        }
      );
    } catch (e) {
      const msg = e?.message || String(e);
      const aborted = ctrl.signal.aborted || msg === "Cancelled";
      postStatus(jobId, { id: jobId, status: aborted ? "cancelled" : "error", error: msg });
    } finally {
      activeJobs.delete(jobId);
    }
  }

  function sanitize(name) {
    return String(name || "video")
      .replace(/[<>:"/\\|?*\x00-\x1f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .substring(0, 200) || "video";
  }

  async function listVariants(url) {
    return await window.HLSDownloader.listVariants(url);
  }

  async function listDashReps(url) {
    return await window.DASHDownloader.listRepresentations(url);
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.target !== "offscreen") return;

    if (msg.type === "PING_OFFSCREEN") {
      sendResponse({ ok: true, ready: true });
      return true;
    }

    switch (msg.type) {
      case "HLS_LIST_VARIANTS":
        listVariants(msg.url)
          .then((v) => sendResponse({ ok: true, variants: v }))
          .catch((e) => sendResponse({ ok: false, error: e?.message || String(e) }));
        return true;

      case "DASH_LIST_REPS":
        listDashReps(msg.url)
          .then((r) => sendResponse({ ok: true, reps: r }))
          .catch((e) => sendResponse({ ok: false, error: e?.message || String(e) }));
        return true;

      case "HLS_START":
        runHlsJob(msg.jobId, msg.params);
        sendResponse({ ok: true });
        return true;

      case "DASH_START":
        runDashJob(msg.jobId, msg.params);
        sendResponse({ ok: true });
        return true;

      case "JOB_PAUSE": {
        const job = activeJobs.get(msg.jobId);
        if (job) { job.paused = !!msg.paused; sendResponse({ ok: true }); }
        else sendResponse({ ok: false, error: "No such job" });
        return true;
      }

      case "JOB_CANCEL": {
        const job = activeJobs.get(msg.jobId);
        if (job) { job.abort.abort(); sendResponse({ ok: true }); }
        else sendResponse({ ok: false, error: "No such job" });
        return true;
      }

      case "JOB_LIST":
        sendResponse({ ok: true, jobs: Array.from(activeJobs.keys()) });
        return true;
    }
  });

  // Heartbeat so the offscreen document is not torn down while jobs are
  // queued. Self-ping every 25s while jobs are active.
  setInterval(() => {
    if (activeJobs.size === 0) return;
    try {
      const p = chrome.runtime.sendMessage({ type: "OFFSCREEN_HEARTBEAT", active: activeJobs.size });
      if (p && typeof p.catch === "function") p.catch(() => {});
    } catch {}
  }, 25000);
})();
