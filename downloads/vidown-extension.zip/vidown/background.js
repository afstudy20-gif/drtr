// Vidown - Background Service Worker
// Handles network request monitoring, video storage, badge updates, and downloads

const BUILD_ID = "vimeo-features-2026-06-13";

// --- Filename enforcement for blob/redirect downloads ---
const pendingFilenames = new Map();
const pendingFilenamesByUrl = new Map();

chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  const filename =
    pendingFilenamesByUrl.get(item.url) ||
    pendingFilenamesByUrl.get(item.finalUrl) ||
    pendingFilenames.get(item.id);
  if (filename) {
    suggest({ filename, conflictAction: "uniquify" });
    return true;
  }
  return false;
});

chrome.downloads.onChanged.addListener((delta) => {
  if (
    delta.state &&
    (delta.state.current === "complete" || delta.state.current === "interrupted")
  ) {
    pendingFilenames.delete(delta.id);
  }
});

const MEDIA_PATTERNS = [
  { regex: /\.m3u8(\?|#|$)/i, type: "hls" },
  { regex: /\.mpd(\?|#|$)/i, type: "dash" },
  { regex: /\.mp4(\?|#|$)/i, type: "mp4" },
  { regex: /\.webm(\?|#|$)/i, type: "webm" },
  { regex: /\.m4v(\?|#|$)/i, type: "mp4" },
  { regex: /\.ogv(\?|#|$)/i, type: "webm" },
  { regex: /\.flv(\?|#|$)/i, type: "flv" },
  { regex: /\.f4v(\?|#|$)/i, type: "flv" },
  { regex: /\.mkv(\?|#|$)/i, type: "mkv" },
  { regex: /\.avi(\?|#|$)/i, type: "avi" },
  { regex: /\.(vtt|webvtt|srt|ttml|dfxp)(\?|#|$)/i, type: "subtitle" },
];

// CDN host patterns that serve video content directly
const CDN_PATTERNS = [
  { regex: /bilivideo\.(com|cn|net)/i, type: "mp4" },
  { regex: /akamaized\.net.*upgcxcode/i, type: "mp4" },
  { regex: /upos-[a-z]+-mirror/i, type: "mp4" },
  { regex: /\.tiktokcdn\.com\/.*video/i, type: "mp4" },
  { regex: /\.twimg\.com\/.*video/i, type: "mp4" },
  { regex: /video-weaver\..+\.hls\.ttvnw\.net/i, type: "hls" },
  { regex: /\.pstatp\.com\/.*video/i, type: "mp4" },
  // Embed-host CDNs that serve HLS manifests via /cdn/hls/<hash>/master.<ext>
  { regex: /\/cdn\/hls\/[a-f0-9]+\//i, type: "hls" },
  { regex: /\/(master|playlist|index|manifest)\.(txt|m3u8?)(\?|#|$)/i, type: "hls" },
  { regex: /\/(master|playlist|index|manifest)\.mpd(\?|#|$)/i, type: "dash" },
  // Vimeo CDNs (akamaized vods, vimeocdn) — serve progressive MP4
  { regex: /vod-progressive\.akamaized\.net.*\.mp4/i, type: "mp4" },
  { regex: /\.vimeocdn\.com.*\.mp4/i, type: "mp4" },
  { regex: /player\.vimeo\.com\/.*master\.(json|m3u8)/i, type: "hls" },
  { regex: /\/(subtitles?|captions?|tracks?)\/.*\.(vtt|srt|ttml|dfxp)(\?|#|$)/i, type: "subtitle" },
];

// URLs that should be completely ignored (not video content).
// Patterns must be SPECIFIC — anchored to known analytics paths/hosts. Loose
// substring matches (like "/track") wrongly drop legit video paths
// (e.g. /master/track-2-video.m3u8, /ads/playlist.m3u8 from real CDNs).
const BLACKLIST_PATTERNS = [
  /\/generate_204(\/|\?|$)/i,
  /\/api\/stats(\/|\?|$)/i,
  /\/log_event(\/|\?|$)/i,
  /\/ptracking(\/|\?|$)/i,
  /\/qoe(\/|\?|$)/i,
  /googlevideo\.com\/initplayback/i,
  /\.googlesyndication\./i,
  /\.doubleclick\./i,
  /\/pagead\//i,
  /^https?:\/\/[^/]*\/(analytics|telemetry|beacon|collect)(\/|\?|$)/i,
  /\/(ga|gtm)\.js$/i,
  /1x1\.gif$|\/spacer\.gif$|\/transparent\.gif$/i,
  /google-analytics\.com/i,
  /googletagmanager\.com/i,
  /scorecardresearch\.com/i,
  /\.hotjar\.com/i,
  /\.sentry\.io/i,
  /newrelic\.com|nr-data\.net/i,
  /\.segment\.(io|com)/i,
  /\.amplitude\.com/i,
  /\.mixpanel\.com/i,
  /heapanalytics\.com/i,
];

// Segment patterns - tracked to confirm streams but not shown to user
const SEGMENT_PATTERNS = [
  /\.ts(\?|#|$)/i,
  /\.aac(\?|#|$)/i,
];

function getLastErrorMessage() {
  return chrome.runtime.lastError?.message || "";
}

function normalizeError(error, fallback = "Unknown error") {
  if (!error) return fallback;
  if (typeof error === "string") return error;
  if (error.message) return error.message;
  try {
    return JSON.stringify(error);
  } catch {
    return String(error);
  }
}

function respondWithError(sendResponse, error, extra = {}) {
  sendResponse({
    success: false,
    status: "error",
    error: normalizeError(error),
    ...extra,
  });
}

// Per-tab detected videos: Map<tabId, VideoEntry[]>
const tabVideos = new Map();
// Per-tab page titles: Map<tabId, string>
const tabTitles = new Map();
// Per-tab page URLs: Map<tabId, string>
const tabUrls = new Map();
// Per-tab MSE buffer registrations: Map<tabId, Set<msId>>. Tracks whether the
// content script has reported any captured MediaSource so the popup knows to
// query for a live snapshot.
const tabMseBuffers = new Map();
// User-defined domain block list: Set<string>
const userBlockedDomains = new Set();

async function loadBlockList() {
  try {
    const result = await chrome.storage.local.get("blockedDomains");
    if (Array.isArray(result.blockedDomains)) {
      result.blockedDomains.forEach((d) => userBlockedDomains.add(d));
    }
  } catch (e) {
    console.warn("Vidown: failed to load block list", e);
  }
}

async function saveBlockList() {
  try {
    await chrome.storage.local.set({
      blockedDomains: Array.from(userBlockedDomains),
    });
  } catch (e) {
    console.warn("Vidown: failed to save block list", e);
  }
}

loadBlockList();

// --- Debug log ring buffer ---
const DEBUG_LOG_MAX = 500;
const debugLog = [];

function dlog(tag, url, extra) {
  try {
    debugLog.push({ ts: Date.now(), tag, url, extra: extra || null });
    if (debugLog.length > DEBUG_LOG_MAX) debugLog.shift();
  } catch {}
}

function getDomain(url) {
  try {
    return new URL(url).hostname;
  } catch {
    return "";
  }
}

function isUserBlocked(url) {
  if (userBlockedDomains.size === 0) return false;
  const host = getDomain(url);
  if (!host) return false;
  for (const d of userBlockedDomains) {
    if (host === d || host.endsWith("." + d)) return true;
  }
  return false;
}

// --- Storage persistence ---

async function saveToStorage() {
  const data = {};
  for (const [tabId, videos] of tabVideos) {
    data[tabId] = videos;
  }
  try {
    await chrome.storage.session.set({ tabVideos: data });
  } catch (e) {
    console.warn("Vidown: failed to save session storage", e);
  }
}

async function restoreFromStorage() {
  try {
    const result = await chrome.storage.session.get("tabVideos");
    if (result.tabVideos) {
      for (const [tabId, videos] of Object.entries(result.tabVideos)) {
        tabVideos.set(Number(tabId), videos);
      }
    }
  } catch (e) {
    console.warn("Vidown: failed to restore session storage", e);
  }
}

// Restore on startup
restoreFromStorage();

// --- URL checks ---

function isBlacklisted(url) {
  if (BLACKLIST_PATTERNS.some((r) => r.test(url))) return true;
  if (isUserBlocked(url)) return true;
  return false;
}

function isSegment(url) {
  return SEGMENT_PATTERNS.some((r) => r.test(url));
}

// YouTube SABR streaming segments are not directly downloadable
// They return tiny chunks (~31KB) instead of full video
function isYouTubeSegment(url) {
  if (!/googlevideo\.com\/videoplayback/i.test(url)) return false;
  // SABR segments have sabr=1 or alr=yes or rn= (range number)
  return /[?&](sabr=1|alr=yes|rn=\d)/i.test(url);
}

// --- URL normalization for dedup ---

function normalizeUrl(url) {
  try {
    const u = new URL(url);
    // Remove common tracking/cache-busting params
    for (const p of ["_", "t", "cb", "rnd", "cpn", "cver", "rn", "alr"]) {
      u.searchParams.delete(p);
    }
    return u.origin + u.pathname + (u.search || "");
  } catch {
    return url;
  }
}

// Stronger dedup for YouTube videoplayback: normalize by removing volatile params
function normalizeYouTubeUrl(url) {
  try {
    const u = new URL(url);
    if (!/googlevideo\.com/i.test(u.hostname)) return normalizeUrl(url);
    // Keep only the params that identify the stream (id, itag, source)
    const id = u.searchParams.get("id") || "";
    const itag = u.searchParams.get("itag") || "";
    const mime = u.searchParams.get("mime") || "";
    return `${u.origin}${u.pathname}?id=${id}&itag=${itag}&mime=${mime}`;
  } catch {
    return normalizeUrl(url);
  }
}

function getMimeParamType(url) {
  try {
    const mime = (new URL(url).searchParams.get("mime") || "").toLowerCase();
    if (mime.startsWith("audio/")) return "audio";
    if (mime.includes("video/mp4")) return "mp4";
    if (mime.includes("video/webm")) return "webm";
    if (mime.startsWith("video/")) return "video";
  } catch {}
  return null;
}

function isLikelyAudioUrl(url) {
  try {
    const u = new URL(url);
    const text = `${u.pathname} ${u.searchParams.get("mime") || ""} ${u.searchParams.get("codecs") || ""}`.toLowerCase();
    return /(^|[/?_.=&-])(audio|aac|m4a|mp3|mp4a|opus|vorbis)([/?_.=&-]|$)/i.test(text)
      || /(^|[/?_.=&-])a\d{1,3}([/?_.=&-]|$)/i.test(text);
  } catch {
    return /(^|[/?_.=&-])(audio|aac|m4a|mp3|mp4a|opus|vorbis)([/?_.=&-]|$)/i.test(String(url).toLowerCase());
  }
}

// --- Classify URL ---

// Manifest keyword patterns: many sites serve m3u8 from tokenized endpoints
// without `.m3u8` in the URL (e.g. /playlist?token=..., /hls/master/abc).
// These hint at HLS/DASH but are confirmed via content-type in headers.
const MANIFEST_HINT_PATTERNS = [
  { regex: /\/(playlist|master|manifest|index)(\.m3u8|\.mpd)?(\?|$)/i, type: "hls" },
  { regex: /\/hls\//i, type: "hls" },
  { regex: /\/dash\//i, type: "dash" },
];

function classifyUrl(url) {
  if (isBlacklisted(url)) return null;

  const mimeType = getMimeParamType(url);
  if (mimeType) {
    return {
      type: mimeType,
      downloadable: ["mp4", "webm", "video", "audio"].includes(mimeType),
    };
  }

  if (isLikelyAudioUrl(url)) {
    return { type: "audio", downloadable: true };
  }

  for (const p of MEDIA_PATTERNS) {
    if (p.regex.test(url)) {
      return {
        type: p.type,
        downloadable: ["mp4", "webm", "mkv", "avi", "flv", "subtitle"].includes(p.type),
      };
    }
  }
  // Check CDN host patterns
  for (const cdn of CDN_PATTERNS) {
    if (cdn.regex.test(url)) {
      if (/\.m4s(\?|#|$)/i.test(url)) return null; // segment
      return {
        type: cdn.type,
        downloadable: ["mp4", "webm", "subtitle"].includes(cdn.type),
      };
    }
  }
  return null;
}

// JW Player analytics pings carry the manifest URL in `mu=` query param.
// e.g. https://prd.jwpltx.com/v1/jwplayer6/ping.gif?...&mu=<encoded-manifest>
function extractManifestFromJwPing(url) {
  try {
    if (!/jwpltx\.com\/.+ping\.gif/i.test(url)) return null;
    const u = new URL(url);
    const mu = u.searchParams.get("mu");
    if (!mu) return null;
    const manifestUrl = decodeURIComponent(mu);
    if (!/^https?:\/\//i.test(manifestUrl)) return null;
    let type = "hls";
    if (/\.mpd(\?|#|$)/i.test(manifestUrl)) type = "dash";
    else if (/\.(mp4|webm)(\?|#|$)/i.test(manifestUrl)) type = "mp4";
    return { url: manifestUrl, type };
  } catch {
    return null;
  }
}

// --- Add video to tab list ---

function addVideo(tabId, entry) {
  if (!tabId || tabId < 0) return;
  if (isBlacklisted(entry.url)) return;

  let videos = tabVideos.get(tabId);
  if (!videos) {
    videos = [];
    tabVideos.set(tabId, videos);
  }

  // Use YouTube-specific dedup for googlevideo URLs
  const normalized = /googlevideo\.com/i.test(entry.url)
    ? normalizeYouTubeUrl(entry.url)
    : normalizeUrl(entry.url);

  const existing = videos.find((v) => {
    const vNorm = /googlevideo\.com/i.test(v.url)
      ? normalizeYouTubeUrl(v.url)
      : normalizeUrl(v.url);
    return vNorm === normalized;
  });

  if (existing) {
    const oldType = existing.type;
    if (entry.type && entry.type !== existing.type) existing.type = entry.type;
    if (entry.downloadable !== undefined) existing.downloadable = entry.downloadable;
    if (entry.quality) existing.quality = entry.quality;
    if (entry.source) existing.source = entry.source;
    if (entry.frameUrl) existing.frameUrl = entry.frameUrl;
    if (entry.size != null && Number.isFinite(entry.size) && entry.size > 0) existing.size = entry.size;
    existing.timestamp = Date.now();
    dlog("update-existing", entry.url, {
      tabId,
      oldType,
      newType: existing.type,
      source: existing.source,
      quality: existing.quality,
    });
    saveToStorage();
    return;
  }

  videos.push({
    url: entry.url,
    type: entry.type,
    downloadable: entry.downloadable,
    quality: entry.quality || null,
    source: entry.source || "network",
    frameUrl: entry.frameUrl || "",
    size: Number.isFinite(entry.size) && entry.size > 0 ? entry.size : null,
    timestamp: Date.now(),
  });

  dlog("add-video", entry.url, {
    tabId,
    type: entry.type,
    source: entry.source || "network",
    quality: entry.quality || null,
  });
  updateBadge(tabId);
  saveToStorage();
}

function updateVideoFromHeaders(tabId, url, patch) {
  if (!tabId || tabId < 0) return false;
  const videos = tabVideos.get(tabId);
  if (!videos) return false;
  const normalized = /googlevideo\.com/i.test(url)
    ? normalizeYouTubeUrl(url)
    : normalizeUrl(url);
  const video = videos.find((v) => {
    const vNorm = /googlevideo\.com/i.test(v.url)
      ? normalizeYouTubeUrl(v.url)
      : normalizeUrl(v.url);
    return vNorm === normalized;
  });
  if (!video) return false;
  Object.assign(video, patch);
  saveToStorage();
  return true;
}

function typeFromContentType(contentType) {
  const ct = String(contentType || "").toLowerCase();
  if (ct.includes("audio/")) return "audio";
  if (ct.includes("text/vtt") || ct.includes("application/x-subrip") || ct.includes("application/ttml+xml")) return "subtitle";
  if (ct.includes("video/mp4") || ct.includes("video/x-mp4")) return "mp4";
  if (ct.includes("video/webm")) return "webm";
  if (ct.includes("video/")) return "video";
  if (ct.includes("application/vnd.apple.mpegurl") || ct.includes("application/x-mpegurl")) return "hls";
  if (ct.includes("application/dash+xml")) return "dash";
  return null;
}

function asciiAt(bytes, offset, length) {
  if (!bytes || offset < 0 || offset + length > bytes.byteLength) return "";
  let out = "";
  for (let i = 0; i < length; i++) out += String.fromCharCode(bytes[offset + i]);
  return out;
}

function detectMp4Tracks(bytes) {
  const tracks = { hasVideo: false, hasAudio: false };
  if (!bytes || bytes.byteLength < 24) return tracks;
  for (let i = 4; i < bytes.byteLength - 16; i++) {
    if (asciiAt(bytes, i, 4) !== "hdlr") continue;
    const handler = asciiAt(bytes, i + 12, 4);
    if (handler === "vide") tracks.hasVideo = true;
    if (handler === "soun") tracks.hasAudio = true;
    if (tracks.hasVideo && tracks.hasAudio) break;
  }
  return tracks;
}

function probeHasVideo(probe) {
  if (!probe) return false;
  if (probe.type === "hls" || probe.type === "dash") return true;
  if (probe.tracks) return !!probe.tracks.hasVideo;
  return probe.type === "mp4" || probe.type === "webm" || probe.type === "video";
}

async function fetchProbeBytes(url, signal, maxBytes = 1048576) {
  const res = await fetch(url, {
    method: "GET",
    headers: { Range: `bytes=0-${maxBytes - 1}` },
    credentials: "include",
    cache: "no-store",
    signal,
  });
  if (!res.ok && res.status !== 206) throw new Error(`Probe HTTP ${res.status}`);
  if (!res.body) {
    return {
      bytes: new Uint8Array(await res.arrayBuffer()).subarray(0, maxBytes),
      contentType: res.headers.get("content-type") || "",
      status: res.status,
    };
  }

  const reader = res.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (total < maxBytes) {
      const { done, value } = await reader.read();
      if (done || !value) break;
      const take = Math.min(value.byteLength, maxBytes - total);
      chunks.push(value.subarray(0, take));
      total += take;
      if (take < value.byteLength) break;
    }
  } finally {
    try { await reader.cancel(); } catch {}
  }

  const out = new Uint8Array(total);
  let offset = 0;
  for (const c of chunks) {
    out.set(c, offset);
    offset += c.byteLength;
  }
  return {
    bytes: out,
    contentType: res.headers.get("content-type") || "",
    status: res.status,
  };
}

async function probeMediaUrl(url) {
  if (!/^https?:\/\//i.test(url)) return null;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 8000);
  try {
    const res = await fetch(url, {
      method: "HEAD",
      credentials: "include",
      cache: "no-store",
      signal: ctrl.signal,
    });
    const contentType = res.headers.get("content-type") || "";
    const contentLength = res.headers.get("content-length") || "";
    const probe = {
      contentType,
      contentLength,
      type: isLikelyAudioUrl(url) ? "audio" : typeFromContentType(contentType),
      status: res.status,
      audioUrlHint: isLikelyAudioUrl(url),
    };
    if (
      !probe.type ||
      probe.type === "mp4" ||
      probe.type === "video" ||
      /mp4|octet-stream/i.test(contentType)
    ) {
      try {
        const byteProbe = await fetchProbeBytes(url, ctrl.signal);
        const byteContentType = byteProbe.contentType || contentType;
        const tracks = detectMp4Tracks(byteProbe.bytes);
        probe.byteStatus = byteProbe.status;
        probe.byteContentType = byteContentType;
        probe.tracks = tracks;
        if (tracks.hasAudio && !tracks.hasVideo) probe.type = "audio";
        else if (tracks.hasVideo) probe.type = typeFromContentType(byteContentType) || "mp4";
        else probe.type = probe.type || typeFromContentType(byteContentType);
      } catch (e) {
        probe.byteProbeError = normalizeError(e);
      }
    }
    return probe;
  } finally {
    clearTimeout(timer);
  }
}

// --- Badge ---

function updateBadge(tabId) {
  const videos = tabVideos.get(tabId) || [];
  const count = videos.length;
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : "", tabId });
  chrome.action.setBadgeBackgroundColor({ color: "#e94560", tabId });
}

// --- Network request monitoring ---

chrome.webRequest.onBeforeRequest.addListener(
  (details) => {
    const { url } = details;
    const tabId = details.tabId;

    // JW Player analytics ping leaks manifest URL in mu= param. Extract first
    // (these pings are often blocked by adblockers but may still be requested).
    const jwExtract = extractManifestFromJwPing(url);
    if (jwExtract) {
      dlog("jw-ping-extract", jwExtract.url, { from: url });
      const targetTab = tabId >= 0 ? tabId : null;
      const add = (id) => {
        if (id == null || id < 0) return;
        addVideo(id, {
          url: jwExtract.url,
          type: jwExtract.type,
          downloadable: false,
          source: "jw-ping",
        });
      };
      if (targetTab) add(targetTab);
      else chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => add(tabs[0]?.id));
    }

    // Skip blacklisted, segments, and YouTube SABR chunks
    if (isBlacklisted(url)) { dlog("blacklist", url); return; }
    if (isSegment(url)) { dlog("segment", url); return; }
    if (isYouTubeSegment(url)) { dlog("yt-sabr", url); return; }

    const classification = classifyUrl(url);
    if (!classification) { dlog("nomatch-onbefore", url, { tabId }); return; }
    dlog("match-onbefore", url, { tabId, type: classification.type });

    if (tabId >= 0) {
      addVideo(tabId, {
        url,
        type: classification.type,
        downloadable: classification.downloadable,
        source: "network",
        frameUrl: details.initiator || "",
      });
    } else {
      // Worker / SW request — attribute to currently active tab
      chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
        const activeId = tabs[0]?.id;
        if (activeId && activeId >= 0) {
          addVideo(activeId, {
            url,
            type: classification.type,
            downloadable: classification.downloadable,
            source: "network-worker",
            frameUrl: details.initiator || "",
          });
        }
      });
    }
  },
  { urls: ["<all_urls>"] }
);

// Also monitor response headers for content-type
chrome.webRequest.onHeadersReceived.addListener(
  (details) => {
    const { url, responseHeaders } = details;
    let { tabId } = details;
    if (!responseHeaders) return;
    if (isBlacklisted(url)) return;
    if (isSegment(url)) return;
    if (isYouTubeSegment(url)) return;

    // Worker / service-worker requests have tabId === -1. Attribute to the
    // currently-active tab so manifests fetched off-thread (hls.js workers,
    // Shaka, Bilibili workers) still surface in the popup.
    if (tabId < 0) {
      // Fire-and-forget: query active tab; if available, re-attribute.
      // We can't await inside the listener synchronously, so we proceed
      // assuming attribution will be resolved below in the tabs.query path.
    }

    const contentType = responseHeaders.find(
      (h) => h.name.toLowerCase() === "content-type"
    );
    if (!contentType || !contentType.value) return;

    const contentLengthHdr = responseHeaders.find(
      (h) => h.name.toLowerCase() === "content-length"
    );
    const contentLength = contentLengthHdr ? parseInt(contentLengthHdr.value, 10) : null;

    const ct = contentType.value.toLowerCase();
    let type = null;
    let downloadable = false;

    if (ct.includes("video/mp4") || ct.includes("video/x-mp4")) {
      type = "mp4";
      downloadable = true;
    } else if (ct.includes("video/webm")) {
      type = "webm";
      downloadable = true;
    } else if (ct.includes("audio/")) {
      type = "audio";
      downloadable = true;
    } else if (
      ct.includes("text/vtt") ||
      ct.includes("application/x-subrip") ||
      ct.includes("application/ttml+xml")
    ) {
      type = "subtitle";
      downloadable = true;
    } else if (
      ct.includes("application/vnd.apple.mpegurl") ||
      ct.includes("application/x-mpegurl")
    ) {
      type = "hls";
    } else if (ct.includes("application/dash+xml")) {
      type = "dash";
    } else if (ct.includes("video/")) {
      type = "video";
      downloadable = true;
    }

    if (type) {
      dlog("ct-match", url, { tabId, type, ct });
      if (updateVideoFromHeaders(tabId, url, { type, downloadable, source: "network-headers", size: contentLength })) {
        return;
      }
      if (tabId >= 0) {
        addVideo(tabId, { url, type, downloadable, source: "network-headers", frameUrl: details.initiator || "", size: contentLength });
      } else {
        // Worker request: attribute to the active tab in the focused window.
        chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
          const activeId = tabs[0]?.id;
          if (activeId && activeId >= 0) {
            addVideo(activeId, { url, type, downloadable, source: "network-headers-worker", frameUrl: details.initiator || "", size: contentLength });
          }
        });
      }
    } else {
      // Log video-ish content types we ignored
      const lct = ct.toLowerCase();
      if (lct.includes("video/") || lct.includes("audio/") || lct.includes("mpegurl") || lct.includes("dash")) {
        dlog("ct-ignored", url, { tabId, ct });
      }
    }
  },
  { urls: ["<all_urls>"] },
  ["responseHeaders"]
);

// --- Message handling ---

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Messages targeted at offscreen are handled by offscreen.js — ignore here.
  if (message?.target === "offscreen") return;

  switch (message.type) {
    case "MEDIA_DETECTED": {
      const tabId = message.tabId || sender.tab?.id;
      if (!tabId) break;
      if (isBlacklisted(message.url)) break;
      if (isYouTubeSegment(message.url)) break;

      const classification = classifyUrl(message.url);
      if (classification) {
        addVideo(tabId, {
          url: message.url,
          type: message.mediaType || classification.type,
          downloadable: classification.downloadable,
          quality: message.quality,
          source: message.source || "content-script",
          frameUrl: sender.url || "",
        });
      } else if (message.mediaType) {
        const mType = message.mediaType;
        addVideo(tabId, {
          url: message.url,
          type: mType,
          downloadable: ["mp4", "webm", "video", "flv", "audio", "subtitle"].includes(mType),
          quality: message.quality,
          source: message.source || "content-script",
          frameUrl: sender.url || "",
        });
      }
      break;
    }

    case "MSE_BUFFER_REGISTERED": {
      const tabId = sender.tab?.id;
      if (!tabId) break;
      let set = tabMseBuffers.get(tabId);
      if (!set) {
        set = new Set();
        tabMseBuffers.set(tabId, set);
      }
      set.add(message.msId);
      updateBadge(tabId);
      break;
    }

    case "MSE_HAS_BUFFERS": {
      const tabId = message.tabId || sender.tab?.id;
      const set = tabMseBuffers.get(tabId);
      sendResponse({ has: !!(set && set.size > 0) });
      return true;
    }

    case "MSE_GET_SNAPSHOT": {
      const tabId = message.tabId;
      if (!tabId) {
        sendResponse({ snapshot: [] });
        return true;
      }
      chrome.tabs.sendMessage(tabId, { type: "MSE_SNAPSHOT_REQUEST" }, (resp) => {
        sendResponse({ snapshot: resp?.snapshot || [] });
      });
      return true;
    }

    case "MSE_EXPORT": {
      const tabId = message.tabId;
      if (!tabId) {
        sendResponse({ ok: false, error: "no tab id" });
        return true;
      }
      chrome.tabs.sendMessage(
        tabId,
        { type: "MSE_EXPORT_REQUEST", msId: message.msId, sbId: message.sbId },
        (resp) => sendResponse(resp || { ok: false, error: "no response" })
      );
      return true;
    }

    case "PAGE_TITLE": {
      const tabId = sender.tab?.id;
      if (tabId && message.title) {
        tabTitles.set(tabId, message.title);
      }
      if (tabId && message.pageUrl) {
        tabUrls.set(tabId, message.pageUrl);
      }
      break;
    }

    case "GET_VIDEOS": {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        const tabId = tabs[0]?.id;
        const rawVideos = tabId ? tabVideos.get(tabId) || [] : [];
        chrome.storage.local.get(["vidown_size_min_kb", "vidown_size_max_kb"], (s) => {
          const minBytes = (parseInt(s.vidown_size_min_kb, 10) || 0) * 1024;
          const maxBytes = (parseInt(s.vidown_size_max_kb, 10) || 0) * 1024;
          // Filter only entries that actually have a known size; manifests and
          // size-less direct URLs are always shown so the user can pick them.
          const videos = rawVideos.filter((v) => {
            const sz = Number(v.size);
            if (!Number.isFinite(sz) || sz <= 0) return true;
            if (minBytes > 0 && sz < minBytes) return false;
            if (maxBytes > 0 && sz > maxBytes) return false;
            return true;
          });
          const pageTitle = tabId ? tabTitles.get(tabId) || tabs[0]?.title || "" : "";
          const pageUrl = tabId ? tabUrls.get(tabId) || tabs[0]?.url || "" : "";
          sendResponse({ videos, pageTitle, pageUrl, tabId });
        });
      });
      return true;
    }

    case "DOWNLOAD": {
      const { url, filename, expectedType } = message;
      if (!url) {
        respondWithError(sendResponse, "No download URL provided");
        return true;
      }
      (async () => {
        let probe = null;
        if (expectedType && !["audio", "subtitle"].includes(expectedType)) {
          try {
            probe = await probeMediaUrl(url);
            dlog("download-probe", url, { expectedType, probe });
            if (probe?.type === "audio") {
              sendResponse({
                success: false,
                status: "error",
                error: "This URL is audio-only; skipped video download. Pick a video row or use yt-dlp for merged video+audio.",
                probe,
              });
              return;
            }
            if (!probeHasVideo(probe)) {
              sendResponse({
                success: false,
                status: "error",
                error: "Could not verify a video track in this URL. Use the stream/yt-dlp video option instead.",
                probe,
              });
              return;
            }
          } catch (e) {
            dlog("download-probe-failed", url, { expectedType, error: normalizeError(e) });
            sendResponse({
              success: false,
              status: "error",
              error: "Could not verify this direct URL contains video. Use yt-dlp video or the HLS/DASH row.",
            });
            return;
          }
        }
        if (filename) pendingFilenamesByUrl.set(url, filename);
        chrome.downloads.download(
          {
            url,
            filename: filename || undefined,
            saveAs: message.saveAs !== false,
          },
          (downloadId) => {
            const err = getLastErrorMessage();
            if (filename && typeof downloadId === "number") {
              pendingFilenames.set(downloadId, filename);
            }
            if (filename) setTimeout(() => pendingFilenamesByUrl.delete(url), 10000);
            dlog("download-start", url, { filename, expectedType, probe, downloadId, err });
            sendResponse({
              success: !err && typeof downloadId === "number",
              downloadId,
              error: err || null,
              probe,
            });
          }
        );
      })();
      return true;
    }

    case "START_RECORDING": {
      const tabId = message.tabId;
      if (!tabId) {
        respondWithError(sendResponse, "No tabId");
        return true;
      }
      const opts = { trim: !!message.trim };
      // Stash recorder options on `window` before injecting the driver, so
      // the driver can read them with a simple property lookup instead of
      // relying on an async message round-trip.
      chrome.scripting.executeScript({
        target: { tabId, allFrames: false },
        func: (o) => { window.__VIDOWN_RECORD_OPTS = o; },
        args: [opts],
        world: "MAIN",
      }).then(() => chrome.scripting.executeScript({
        target: { tabId, allFrames: false },
        files: ["utils/record-driver.js"],
        world: "MAIN",
      })).then(() => {
        sendResponse({ status: "ok" });
      }).catch((e) => {
        respondWithError(sendResponse, e);
      });
      return true;
    }

    case "STOP_RECORDING": {
      const tabId = message.tabId;
      if (!tabId) {
        respondWithError(sendResponse, "No tabId");
        return true;
      }
      chrome.scripting.executeScript({
        target: { tabId, allFrames: false },
        func: () => window.dispatchEvent(new Event("vidown-stop-record")),
        world: "MAIN",
      }).then(() => sendResponse({ status: "ok" }))
        .catch((e) => respondWithError(sendResponse, e));
      return true;
    }

    case "RECORD_STATUS_RELAY": {
      // Forwarded from content.js. Persist to session storage so popup
      // can read regardless of open state.
      chrome.storage.session.set({
        record_status: { ...message.payload, ts: Date.now(), tabId: sender.tab?.id }
      }).catch(() => {});
      break;
    }

    case "INJECT_FALLBACK": {
      const tabId = sender.tab?.id;
      const frameId = sender.frameId;
      if (tabId != null) {
        chrome.scripting
          .executeScript({
            target: { tabId, frameIds: [frameId || 0] },
            files: ["inject.js"],
            world: "MAIN",
          })
          .catch((e) => {
            console.warn("Vidown: fallback script injection failed", e);
          });
      }
      break;
    }

    case "CLEAR_TAB": {
      const tabId = message.tabId || sender.tab?.id;
      if (tabId) {
        tabVideos.delete(tabId);
        updateBadge(tabId);
        saveToStorage();
      }
      break;
    }

    // --- yt-dlp Native Messaging ---

    case "CHECK_YTDLP": {
      nativeOneShot({ action: "check" }, sendResponse);
      return true;
    }

    case "LIST_FORMATS": {
      nativeOneShot({ action: "formats", url: message.url }, sendResponse);
      return true;
    }

    case "PICK_DIR": {
      nativeOneShot(
        { action: "pick_dir", initial: message.initial || null },
        sendResponse
      );
      return true;
    }

    case "YTDLP_DOWNLOAD": {
      const dlId = message.id || String(Date.now());
      let port;
      try {
        port = chrome.runtime.connectNative(NATIVE_HOST);
      } catch (e) {
        respondWithError(sendResponse, "Cannot connect to yt-dlp host: " + normalizeError(e));
        return true;
      }

      activeNativePorts.set(dlId, port);

      port.onMessage.addListener((msg) => {
        chrome.storage.session.set({ [`dl_${dlId}`]: msg }).catch((e) => {
          console.warn("Vidown: failed to store download update", e);
        });
      });

      port.onDisconnect.addListener(() => {
        activeNativePorts.delete(dlId);
        const err = getLastErrorMessage();
        chrome.storage.session.set({
          [`dl_${dlId}`]: { status: "disconnected", id: dlId, error: err },
        }).catch((e) => {
          console.warn("Vidown: failed to store disconnect update", e);
        });
      });

      port.postMessage({
        action: "download",
        id: dlId,
        url: message.url,
        format: message.format || null,
        audio_format: message.audio_format || null,
        subs_only: message.subs_only || null,
        output_dir: message.output_dir || null,
        noplaylist: message.noplaylist !== undefined ? message.noplaylist : true,
        write_subs: message.write_subs || null,
      });

      sendResponse({ status: "started", id: dlId });
      return true;
    }

    case "BLOCK_DOMAIN": {
      const host = getDomain(message.url);
      if (host) {
        userBlockedDomains.add(host);
        saveBlockList();
        // Purge from all tabs
        for (const [tid, list] of tabVideos) {
          const filtered = list.filter((v) => !isUserBlocked(v.url));
          if (filtered.length !== list.length) {
            tabVideos.set(tid, filtered);
            updateBadge(tid);
          }
        }
        saveToStorage();
      }
      sendResponse({ status: "ok", blocked: host });
      return true;
    }

    case "OFFSCREEN_JOB_STATUS": {
      const key = `hls_dl_${message.jobId}`;
      const p = message.payload;
      chrome.storage.session.set({ [key]: p }).catch((e) => {
        console.warn("Vidown: failed to persist job status", e);
      });
      // Forward progress to content script for in-video ring overlay
      if (p && (p.status === "progress" || p.status === "done" || p.status === "error" || p.status === "cancelled")) {
        const pct = p.total > 0 ? (p.completed / p.total) * 100 : 0;
        chrome.tabs.query({ active: true, lastFocusedWindow: true }, (tabs) => {
          const tabId = tabs[0]?.id;
          if (tabId) {
            chrome.tabs.sendMessage(tabId, {
              type: "DOWNLOAD_PROGRESS_RING",
              jobId: message.jobId,
              percent: p.status === "done" ? 100 : pct,
              status: p.status === "progress" ? "downloading" : p.status,
            }).catch(() => {});
          }
        });
      }
      return false;
    }

    case "OFFSCREEN_HEARTBEAT": {
      // Just acknowledge to keep offscreen alive. No response needed.
      return false;
    }

    case "BG_HLS_DOWNLOAD":
    case "BG_DASH_DOWNLOAD":
    case "BG_HLS_LIST_VARIANTS":
    case "BG_DASH_LIST_REPS":
    case "BG_JOB_CANCEL":
    case "BG_JOB_PAUSE":
    case "BG_JOB_LIST": {
      const map = {
        BG_HLS_DOWNLOAD: "HLS_START",
        BG_DASH_DOWNLOAD: "DASH_START",
        BG_HLS_LIST_VARIANTS: "HLS_LIST_VARIANTS",
        BG_DASH_LIST_REPS: "DASH_LIST_REPS",
        BG_JOB_CANCEL: "JOB_CANCEL",
        BG_JOB_PAUSE: "JOB_PAUSE",
        BG_JOB_LIST: "JOB_LIST",
      };
      console.log("[vidown] BG msg:", message.type, "→ offscreen", map[message.type]);
      ensureOffscreen()
        .then(() => chrome.runtime.sendMessage({ ...message, type: map[message.type], target: "offscreen" }))
        .then((r) => {
          console.log("[vidown] Offscreen reply:", map[message.type], r);
          if (r === undefined) {
            sendResponse({ ok: false, error: "Offscreen returned no response (listener may have crashed)" });
          } else {
            sendResponse(r);
          }
        })
        .catch((e) => {
          console.error("[vidown] BG forward error:", e);
          respondWithError(sendResponse, e);
        });
      return true;
    }

    case "GET_DEBUG_LOG": {
      sendResponse({ buildId: BUILD_ID, log: debugLog.slice(-500), tabVideos: Object.fromEntries(tabVideos) });
      return true;
    }

    case "GET_BLOCKED_DOMAINS": {
      sendResponse({ domains: Array.from(userBlockedDomains) });
      return true;
    }

    case "UNBLOCK_DOMAIN": {
      userBlockedDomains.delete(message.domain);
      saveBlockList();
      sendResponse({ status: "ok" });
      return true;
    }

    case "REGISTER_DNR": {
      if (message.url && message.referer) {
        registerDnrRules(message.url, message.referer)
          .then((ruleId) => sendResponse({ success: true, ruleId }))
          .catch((e) => sendResponse({ success: false, error: String(e) }));
      } else {
        sendResponse({ success: false, error: "Missing url or referer" });
      }
      return true;
    }

    case "CANCEL_DOWNLOAD": {
      const port = activeNativePorts.get(message.id);
      if (port) {
        try {
          port.postMessage({ action: "cancel", id: message.id });
        } catch (e) {
          respondWithError(sendResponse, normalizeError(e), { id: message.id });
          return true;
        }
      }
      sendResponse({ status: "ok" });
      return true;
    }
  }
});

// --- IndexedDB transfer helpers (large data SW ↔ offscreen) ---
// Chrome MV3 message limit is ~64MB. For HLS/DASH downloads exceeding that,
// store data in IndexedDB and let offscreen read it by key.

const TRANSFER_DB_NAME = "vidown_transfer";
const TRANSFER_DB_VERSION = 1;

function openTransferDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(TRANSFER_DB_NAME, TRANSFER_DB_VERSION);
    req.onerror = () => reject(req.error);
    req.onsuccess = () => resolve(req.result);
    req.onupgradeneeded = (e) => {
      const db = e.target.result;
      if (!db.objectStoreNames.contains("data")) db.createObjectStore("data");
    };
  });
}

function writeTransferDB(db, key, value) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction("data", "readwrite");
    const store = tx.objectStore("data");
    const req = store.put(value, key);
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

function readTransferDB(db, key) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction("data", "readonly");
    const store = tx.objectStore("data");
    const req = store.get(key);
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

function clearTransferDB(db) {
  return new Promise((resolve, reject) => {
    const tx = db.transaction("data", "readwrite");
    const req = tx.objectStore("data").clear();
    req.onsuccess = () => resolve();
    req.onerror = () => reject(req.error);
  });
}

// --- Offscreen document management ---

const OFFSCREEN_URL = "offscreen.html";
let offscreenCreating = null;

async function pingOffscreen() {
  try {
    const r = await chrome.runtime.sendMessage({ type: "PING_OFFSCREEN", target: "offscreen" });
    return !!(r && r.ok);
  } catch {
    return false;
  }
}

// Track whether we've recreated offscreen since this SW started, so a stale
// document carried over from a previous extension load gets replaced.
let offscreenFreshened = false;

async function ensureOffscreen() {
  if (!chrome.offscreen) {
    throw new Error("Offscreen API not available — Edge/Chrome too old (need 116+)");
  }

  let exists = false;
  try {
    if (chrome.offscreen.hasDocument) {
      exists = await chrome.offscreen.hasDocument();
    } else if (chrome.runtime.getContexts) {
      const contexts = await chrome.runtime.getContexts({
        contextTypes: ["OFFSCREEN_DOCUMENT"],
      });
      exists = contexts && contexts.length > 0;
    }
  } catch (e) {
    console.warn("[vidown] hasDocument check failed:", e);
  }

  // First call after SW boot: tear down any stale offscreen doc carried over
  // from a previous extension load (Edge keeps it across reload).
  if (exists && !offscreenFreshened) {
    try {
      await chrome.offscreen.closeDocument();
      console.log("[vidown] Closed stale offscreen document");
      exists = false;
    } catch (e) {
      console.warn("[vidown] closeDocument failed:", e);
    }
  }
  offscreenFreshened = true;

  if (!exists) {
    if (offscreenCreating) {
      await offscreenCreating;
    } else {
      console.log("[vidown] Creating offscreen document");
      offscreenCreating = chrome.offscreen.createDocument({
        url: OFFSCREEN_URL,
        reasons: ["BLOBS", "WORKERS"],
        justification: "Run HLS/DASH segment downloads + transmux independent of popup lifecycle",
      });
      try {
        await offscreenCreating;
      } catch (e) {
        // Race: another caller may have created it already.
        console.warn("[vidown] createDocument failed (may already exist):", e);
      } finally {
        offscreenCreating = null;
      }
    }
  }

  // Wait until the offscreen document's onMessage listener is registered.
  for (let i = 0; i < 50; i++) {
    if (await pingOffscreen()) {
      console.log("[vidown] Offscreen ready after", i * 100, "ms");
      return;
    }
    await new Promise((r) => setTimeout(r, 100));
  }
  throw new Error("Offscreen document failed to become ready (ping timeout 5s)");
}

// --- Native Messaging helpers ---

const NATIVE_HOST = "com.vidown.ytdlp";
const activeNativePorts = new Map();

// One-shot: connect, send one message, wait for one response, disconnect
function nativeOneShot(message, callback) {
  let responded = false;
  try {
    const port = chrome.runtime.connectNative(NATIVE_HOST);

    port.onMessage.addListener((response) => {
      if (!responded) {
        responded = true;
        callback(response);
        port.disconnect();
      }
    });

    port.onDisconnect.addListener(() => {
      if (!responded) {
        responded = true;
        const err = getLastErrorMessage() || "Disconnected";
        callback({ status: "error", error: err });
      }
    });

    port.postMessage(message);
  } catch (e) {
    if (!responded) {
      responded = true;
      callback({ status: "error", error: e.message || String(e) });
    }
  }
}

// --- Dynamic DNR Session Rules (Referer / CORS Bypass) ---

function getRuleIdForHostname(hostname) {
  let hash = 0;
  for (let i = 0; i < hostname.length; i++) {
    hash = (hash << 5) - hash + hostname.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash) % 10000 + 1; // Unique ID 1 to 10000
}

async function registerDnrRules(streamUrl, refererUrl) {
  if (!chrome.declarativeNetRequest) {
    console.warn("Vidown: declarativeNetRequest API not available");
    return null;
  }
  try {
    let cleanStreamUrl = streamUrl;
    if (cleanStreamUrl.startsWith("blob:")) {
      cleanStreamUrl = cleanStreamUrl.substring(5);
    }
    const streamDomain = new URL(cleanStreamUrl).hostname;
    const refererOrigin = new URL(refererUrl).origin;
    const ruleId = getRuleIdForHostname(streamDomain);

    const rule = {
      id: ruleId,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          { header: "referer", operation: "set", value: refererUrl },
          { header: "origin", operation: "set", value: refererOrigin }
        ],
        responseHeaders: [
          { header: "access-control-allow-origin", operation: "set", value: "*" },
          { header: "access-control-allow-methods", operation: "set", value: "GET, HEAD, OPTIONS" },
          { header: "access-control-allow-headers", operation: "set", value: "*" }
        ]
      },
      condition: {
        requestDomains: [streamDomain]
      }
    };

    await chrome.declarativeNetRequest.updateSessionRules({
      addRules: [rule],
      removeRuleIds: [ruleId] // Clear existing rule first to ensure clean overwrite
    });

    console.log(`[vidown] DNR rule ${ruleId} registered for ${streamDomain} with referer ${refererUrl}`);
    return ruleId;
  } catch (e) {
    console.error("[vidown] DNR registration error:", e);
    return null;
  }
}

// --- Tab lifecycle ---

chrome.tabs.onRemoved.addListener((tabId) => {
  tabVideos.delete(tabId);
  tabTitles.delete(tabId);
  tabUrls.delete(tabId);
  saveToStorage();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === "loading") {
    tabVideos.delete(tabId);
    tabTitles.delete(tabId);
    tabUrls.delete(tabId);
    updateBadge(tabId);
    saveToStorage();
  }
});
