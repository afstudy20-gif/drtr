// Vidown - Popup Script
// Renders detected videos, format picker, download progress via yt-dlp native host

(function () {
  "use strict";

  const POPUP_BUILD_ID = "audio-fix-2026-05-24-3";

  const videoList = document.getElementById("video-list");
  const emptyState = document.getElementById("empty-state");
  const toast = document.getElementById("toast");
  const btnRescan = document.getElementById("btn-rescan");
  const btnClear = document.getElementById("btn-clear");
  const btnDebug = document.getElementById("btn-debug");
  const ytdlpStatusEl = document.getElementById("ytdlp-status");

  // Modal elements
  const formatModal = document.getElementById("format-modal");
  const modalTitle = document.getElementById("modal-title");
  const modalClose = document.getElementById("modal-close");
  const formatLoading = document.getElementById("format-loading");
  const formatList = document.getElementById("format-list");
  const formatError = document.getElementById("format-error");

  // Progress elements
  const downloadProgress = document.getElementById("download-progress");
  const progressTitle = document.getElementById("progress-title");
  const progressBar = document.getElementById("progress-bar");
  const progressPercent = document.getElementById("progress-percent");
  const progressSpeed = document.getElementById("progress-speed");
  const progressEta = document.getElementById("progress-eta");
  const progressCounter = document.getElementById("progress-counter");
  const progressCancel = document.getElementById("progress-cancel");

  // Settings elements
  const btnSettings = document.getElementById("btn-settings");
  const settingsPanel = document.getElementById("settings-panel");
  const settingsDir = document.getElementById("settings-dir");
  const settingsBrowse = document.getElementById("settings-browse");
  const settingsSave = document.getElementById("settings-save");
  const settingsReset = document.getElementById("settings-reset");
  const settingsSizeMin = document.getElementById("settings-size-min");
  const settingsSizeMax = document.getElementById("settings-size-max");
  const settingsSubs = document.getElementById("settings-subs");
  const settingsBlockedList = document.getElementById("settings-blocked-list");

  // State
  let currentPageTitle = "";
  let currentPageUrl = "";
  let ytdlpConnected = false;
  let userDownloadDir = "";
  let downloadSubs = false;
  let currentDownloadId = null;
  let currentDownloadUrl = "";
  let currentVideos = [];
  let currentTabId = null;
  let mseBuffers = []; // [{msId, sourceBuffers:[{id,mime,chunkCount,bytes}], pageTitle, live}]

  // Platforms where yt-dlp works best
  const YTDLP_SITES = [
    { regex: /youtube\.com|youtu\.be/i, name: "YouTube" },
    { regex: /twitch\.tv/i, name: "Twitch" },
    { regex: /dailymotion\.com/i, name: "Dailymotion" },
    { regex: /vimeo\.com/i, name: "Vimeo" },
    { regex: /facebook\.com|fb\.watch/i, name: "Facebook" },
    { regex: /instagram\.com/i, name: "Instagram" },
    { regex: /tiktok\.com/i, name: "TikTok" },
    { regex: /x\.com|twitter\.com/i, name: "X/Twitter" },
    { regex: /reddit\.com/i, name: "Reddit" },
    { regex: /bilibili\.(com|tv)/i, name: "Bilibili" },
    { regex: /nicovideo\.jp/i, name: "Niconico" },
    { regex: /soundcloud\.com/i, name: "SoundCloud" },
    { regex: /bandcamp\.com/i, name: "Bandcamp" },
  ];

  function getYtdlpSite(url) {
    if (!url) return null;
    for (const s of YTDLP_SITES) {
      if (s.regex.test(url)) return s.name;
    }
    return null;
  }

  // --- Toast ---
  let toastTimeout;
  function showToast(msg) {
    toast.textContent = msg;
    toast.style.display = "block";
    clearTimeout(toastTimeout);
    toastTimeout = setTimeout(() => (toast.style.display = "none"), 1500);
  }

  // --- Helpers ---
  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function escapeAttr(str) {
    return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;")
      .replace(/'/g, "&#39;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }

  async function copyToClipboard(text) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.cssText = "position:fixed;opacity:0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
  }

  function truncateUrl(url, maxLen = 80) {
    if (url.length <= maxLen) return url;
    try {
      const u = new URL(url);
      const parts = u.pathname.split("/").filter(Boolean);
      const last = parts[parts.length - 1] || "";
      const display = u.hostname + "/.../" + last;
      return display.length > maxLen ? url.substring(0, maxLen - 3) + "..." : display;
    } catch {
      return url.substring(0, maxLen - 3) + "...";
    }
  }

  function formatBytes(bytes) {
    if (!bytes) return "";
    if (bytes >= 1073741824) return (bytes / 1073741824).toFixed(1) + " GB";
    if (bytes >= 1048576) return (bytes / 1048576).toFixed(1) + " MB";
    if (bytes >= 1024) return (bytes / 1024).toFixed(0) + " KB";
    return bytes + " B";
  }

  function getBadgeClass(type) {
    const t = (type || "").toLowerCase().replace("-", "");
    const map = {
      mp4: "badge-mp4", webm: "badge-webm", mkv: "badge-mkv",
      avi: "badge-avi", flv: "badge-flv", hls: "badge-hls",
      dash: "badge-dash", dashsegment: "badge-dash-segment",
      blob: "badge-blob", blobmediasource: "badge-blob-mediasource",
      video: "badge-video", audio: "badge-audio", subtitle: "badge-subtitle",
    };
    return map[t] || "badge-video";
  }

  function getDisplayType(type) {
    const t = (type || "").toLowerCase();
    return t === "blob-mediasource" ? "BLOB" : t.toUpperCase();
  }

  function isDirectDownloadable(type) {
    return ["mp4", "webm", "mkv", "avi", "flv", "video", "m4v", "ogv", "subtitle"].includes(
      (type || "").toLowerCase()
    );
  }

  function isStreamManifest(type) {
    return ["hls", "dash"].includes((type || "").toLowerCase());
  }

  // --- Size estimation ---
  // Estimate file size from resolution height and duration (bitrate lookup table).
  // Returns bytes or null if no estimate possible.
  const BITRATE_ESTIMATES_KBPS = {
    2160: 20000, 1440: 10000, 1080: 5000, 720: 2500,
    480: 1000, 360: 600, 240: 400,
  };

  function estimateSize(bandwidth, height, durationSec) {
    if (bandwidth && durationSec) {
      return Math.round((bandwidth * durationSec) / 8);
    }
    if (height && durationSec) {
      const h = parseInt(height, 10);
      const sortedHeights = Object.keys(BITRATE_ESTIMATES_KBPS).map(Number).sort((a, b) => a - b);
      let bitrate = BITRATE_ESTIMATES_KBPS[360];
      for (const k of sortedHeights) {
        if (h >= k) bitrate = BITRATE_ESTIMATES_KBPS[k];
      }
      return Math.round((bitrate * durationSec * 1000) / 8);
    }
    return null;
  }

  // --- Filename ---
  function sanitizeFilename(name) {
    return name.replace(/[<>:"/\\|?*\x00-\x1f]/g, "").replace(/\s+/g, " ").trim().substring(0, 200);
  }

  function getExtension(type) {
    const map = { mp4: "mp4", webm: "webm", mkv: "mkv", avi: "avi", flv: "flv", video: "mp4", audio: "m4a", subtitle: "vtt" };
    return map[(type || "").toLowerCase()] || "mp4";
  }

  function audioExtFromUrl(url) {
    try {
      const p = new URL(url).pathname.toLowerCase();
      const m = p.match(/\.(mp3|m4a|aac|opus|ogg|wav|flac)(?:[/?#]|$)/);
      if (m) return m[1];
    } catch {}
    return null;
  }

  function buildFilename(url, type, quality) {
    if (currentPageTitle) {
      let name = sanitizeFilename(currentPageTitle);
      if (name) {
        const ext = (type || "").toLowerCase() === "audio"
          ? (audioExtFromUrl(url) || getExtension(type))
          : getExtension(type);
        let suffix = "";
        if (quality) {
          const resMatch = quality.match(/(\d{3,4}x\d{3,4})/);
          if (resMatch) suffix = `_${resMatch[1]}`;
          else if (type === "audio") suffix = "_audio";
        } else if (type === "audio") suffix = "_audio";
        return `${name}${suffix}.${ext}`;
      }
    }
    try {
      const u = new URL(url);
      const last = u.pathname.split("/").filter(Boolean).pop() || "";
      if (/\.(mp4|webm|mkv|avi|flv|m4v|ogv|m4a|vtt|srt|ttml|dfxp)/i.test(last)) return decodeURIComponent(last);
    } catch {}
    return `video_${Date.now()}.${getExtension(type)}`;
  }

  // --- Check yt-dlp connection ---
  function checkYtdlp() {
    chrome.runtime.sendMessage({ type: "CHECK_YTDLP" }, (response) => {
      if (response?.status === "ok") {
        ytdlpConnected = true;
        ytdlpStatusEl.textContent = `yt-dlp v${response.version}`;
        ytdlpStatusEl.className = "ytdlp-status connected";
        ytdlpStatusEl.title = `Python ${response.python}`;
      } else {
        ytdlpConnected = false;
        ytdlpStatusEl.textContent = "yt-dlp";
        ytdlpStatusEl.className = "ytdlp-status disconnected";
        ytdlpStatusEl.title = response?.error || "Not connected. Run install.sh";
      }
      renderVideos(currentVideos);
    });
  }

  // --- Render ---
  function collectDetectedSubtitles() {
    return (currentVideos || [])
      .filter((v) => (v.type || "").toLowerCase() === "subtitle")
      .map((v) => ({ url: v.url, quality: v.quality || "subtitle" }));
  }

  function renderVideos(videos) {
    videoList.innerHTML = "";

    // Collapse master + child HLS playlists into single rows
    if (window.HLSGrouping && Array.isArray(videos)) {
      videos = window.HLSGrouping.groupStreams(videos);
    }

    const siteName = getYtdlpSite(currentPageUrl);
    const hasVideos = videos && videos.length > 0;

    // Empty list AND not on a yt-dlp-supported site → empty state.
    if (!hasVideos && !siteName) {
      videoList.style.display = "none";
      emptyState.style.display = "flex";
      return;
    }

    videoList.style.display = "flex";
    emptyState.style.display = "none";

    // Page title
    if (currentPageTitle) {
      const titleBar = document.createElement("div");
      titleBar.className = "page-title-bar";
      titleBar.textContent = currentPageTitle;
      videoList.appendChild(titleBar);
    }

    // MSE captured buffers (above sniffed streams — they're the surest hit
    // since the data already arrived through the player).
    renderMseBuffers(videoList);

    // yt-dlp banner for supported sites (always render when site matches,
    // even if no media URLs were sniffed — YouTube SABR segments are
    // intentionally filtered, so the banner is the primary download path).
    if (siteName) {
      const banner = document.createElement("div");
      banner.className = "ytdlp-banner";

      const isPlaylist = currentPageUrl && (currentPageUrl.includes("/playlist") || currentPageUrl.includes("list="));
      const isChannel = currentPageUrl && (
        currentPageUrl.includes("/channel/") ||
        currentPageUrl.includes("/c/") ||
        currentPageUrl.includes("/user/") ||
        /\.com\/@[^/]+/.test(currentPageUrl)
      );
      const isCollection = isPlaylist || isChannel;
      const collectionType = isChannel ? "Channel" : "Playlist";

      if (ytdlpConnected) {
        banner.innerHTML = `
          <div class="ytdlp-banner-text">
            <strong>${escapeHtml(siteName)}</strong> — download with yt-dlp:
          </div>
          <div class="ytdlp-banner-actions">
            <button class="btn btn-ytdlp ytdlp-page-btn" data-action="ytdlp-download-page">
              <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M8 12l-4-4h2.5V1h3v7H12L8 12zm-6 2h12v2H2v-2z"/></svg>
              Download
            </button>
            ${isCollection ? `
            <button class="btn btn-ytdlp ytdlp-page-btn" data-action="ytdlp-download-playlist" style="background: linear-gradient(135deg, #10b981, #059669);">
              <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M12 2H4a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2zm-1 9H5V5h6v6z"/></svg>
              ${collectionType}
            </button>
            ` : ""}
            <button class="btn btn-copy ytdlp-page-btn" data-action="ytdlp-copy">
              <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M4 2a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V2zm8 0H6v8h6V2zM2 4a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2v-1H8v1H2V6h1V4z"/></svg>
              Copy cmd
            </button>
            <button class="btn btn-copy ytdlp-page-btn" data-action="export-cookies">
              <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="8" r="7" fill="none" stroke="currentColor" stroke-width="1.5"/><circle cx="5" cy="6" r="1"/><circle cx="10" cy="9" r="1"/><circle cx="6" cy="11" r="1"/></svg>
              Cookies
            </button>
          </div>
        `;
      } else {
        banner.innerHTML = `
          <div class="ytdlp-banner-text">
            <strong>${escapeHtml(siteName)}</strong> uses segmented streaming. Use <strong>yt-dlp</strong>:
          </div>
          <div class="ytdlp-banner-actions">
            <button class="btn btn-ytdlp ytdlp-page-btn" data-action="ytdlp-copy">
              <svg width="12" height="12" viewBox="0 0 16 16" fill="currentColor"><path d="M6 1v3H1v1h5v3l4-3.5L6 1zM1 14h14v1H1v-1z"/></svg>
              Copy yt-dlp command
            </button>
          </div>
        `;
      }

      videoList.appendChild(banner);

      banner.querySelectorAll("[data-action]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const action = btn.dataset.action;
          if (action === "ytdlp-download-page") {
            openFormatPicker(currentPageUrl);
          } else if (action === "ytdlp-download-playlist") {
            startYtdlpDownload(currentPageUrl, null, "playlist");
          } else if (action === "ytdlp-copy") {
            copyToClipboard(`yt-dlp "${currentPageUrl}"`);
            showToast("yt-dlp command copied!");
          } else if (action === "export-cookies") {
            exportCookiesForCurrentPage();
          }
        });
      });
    }

    // Video cards
    videos.sort((a, b) => {
      const rank = (v) => {
        const t = (v.type || "").toLowerCase();
        if (t === "hls" || t === "dash") return 0;
        if (t === "audio" || t === "subtitle") return 3;
        if (isDirectDownloadable(t)) return 1;
        return 2;
      };
      return rank(a) - rank(b);
    }).forEach((video) => {
      const card = document.createElement("div");
      card.className = "video-card";

      const type = video.type || "unknown";
      const badgeClass = getBadgeClass(type);
      const displayType = getDisplayType(type);
      const directDL = isDirectDownloadable(type);
      const isStream = isStreamManifest(type);
      const filename = buildFilename(video.url, type, video.quality);

      const sizeLabel = video.size ? formatBytes(video.size) : "";
      let qualityHtml = video.quality
        ? `<div class="video-quality">${escapeHtml(video.quality)}${sizeLabel ? " — ~" + sizeLabel : ""}</div>`
        : sizeLabel ? `<div class="video-quality">~${sizeLabel}</div>` : "";

      if (video.groupCount && video.groupCount > 1) {
        qualityHtml += `<div class="video-quality">${video.groupCount} variants merged</div>`;
      }

      let actionsHtml = "";

      if (directDL) {
        const label = type.toLowerCase() === "subtitle" ? "Download subtitle" : "Download";
        actionsHtml = `
          <button class="btn btn-copy" data-url="${escapeAttr(video.url)}" data-action="copy">Copy</button>
          <button class="btn btn-download" data-url="${escapeAttr(video.url)}" data-type="${escapeAttr(type)}" data-filename="${escapeAttr(filename)}" data-action="download">${label}</button>
        `;
      } else if (type.toLowerCase() === "audio") {
        actionsHtml = `
          <button class="btn btn-copy" data-url="${escapeAttr(video.url)}" data-action="copy">Copy audio URL</button>
          <button class="btn btn-download" data-url="${escapeAttr(video.url)}" data-type="${escapeAttr(type)}" data-filename="${escapeAttr(filename)}" data-action="download">Download</button>
          ${ytdlpConnected ? `<button class="btn btn-ytdlp" data-url="${escapeAttr(currentPageUrl || video.url)}" data-action="ytdlp-download">yt-dlp video</button>` : ""}
        `;
      } else if (type.toLowerCase() === "hls") {
        const ytdlpBtn = ytdlpConnected
          ? `<button class="btn btn-ytdlp" data-url="${escapeAttr(video.url)}" data-action="ytdlp-download">yt-dlp</button>`
          : "";
        actionsHtml = `
          <button class="btn btn-copy" data-url="${escapeAttr(video.url)}" data-action="copy">Copy</button>
          <button class="btn btn-download" data-url="${escapeAttr(video.url)}" data-frame-url="${escapeAttr(video.frameUrl || "")}" data-action="hls-download">Download</button>
          <button class="btn btn-download" data-url="${escapeAttr(video.url)}" data-frame-url="${escapeAttr(video.frameUrl || "")}" data-output-format="ts" data-action="hls-download">TS</button>
          ${ytdlpBtn}
        `;
      } else if (type.toLowerCase() === "dash") {
        const ytdlpBtn = ytdlpConnected
          ? `<button class="btn btn-ytdlp" data-url="${escapeAttr(video.url)}" data-action="ytdlp-download">yt-dlp</button>`
          : "";
        actionsHtml = `
          <button class="btn btn-copy" data-url="${escapeAttr(video.url)}" data-action="copy">Copy</button>
          <button class="btn btn-download" data-url="${escapeAttr(video.url)}" data-frame-url="${escapeAttr(video.frameUrl || "")}" data-action="dash-download">Download</button>
          ${ytdlpBtn}
        `;
      } else if (isStream && ytdlpConnected) {
        actionsHtml = `
          <button class="btn btn-copy" data-url="${escapeAttr(video.url)}" data-action="copy">Copy URL</button>
          <button class="btn btn-ytdlp" data-url="${escapeAttr(video.url)}" data-action="ytdlp-download">yt-dlp</button>
        `;
      } else if (isStream) {
        actionsHtml = `
          <button class="btn btn-copy" data-url="${escapeAttr(video.url)}" data-action="copy">Copy URL</button>
          <button class="btn btn-ytdlp" data-url="${escapeAttr(video.url)}" data-action="ytdlp-cmd">yt-dlp cmd</button>
        `;
      } else {
        actionsHtml = `
          <button class="btn btn-copy" data-url="${escapeAttr(video.url)}" data-action="copy">Copy URL</button>
        `;
      }

      card.innerHTML = `
        <div class="video-card-header">
          <span class="format-badge ${badgeClass}">${displayType}</span>
          <span class="video-source">${escapeHtml(video.source || "")}</span>
          <button class="btn-block" data-url="${escapeAttr(video.url)}" data-action="block" title="Block this domain">
            <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="8" r="7" fill="none" stroke="currentColor" stroke-width="1.5"/><path d="M4 8h8" stroke="currentColor" stroke-width="1.5"/></svg>
          </button>
        </div>
        <div class="video-filename" title="${escapeAttr(filename)}">${escapeHtml(filename)}</div>
        <div class="video-url" title="${escapeAttr(video.url)}">${escapeHtml(truncateUrl(video.url))}</div>
        ${qualityHtml}
        <div class="video-actions">${actionsHtml}</div>
      `;

      videoList.appendChild(card);
    });

    // Event delegation for actions
    videoList.querySelectorAll("[data-action]").forEach((btn) => {
      btn.addEventListener("click", handleAction);
    });
  }

  // --- Actions ---
  async function handleAction(e) {
    const btn = e.currentTarget;
    const action = btn.dataset.action;
    const url = btn.dataset.url;

    switch (action) {
      case "copy":
        await copyToClipboard(url);
        showToast("URL copied!");
        break;

      case "download": {
        const filename = btn.dataset.filename;
        const expectedType = btn.dataset.type || "";
        btn.disabled = true;
        btn.textContent = "Starting...";
        chrome.runtime.sendMessage({ type: "DOWNLOAD", url, filename, expectedType }, (r) => {
          if (r?.success) {
            showToast("Download started!");
          } else {
            showToast("Failed: " + (r?.error || "unknown"));
            btn.disabled = false;
            btn.textContent = "Download";
          }
        });
        break;
      }

      case "ytdlp-cmd":
        await copyToClipboard(`yt-dlp "${url}"`);
        showToast("yt-dlp command copied!");
        break;

      case "ytdlp-download":
        openFormatPicker(url);
        break;

      case "hls-download": {
        const frameUrl = btn.dataset.frameUrl || "";
        openHlsDownloader(url, frameUrl, btn.dataset.outputFormat || null);
        break;
      }

      case "dash-download": {
        const frameUrl = btn.dataset.frameUrl || "";
        openDashDownloader(url, frameUrl);
        break;
      }

      case "block": {
        const host = (() => { try { return new URL(url).hostname; } catch { return ""; } })();
        if (!host) { showToast("Invalid URL"); break; }
        chrome.runtime.sendMessage({ type: "BLOCK_DOMAIN", url }, () => {
          showToast(`Blocked ${host}`);
          loadVideos();
        });
        break;
      }
    }
  }

  // --- DASH downloader (reuses HLS modal UI) ---
  let dashKind = false;

  async function openDashDownloader(url, frameUrl) {
    hlsCurrentUrl = url;
    dashKind = true;
    resetHlsUi();
    hlsVariantSelect.innerHTML = '<option>Loading representations...</option>';
    hlsVariantSelect.disabled = true;
    hlsFilenameInput.value = defaultHlsFilename();
    hlsFilenameInput.setAttribute("readonly", "true");
    hlsModalTitle.textContent = "DASH (MPD) Video Downloader";
    hlsModal.style.display = "flex";

    await ensureDnrHeaders(url, frameUrl);

    try {
      const reps = await window.DASHDownloader.listRepresentations(url);
      hlsVariantSelect.disabled = false;
      hlsVariantSelect.innerHTML = "";
      const videoReps = reps.filter((r) => (r.contentType || "").includes("video"));
      const list = videoReps.length > 0 ? videoReps : reps;
      if (list.length === 0) {
        const opt = document.createElement("option");
        opt.textContent = "No representations";
        hlsVariantSelect.appendChild(opt);
      } else {
        for (const r of list) {
          const opt = document.createElement("option");
          opt.value = r.id;
          const res = r.resolution
            || (r.bandwidth ? Math.round(r.bandwidth / 1000) + "kbps" : r.id || "track");
          const bwLabel = r.bandwidth ? " ~" + formatBytes(r.bandwidth * 60 / 8) + "/min" : "";
          opt.textContent = res + (r.codecs ? "  " + r.codecs.split(",")[0] : "") + bwLabel;
          hlsVariantSelect.appendChild(opt);
        }
      }
      startDashDownload();
    } catch (e) {
      setHlsError(e.message || String(e));
      hlsVariantSelect.innerHTML = '<option>—</option>';
    }
  }

  async function startDashDownload() {
    if (hlsRunning) return;
    resetHlsUi();
    hlsRunning = true;

    const videoId = hlsVariantSelect.value || null;
    const concurrency = parseInt(hlsConcurrency.value, 10) || 6;
    const baseName = sanitizeFilename(hlsFilenameInput.value || defaultHlsFilename()) || "video";
    const jobId = "dash_" + Date.now();
    bgJobId = jobId;

    attachJobListener(jobId);

    const resp = await sendBg("BG_DASH_DOWNLOAD", {
      jobId,
      params: {
        url: hlsCurrentUrl,
        videoId,
        concurrency,
        filename: baseName,
        subtitles: collectDetectedSubtitles(),
      },
    });
    if (!resp?.ok) {
      setHlsError(resp?.error || "Failed to start");
      hlsRunning = false;
      return;
    }
    chrome.tabs.create({
      url: chrome.runtime.getURL("progress.html") +
        `#jobId=${encodeURIComponent(jobId)}&kind=dash&filename=${encodeURIComponent(baseName)}`,
    });
    closeHlsModal();
  }

  // Live progress listener — reads job status from chrome.storage.session.
  // Survives popup close/reopen because the offscreen doc keeps writing.
  function attachJobListener(jobId) {
    const key = `hls_dl_${jobId}`;

    // Catch up on existing state
    chrome.storage.session.get(key, (s) => {
      const msg = s?.[key];
      if (msg) applyJobStatus(msg);
    });

    const listener = (changes) => {
      if (!changes[key]) return;
      const msg = changes[key].newValue;
      if (!msg) return;
      applyJobStatus(msg);
      if (msg.status === "done" || msg.status === "error" || msg.status === "cancelled") {
        chrome.storage.session.onChanged.removeListener(listener);
        chrome.storage.session.remove(key);
      }
    };
    chrome.storage.session.onChanged.addListener(listener);
  }

  function applyJobStatus(msg) {
    if (msg.status === "phase") {
      if (msg.phase === "playlist") hlsStatSpeed.textContent = "Loading playlist...";
      else if (msg.phase === "init") hlsStatSpeed.textContent = "Init segment...";
      else if (msg.phase === "merging") hlsStatSpeed.textContent = "Merging...";
      else if (msg.phase === "transmux") hlsStatSpeed.textContent = "Transmuxing TS→MP4...";
      else if (msg.phase === "audio") hlsStatSpeed.textContent = "Downloading audio track...";
      else if (msg.phase === "subtitles") hlsStatSpeed.textContent = "Downloading subtitles...";
      else if (msg.phase === "segments") hlsStatSpeed.textContent = "Downloading...";
    } else if (msg.status === "progress") {
      const pct = msg.total > 0 ? (msg.completed / msg.total) * 100 : 0;
      hlsProgressBar.style.width = pct.toFixed(2) + "%";
      hlsStatSegments.textContent = `${msg.completed}/${msg.total}`;
      if (msg.phase !== "transmux") {
        hlsStatSize.textContent = formatBytes(msg.bytes);
        hlsStatSpeed.textContent = formatBytes(msg.speed) + "/s";
      }
    } else if (msg.status === "done") {
      hlsProgressBar.style.width = "100%";
      hlsStatSpeed.textContent = "Done";
      showToast(`Saved ${msg.filename}${msg.audioTrack ? " + audio" : ""}${msg.subtitleCount ? ` + ${msg.subtitleCount} subtitles` : ""}`);
      hlsRunning = false;
      bgJobId = null;
    } else if (msg.status === "error") {
      setHlsError(msg.error || "Unknown error");
      hlsRunning = false;
      bgJobId = null;
    } else if (msg.status === "cancelled") {
      setHlsError("Cancelled");
      hlsRunning = false;
      bgJobId = null;
    }
  }

  // --- HLS in-browser downloader (FetchV-style) ---
  const hlsModal = document.getElementById("hls-modal");
  const hlsModalClose = document.getElementById("hls-modal-close");
  const hlsVariantSelect = document.getElementById("hls-variant-select");
  const hlsFilenameInput = document.getElementById("hls-filename-input");
  const hlsFilenameEdit = document.getElementById("hls-filename-edit");
  const hlsOpenTab = document.getElementById("hls-open-tab");
  const hlsProgressBar = document.getElementById("hls-progress-bar");
  const hlsStatSegments = document.getElementById("hls-stat-segments");
  const hlsStatSize = document.getElementById("hls-stat-size");
  const hlsStatSpeed = document.getElementById("hls-stat-speed");
  const hlsCancelBtn = document.getElementById("hls-cancel-btn");
  const hlsPauseBtn = document.getElementById("hls-pause-btn");
  const hlsPauseIcon = document.getElementById("hls-pause-icon");
  const hlsPlayIcon = document.getElementById("hls-play-icon");
  const hlsSettingsBtn = document.getElementById("hls-settings-btn");
  const hlsSettingsPanel = document.getElementById("hls-settings-panel");
  const hlsConcurrency = document.getElementById("hls-concurrency");
  const hlsOutputFormat = document.getElementById("hls-output-format");
  const hlsError = document.getElementById("hls-error");
  const hlsModalTitle = document.getElementById("hls-modal-title");

  let hlsAbortCtrl = null;
  let hlsPaused = false;
  let hlsCurrentUrl = "";
  let hlsRunning = false;
  let hlsOutputOverride = null;

  // Persist HLS settings
  chrome.storage.local.get(["hls_concurrency", "hls_output_format"], (s) => {
    if (s.hls_concurrency) hlsConcurrency.value = s.hls_concurrency;
    if (s.hls_output_format) hlsOutputFormat.value = s.hls_output_format;
  });

  // --- Vidown settings (download folder + size filter) ---
  chrome.storage.local.get(
    ["vidown_download_dir", "vidown_size_min_kb", "vidown_size_max_kb", "vidown_download_subs"],
    (s) => {
      userDownloadDir = s.vidown_download_dir || "";
      if (settingsDir) settingsDir.value = userDownloadDir;
      if (settingsSizeMin) settingsSizeMin.value = s.vidown_size_min_kb || "";
      if (settingsSizeMax) settingsSizeMax.value = s.vidown_size_max_kb || "";
      downloadSubs = !!s.vidown_download_subs;
      if (settingsSubs) settingsSubs.checked = downloadSubs;
    }
  );

  function refreshBlockedDomains() {
    if (!settingsBlockedList) return;
    chrome.runtime.sendMessage({ type: "GET_BLOCKED_DOMAINS" }, (resp) => {
      const domains = resp?.domains || [];
      settingsBlockedList.innerHTML = "";
      if (domains.length === 0) {
        const hint = document.createElement("span");
        hint.className = "settings-hint";
        hint.textContent = "No domains blocked yet — use the trash icon on a row to add one.";
        settingsBlockedList.appendChild(hint);
        return;
      }
      for (const d of domains) {
        const row = document.createElement("div");
        row.className = "settings-blocked-row";
        const label = document.createElement("span");
        label.textContent = d;
        const btn = document.createElement("button");
        btn.textContent = "Unblock";
        btn.addEventListener("click", () => {
          chrome.runtime.sendMessage({ type: "UNBLOCK_DOMAIN", domain: d }, () => {
            refreshBlockedDomains();
          });
        });
        row.appendChild(label);
        row.appendChild(btn);
        settingsBlockedList.appendChild(row);
      }
    });
  }

  if (btnSettings) {
    btnSettings.addEventListener("click", () => {
      const isOpen = settingsPanel.style.display !== "none";
      settingsPanel.style.display = isOpen ? "none" : "block";
      if (!isOpen) {
        settingsDir.focus();
        refreshBlockedDomains();
      }
    });
  }

  if (settingsSave) {
    settingsSave.addEventListener("click", () => {
      userDownloadDir = settingsDir.value.trim();
      const sizeMinKb = parseInt(settingsSizeMin?.value, 10) || 0;
      const sizeMaxKb = parseInt(settingsSizeMax?.value, 10) || 0;
      downloadSubs = settingsSubs ? settingsSubs.checked : false;
      chrome.storage.local.set(
        {
          vidown_download_dir: userDownloadDir,
          vidown_size_min_kb: sizeMinKb,
          vidown_size_max_kb: sizeMaxKb,
          vidown_download_subs: downloadSubs,
        },
        () => {
          showToast("Settings saved");
          settingsPanel.style.display = "none";
          loadVideos();
        }
      );
    });
  }

  if (settingsReset) {
    settingsReset.addEventListener("click", () => {
      userDownloadDir = "";
      settingsDir.value = "";
      if (settingsSizeMin) settingsSizeMin.value = "";
      if (settingsSizeMax) settingsSizeMax.value = "";
      downloadSubs = false;
      if (settingsSubs) settingsSubs.checked = false;
      chrome.storage.local.remove(
        ["vidown_download_dir", "vidown_size_min_kb", "vidown_size_max_kb", "vidown_download_subs"],
        () => {
          showToast("Reset to defaults");
          loadVideos();
        }
      );
    });
  }

  if (settingsBrowse) {
    settingsBrowse.addEventListener("click", () => {
      if (!ytdlpConnected) {
        showToast("yt-dlp host required for native folder picker");
        return;
      }
      settingsBrowse.disabled = true;
      const originalLabel = settingsBrowse.textContent;
      settingsBrowse.textContent = "Picking...";
      chrome.runtime.sendMessage(
        { type: "PICK_DIR", initial: settingsDir.value.trim() || userDownloadDir || "" },
        (resp) => {
          settingsBrowse.disabled = false;
          settingsBrowse.textContent = originalLabel;
          if (!resp) {
            showToast("No response from host");
            return;
          }
          if (resp.status === "ok" && resp.path) {
            settingsDir.value = resp.path;
          } else if (resp.status === "cancelled") {
            // user closed dialog — no toast
          } else {
            showToast("Picker error: " + (resp.error || "unknown"));
          }
        }
      );
    });
  }

  hlsConcurrency.addEventListener("change", () => {
    chrome.storage.local.set({ hls_concurrency: hlsConcurrency.value });
  });
  hlsOutputFormat.addEventListener("change", () => {
    chrome.storage.local.set({ hls_output_format: hlsOutputFormat.value });
  });

  function setHlsError(msg) {
    if (!msg) {
      hlsError.style.display = "none";
      hlsError.textContent = "";
    } else {
      hlsError.style.display = "block";
      hlsError.textContent = "Error: " + msg;
    }
  }

  function resetHlsUi() {
    hlsProgressBar.style.width = "0%";
    hlsStatSegments.textContent = "0/0";
    hlsStatSize.textContent = "0 B";
    hlsStatSpeed.textContent = "0 B/s";
    hlsPauseIcon.style.display = "";
    hlsPlayIcon.style.display = "none";
    hlsPaused = false;
    setHlsError("");
  }

  function closeHlsModal() {
    if (hlsRunning && hlsAbortCtrl) {
      hlsAbortCtrl.abort();
    }
    hlsModal.style.display = "none";
    hlsRunning = false;
    hlsAbortCtrl = null;
  }

  hlsModalClose.addEventListener("click", closeHlsModal);
  hlsModal.addEventListener("click", (e) => {
    if (e.target === hlsModal) closeHlsModal();
  });

  hlsFilenameEdit.addEventListener("click", () => {
    hlsFilenameInput.removeAttribute("readonly");
    hlsFilenameInput.focus();
    hlsFilenameInput.select();
  });

  hlsOpenTab.addEventListener("click", () => {
    if (hlsCurrentUrl) chrome.tabs.create({ url: hlsCurrentUrl });
  });

  hlsCancelBtn.addEventListener("click", () => {
    if (bgJobId) {
      sendBg("BG_JOB_CANCEL", { jobId: bgJobId });
    } else if (hlsAbortCtrl) {
      hlsAbortCtrl.abort();
    }
  });

  hlsPauseBtn.addEventListener("click", () => {
    hlsPaused = !hlsPaused;
    hlsPauseIcon.style.display = hlsPaused ? "none" : "";
    hlsPlayIcon.style.display = hlsPaused ? "" : "none";
    if (bgJobId) sendBg("BG_JOB_PAUSE", { jobId: bgJobId, paused: hlsPaused });
  });

  hlsSettingsBtn.addEventListener("click", () => {
    hlsSettingsPanel.style.display =
      hlsSettingsPanel.style.display === "none" ? "block" : "none";
  });

  function defaultHlsFilename() {
    const base = currentPageTitle ? sanitizeFilename(currentPageTitle) : "video";
    return base || "video";
  }

  // Active background-job ID (survives popup close)
  let bgJobId = null;

  function sendBg(type, payload) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type, ...payload }, (r) => resolve(r));
    });
  }

  async function ensureDnrHeaders(streamUrl, frameUrl) {
    const referer = frameUrl || currentPageUrl;
    if (!referer) return;
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({
        type: "REGISTER_DNR",
        url: streamUrl,
        referer: referer
      }, (r) => resolve(r));
    });
  }

  async function openHlsDownloader(url, frameUrl, outputOverride) {
    hlsCurrentUrl = url;
    hlsOutputOverride = outputOverride || null;
    dashKind = false;
    resetHlsUi();
    hlsVariantSelect.innerHTML = '<option>Loading variants...</option>';
    hlsVariantSelect.disabled = true;
    hlsFilenameInput.value = defaultHlsFilename();
    hlsFilenameInput.setAttribute("readonly", "true");
    hlsModalTitle.textContent = "M3U8 Video Downloader";
    hlsModal.style.display = "flex";

    await ensureDnrHeaders(url, frameUrl);

    try {
      const resp = await sendBg("BG_HLS_LIST_VARIANTS", { url });
      if (!resp?.ok) throw new Error(resp?.error || "List variants failed");
      const variants = resp.variants || [];
      hlsVariantSelect.disabled = false;
      hlsVariantSelect.innerHTML = "";
      if (variants.length === 0) {
        const opt = document.createElement("option");
        opt.value = "";
        opt.textContent = "Auto (single playlist)";
        hlsVariantSelect.appendChild(opt);
      } else {
        for (const v of variants) {
          const opt = document.createElement("option");
          opt.value = v.url;
          const res = v.resolution || (v.bandwidth ? Math.round(v.bandwidth / 1000) + "kbps" : "Unknown");
          const kind = v.kind === "audio" ? " audio-only" : "";
          const bwLabel = v.bandwidth ? " ~" + formatBytes(v.bandwidth * 60 / 8) + "/min" : "";
          opt.textContent = res + (v.codecs ? "  " + v.codecs.split(",")[0] : "") + kind + bwLabel;
          hlsVariantSelect.appendChild(opt);
        }
      }
      if (hlsOutputOverride) hlsOutputFormat.value = hlsOutputOverride;
      // Auto-start best quality
      startHlsDownload();
    } catch (e) {
      setHlsError(e.message || String(e));
      hlsVariantSelect.innerHTML = '<option>—</option>';
    }
  }

  hlsVariantSelect.addEventListener("change", () => {
    if (hlsRunning && hlsAbortCtrl) hlsAbortCtrl.abort();
    setTimeout(() => {
      if (dashKind) startDashDownload();
      else startHlsDownload();
    }, 100);
  });

  async function startHlsDownload() {
    if (hlsRunning) return;
    resetHlsUi();
    hlsRunning = true;

    const variantUrl = hlsVariantSelect.value || null;
    const concurrency = parseInt(hlsConcurrency.value, 10) || 6;
    const outputFormat = hlsOutputOverride || hlsOutputFormat.value || "auto";
    hlsOutputOverride = null;
    const baseName = sanitizeFilename(hlsFilenameInput.value || defaultHlsFilename()) || "video";
    const jobId = "hls_" + Date.now();
    bgJobId = jobId;

    attachJobListener(jobId);

    const resp = await sendBg("BG_HLS_DOWNLOAD", {
      jobId,
      params: {
        url: hlsCurrentUrl,
        variantUrl,
        concurrency,
        outputFormat,
        filename: baseName,
      },
    });
    if (!resp?.ok) {
      setHlsError(resp?.error || "Failed to start");
      hlsRunning = false;
      return;
    }
    // Open standalone progress tab so user can switch tabs without losing UI
    chrome.tabs.create({
      url: chrome.runtime.getURL("progress.html") +
        `#jobId=${encodeURIComponent(jobId)}&kind=hls&filename=${encodeURIComponent(baseName)}`,
    });
    closeHlsModal();
  }

  // --- Format Picker ---
  function openFormatPicker(url) {
    currentDownloadUrl = url;
    formatModal.style.display = "flex";
    formatLoading.style.display = "flex";
    formatList.style.display = "none";
    formatError.style.display = "none";
    modalTitle.textContent = "Select Quality";

    chrome.runtime.sendMessage({ type: "LIST_FORMATS", url }, (response) => {
      formatLoading.style.display = "none";

      if (response?.status === "error") {
        formatError.textContent = response.error;
        formatError.style.display = "block";
        return;
      }

      if (response?.title) {
        modalTitle.textContent = response.title.length > 40
          ? response.title.substring(0, 40) + "..."
          : response.title;
      }

      const formats = response?.formats || [];
      if (formats.length === 0) {
        formatError.textContent = "No formats available";
        formatError.style.display = "block";
        return;
      }

      renderFormats(formats);
    });
  }

  function renderFormats(formats) {
    formatList.innerHTML = "";
    formatList.style.display = "block";

    // Add "Best quality" option first
    const bestItem = createFormatItem({
      label: "Best Quality",
      details: "Auto-select best video + audio",
      id: "bv*+ba/bv*",
      kind: "video+audio",
    });
    formatList.appendChild(bestItem);

    // Group by kind
    const videoAudio = formats.filter((f) => f.kind === "video+audio");
    const videoOnly = formats.filter((f) => f.kind === "video");
    const audioOnly = formats.filter((f) => f.kind === "audio");

    if (videoAudio.length > 0) {
      formatList.appendChild(sectionTitle("Video + Audio"));
      // Deduplicate by height
      const seen = new Set();
      for (const f of videoAudio) {
        const key = f.height || f.id;
        if (seen.has(key)) continue;
        seen.add(key);
        formatList.appendChild(createFormatItem({
          label: f.height ? `${f.height}p` : f.label,
          details: [f.ext, f.vcodec, f.acodec].filter(Boolean).join(" / "),
          size: formatBytes(f.filesize),
          id: f.id,
          kind: f.kind,
        }));
      }
    }

    if (videoOnly.length > 0) {
      formatList.appendChild(sectionTitle("Video Only"));
      const seen = new Set();
      for (const f of videoOnly) {
        const key = `${f.height}-${f.vcodec}`;
        if (seen.has(key)) continue;
        seen.add(key);
      formatList.appendChild(createFormatItem({
        label: f.height ? `${f.height}p` : f.label,
          details: [f.ext, f.vcodec, f.fps ? `${f.fps}fps` : "", "+ best audio"].filter(Boolean).join(" / "),
          size: formatBytes(f.filesize),
          id: f.id,
          kind: f.kind,
        }));
      }
    }

    if (audioOnly.length > 0) {
      formatList.appendChild(sectionTitle("Audio Only"));
      const seen = new Set();
      for (const f of audioOnly) {
        if (seen.has(f.id)) continue;
        seen.add(f.id);
        formatList.appendChild(createFormatItem({
          label: f.label || "Audio",
          details: [f.ext, f.acodec].filter(Boolean).join(" / "),
          size: formatBytes(f.filesize),
          id: f.id,
          kind: f.kind,
        }));
      }
    }

    // Quick Options: audio + MP3
    formatList.appendChild(sectionTitle("Quick Options"));
    formatList.appendChild(createFormatItem({
      label: "Best Audio (m4a)",
      details: "Extract best quality audio",
      id: "bestaudio",
      kind: "audio",
    }));
    formatList.appendChild(createFormatItem({
      label: "MP3 (audio)",
      details: "Download + convert to MP3 (yt-dlp -x --audio-format mp3)",
      id: "__mp3__",
      kind: "audio",
    }));
    formatList.appendChild(createFormatItem({
      label: "Subtitles (.srt)",
      details: "Download all available subtitles + auto-captions",
      id: "__subs__",
      kind: "audio",
    }));
  }

  function sectionTitle(text) {
    const el = document.createElement("div");
    el.className = "format-section-title";
    el.textContent = text;
    return el;
  }

  function createFormatItem(opts) {
    const el = document.createElement("div");
    el.className = "format-item";

    const kindClass = opts.kind === "video+audio" ? "video-audio"
      : opts.kind === "video" ? "video-only" : "audio-only";
    const kindLabel = opts.kind === "video+audio" ? "V+A"
      : opts.kind === "video" ? "V" : "A";

    el.innerHTML = `
      <span class="format-item-badge ${kindClass}">${kindLabel}</span>
      <span class="format-item-res">${escapeHtml(opts.label)}</span>
      <span class="format-item-details">${escapeHtml(opts.details || "")}</span>
      <span class="format-item-size">${escapeHtml(opts.size || "")}</span>
    `;

    el.addEventListener("click", () => {
      closeModal();
      startYtdlpDownload(currentDownloadUrl, opts.id, opts.kind);
    });

    return el;
  }

  function closeModal() {
    formatModal.style.display = "none";
  }

  modalClose.addEventListener("click", closeModal);
  formatModal.addEventListener("click", (e) => {
    if (e.target === formatModal) closeModal();
  });

  // --- yt-dlp Download with Progress ---
  function startYtdlpDownload(url, formatId, kind) {
    const dlId = String(Date.now());
    currentDownloadId = dlId;

    const isMp3 = formatId === "__mp3__";
    const isSubs = formatId === "__subs__";

    // Show progress UI
    progressTitle.textContent = currentPageTitle || "Downloading...";
    progressBar.style.width = "0%";
    progressPercent.textContent = isMp3 ? "Converting to MP3..."
      : isSubs ? "Fetching subtitles..." : "0%";
    progressSpeed.textContent = "";
    progressEta.textContent = "";
    if (progressCounter) {
      if (kind === "playlist") {
        progressCounter.textContent = "Playlist — fetching info...";
        progressCounter.style.display = "block";
      } else {
        progressCounter.textContent = "";
        progressCounter.style.display = "none";
      }
    }
    downloadProgress.style.display = "block";

    chrome.runtime.sendMessage({
      type: "YTDLP_DOWNLOAD",
      id: dlId,
      url,
      format: isMp3 ? "bestaudio" : (isSubs ? null : kind === "video" ? `${formatId}+bestaudio/${formatId}` : formatId),
      audio_format: isMp3 ? "mp3" : null,
      subs_only: isSubs ? true : null,
      noplaylist: kind === "playlist" ? false : true,
      output_dir: userDownloadDir || null,
      write_subs: downloadSubs || null,
    }, (response) => {
      if (response?.status === "error") {
        showToast("Error: " + response.error);
        downloadProgress.style.display = "none";
        currentDownloadId = null;
      }
      // Otherwise, progress updates come via storage
    });

    // Listen for progress via storage changes
    startProgressListener(dlId);
  }

  function updatePlaylistCounter(msg) {
    if (!progressCounter) return;
    const idx = msg.playlist_index;
    const total = msg.playlist_total;
    if (!idx && !total) return;
    const title = msg.playlist_title ? ` — ${msg.playlist_title}` : "";
    const counter = total ? `${idx}/${total}` : `${idx}`;
    progressCounter.textContent = `Video ${counter}${title}`;
    progressCounter.style.display = "block";
  }

  function startProgressListener(dlId) {
    const key = `dl_${dlId}`;

    const listener = (changes) => {
      if (!changes[key]) return;
      const msg = changes[key].newValue;
      if (!msg) return;

      switch (msg.status) {
        case "downloading":
          if (msg.filename) {
            progressTitle.textContent = msg.filename;
          }
          progressPercent.textContent = msg.percent || "0%";
          progressSpeed.textContent = msg.speed || "";
          progressEta.textContent = msg.eta ? `ETA ${msg.eta}` : "";
          // Parse percent for progress bar
          const pct = parseFloat(msg.percent) || 0;
          progressBar.style.width = `${Math.min(pct, 100)}%`;
          updatePlaylistCounter(msg);
          break;

        case "processing":
          progressPercent.textContent = "100%";
          progressBar.style.width = "100%";
          progressSpeed.textContent = "Merging...";
          progressEta.textContent = "";
          updatePlaylistCounter(msg);
          break;

        case "item_failed":
          // Playlist mode: a single video failed; keep progress visible and
          // let the next item continue.
          if (msg.playlist_index && msg.playlist_total) {
            const title = msg.playlist_title ? ` — ${msg.playlist_title}` : "";
            progressCounter.textContent = `Video ${msg.playlist_index}/${msg.playlist_total} failed${title}`;
            progressCounter.style.display = "block";
          }
          showToast(`Video ${msg.playlist_index} failed: ${msg.error || "unknown"}`);
          break;

        case "finished":
          downloadProgress.style.display = "none";
          currentDownloadId = null;
          if (msg.succeeded !== undefined && msg.playlist_total) {
            showToast(`Playlist done: ${msg.succeeded}/${msg.playlist_total} ok, ${msg.failed || 0} failed`);
          } else {
            showToast("Download complete!");
          }
          chrome.storage.session.onChanged.removeListener(listener);
          chrome.storage.session.remove(key);
          break;

        case "error":
          downloadProgress.style.display = "none";
          currentDownloadId = null;
          showToast("Error: " + (msg.error || "unknown"));
          chrome.storage.session.onChanged.removeListener(listener);
          chrome.storage.session.remove(key);
          break;

        case "cancelled":
          downloadProgress.style.display = "none";
          currentDownloadId = null;
          showToast("Download cancelled");
          chrome.storage.session.onChanged.removeListener(listener);
          chrome.storage.session.remove(key);
          break;

        case "disconnected":
          downloadProgress.style.display = "none";
          currentDownloadId = null;
          showToast("yt-dlp host disconnected");
          chrome.storage.session.onChanged.removeListener(listener);
          chrome.storage.session.remove(key);
          break;
      }
    };

    chrome.storage.session.onChanged.addListener(listener);
  }

  // Cancel button
  progressCancel.addEventListener("click", () => {
    if (currentDownloadId) {
      chrome.runtime.sendMessage({
        type: "CANCEL_DOWNLOAD",
        id: currentDownloadId,
      });
      progressPercent.textContent = "Cancelling...";
    }
  });

  // --- Button handlers ---
  btnRescan.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.tabs.sendMessage(tabs[0].id, { type: "RESCAN" });
        setTimeout(loadVideos, 1000);
      }
    });
    showToast("Rescanning...");
  });

  btnDebug.addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "GET_DEBUG_LOG" }, async (response) => {
      const payload = {
        popupBuildId: POPUP_BUILD_ID,
        pageUrl: currentPageUrl,
        pageTitle: currentPageTitle,
        copiedAt: new Date().toISOString(),
        ...response,
      };
      await copyToClipboard(JSON.stringify(payload, null, 2));
      showToast("Debug log copied");
    });
  });

  // Bulk download — direct files only (skips streams to avoid mass parallel transmux)
  document.getElementById("btn-download-all").addEventListener("click", () => {
    chrome.runtime.sendMessage({ type: "GET_VIDEOS" }, (response) => {
      const videos = response?.videos || [];
      const directs = videos.filter((v) => isDirectDownloadable(v.type));
      if (directs.length === 0) {
        showToast("No direct downloads (HLS/DASH require single download)");
        return;
      }
      let started = 0;
      for (const v of directs) {
        const filename = buildFilename(v.url, v.type, v.quality);
        chrome.runtime.sendMessage({ type: "DOWNLOAD", url: v.url, filename, expectedType: v.type }, (r) => {
          if (r?.success) started++;
        });
      }
      showToast(`Queued ${directs.length} downloads`);
    });
  });

  btnClear.addEventListener("click", () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.runtime.sendMessage({ type: "CLEAR_TAB", tabId: tabs[0].id });
      }
    });
    renderVideos([]);
    showToast("Cleared!");
  });

  // --- Load ---
  function loadVideos() {
    chrome.runtime.sendMessage({ type: "GET_VIDEOS" }, (response) => {
      currentPageTitle = response?.pageTitle || "";
      currentPageUrl = response?.pageUrl || "";
      currentVideos = response?.videos || [];
      currentTabId = response?.tabId || null;
      renderVideos(currentVideos);
      loadMseBuffers();
    });
  }

  function loadMseBuffers() {
    if (!currentTabId) return;
    chrome.runtime.sendMessage(
      { type: "MSE_GET_SNAPSHOT", tabId: currentTabId },
      (resp) => {
        mseBuffers = resp?.snapshot || [];
        if (mseBuffers.length > 0) renderVideos(currentVideos);
      }
    );
  }

  function formatBytes(n) {
    if (!n || n <= 0) return "0 B";
    const units = ["B", "KB", "MB", "GB"];
    let i = 0;
    let v = n;
    while (v >= 1024 && i < units.length - 1) { v /= 1024; i++; }
    return `${v.toFixed(1)} ${units[i]}`;
  }

  function mimeToExt(mime) {
    const m = (mime || "").toLowerCase();
    if (m.includes("mp4")) return "mp4";
    if (m.includes("webm")) return "webm";
    if (m.includes("aac") || m.includes("audio/mp4")) return "m4a";
    if (m.includes("ogg")) return "ogg";
    if (m.includes("mpeg")) return "mp3";
    return "bin";
  }

  function renderMseBuffers(container) {
    if (!Array.isArray(mseBuffers) || mseBuffers.length === 0) return;
    for (const buf of mseBuffers) {
      const sbs = buf.sourceBuffers || [];
      const hasBytes = sbs.some((sb) => (sb.bytes || 0) > 0);
      if (!hasBytes) continue;
      const card = document.createElement("div");
      card.className = "video-card";
      const totalBytes = sbs.reduce((s, sb) => s + (sb.bytes || 0), 0);
      const liveBadge = buf.live ? '<span class="format-badge badge-blob">LIVE</span>' : '<span class="format-badge badge-blob-mediasource">MSE</span>';
      card.innerHTML = `
        <div class="video-card-header">
          ${liveBadge}
          <span class="video-source">in-memory buffer</span>
        </div>
        <div class="video-filename">${escapeHtml(buf.pageTitle || "Captured media")}</div>
        <div class="video-quality">${formatBytes(totalBytes)} across ${sbs.length} track${sbs.length === 1 ? "" : "s"}</div>
        <div class="video-actions"></div>
      `;
      const actions = card.querySelector(".video-actions");
      for (const sb of sbs) {
        if (!sb.bytes) continue;
        const btn = document.createElement("button");
        btn.className = "btn btn-download";
        const trackLabel = sb.mime.split(";")[0].split("/")[1] || "track";
        btn.textContent = `Save ${trackLabel} (${formatBytes(sb.bytes)})`;
        btn.addEventListener("click", () => saveMseBuffer(buf, sb, btn));
        actions.appendChild(btn);
      }
      container.appendChild(card);
    }
  }

  function saveMseBuffer(buf, sb, btn) {
    if (!currentTabId) return;
    const originalText = btn.textContent;
    btn.disabled = true;
    btn.textContent = "Preparing...";
    chrome.runtime.sendMessage(
      { type: "MSE_EXPORT", tabId: currentTabId, msId: buf.msId, sbId: sb.id },
      (resp) => {
        if (!resp?.ok || !resp.url) {
          btn.disabled = false;
          btn.textContent = originalText;
          showToast("Export failed: " + (resp?.error || "unknown"));
          return;
        }
        const baseName = (currentPageTitle || "captured")
          .replace(/[^\w\-. ]+/g, "_")
          .slice(0, 80) || "captured";
        const filename = `${baseName}.${mimeToExt(sb.mime || resp.mime)}`;
        chrome.downloads.download(
          { url: resp.url, filename, saveAs: true },
          () => {
            btn.disabled = false;
            btn.textContent = originalText;
            showToast(`Saved ${formatBytes(resp.size)}`);
          }
        );
      }
    );
  }

  // --- Cookie export (Netscape jar for yt-dlp) ---
  async function exportCookiesForCurrentPage() {
    if (!currentPageUrl) {
      showToast("No active page");
      return;
    }
    try {
      const result = await window.CookieExport.exportForUrl(currentPageUrl);
      const blob = new Blob([result.netscape], { type: "text/plain" });
      const url = URL.createObjectURL(blob);
      chrome.downloads.download({
        url,
        filename: `${result.platform}_cookies.txt`,
        saveAs: true,
      }, () => setTimeout(() => URL.revokeObjectURL(url), 60000));
      showToast(`${result.count} cookies → cookies.txt`);
    } catch (e) {
      showToast("Cookie export: " + (e.message || String(e)));
    }
  }

  // --- Recording mode ---
  const btnRecord = document.getElementById("btn-record");
  const recordLabel = document.getElementById("record-label");
  const recordHint = document.getElementById("record-hint");
  let recording = false;
  let recordingTabId = null;

  function setRecordingUi(active, hint) {
    recording = active;
    recordLabel.textContent = active ? "Stop" : "Record";
    btnRecord.classList.toggle("active", active);
    if (hint) recordHint.textContent = hint;
  }

  function startRecording(trim) {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tabId = tabs[0]?.id;
      if (!tabId) return;
      if (!recording) {
        recordingTabId = tabId;
        chrome.runtime.sendMessage(
          { type: "START_RECORDING", tabId, trim: !!trim },
          (r) => {
            if (r?.status === "ok") {
              setRecordingUi(true, trim ? "Pick start/end on the page..." : "Recording... click Stop when done.");
            } else {
              showToast("Record failed: " + (r?.error || "unknown"));
            }
          }
        );
      } else {
        chrome.runtime.sendMessage({ type: "STOP_RECORDING", tabId: recordingTabId || tabId });
        setRecordingUi(false, "Stopping...");
      }
    });
  }

  btnRecord.addEventListener("click", () => startRecording(false));
  document.getElementById("btn-record-trim")?.addEventListener("click", () => startRecording(true));

  // Listen for record status updates via session storage
  chrome.storage.session.onChanged.addListener((changes) => {
    if (!changes.record_status) return;
    const msg = changes.record_status.newValue;
    if (!msg) return;
    switch (msg.status) {
      case "started":
        setRecordingUi(true, `Recording (${msg.mimeType})`);
        break;
      case "chunk":
        recordHint.textContent = `Recording... ${formatBytes(msg.total)}`;
        break;
      case "done": {
        const baseName = sanitizeFilename(currentPageTitle || "recording");
        const filename = `${baseName || "recording"}.${msg.ext || "webm"}`;
        chrome.downloads.download({ url: msg.url, filename, saveAs: true });
        setRecordingUi(false, `Saved ${formatBytes(msg.size)}`);
        break;
      }
      case "error":
        setRecordingUi(false, "Error: " + (msg.error || "unknown"));
        break;
      case "already-active":
        showToast("Already recording in this tab");
        break;
    }
  });

  chrome.storage.session.onChanged.addListener((changes) => {
    if (changes.tabVideos) loadVideos();
  });

  // Reattach to any in-flight HLS/DASH download spawned in a previous popup
  // session. Offscreen worker keeps writing to chrome.storage.session, so we
  // can pick up where we left off.
  function reattachLiveJob() {
    chrome.storage.session.get(null, (all) => {
      if (!all) return;
      for (const key of Object.keys(all)) {
        if (!key.startsWith("hls_dl_")) continue;
        const msg = all[key];
        if (!msg || msg.status === "done" || msg.status === "error" || msg.status === "cancelled") {
          chrome.storage.session.remove(key);
          continue;
        }
        const jobId = key.substring("hls_dl_".length);
        bgJobId = jobId;
        hlsRunning = true;
        hlsModal.style.display = "flex";
        hlsModalTitle.textContent = (msg.kind === "dash" ? "DASH" : "M3U8") + " Video Downloader";
        applyJobStatus(msg);
        attachJobListener(jobId);
        break;
      }
    });
  }

  function reattachYtdlpJob() {
    chrome.storage.session.get(null, (all) => {
      if (!all) return;
      for (const key of Object.keys(all)) {
        if (!key.startsWith("dl_")) continue;
        const msg = all[key];
        if (!msg || msg.status === "finished" || msg.status === "error" || msg.status === "cancelled" || msg.status === "disconnected") {
          chrome.storage.session.remove(key);
          continue;
        }
        const dlId = key.substring("dl_".length);
        currentDownloadId = dlId;

        // Show progress UI and seed initial stats
        progressTitle.textContent = msg.filename || "Downloading...";
        progressBar.style.width = msg.percent || "0%";
        progressPercent.textContent = msg.percent || "0%";
        progressSpeed.textContent = msg.speed || "";
        progressEta.textContent = msg.eta ? `ETA ${msg.eta}` : "";
        downloadProgress.style.display = "block";

        startProgressListener(dlId);
        break;
      }
    });
  }

  checkYtdlp();
  loadVideos();
  reattachLiveJob();
  reattachYtdlpJob();
})();
