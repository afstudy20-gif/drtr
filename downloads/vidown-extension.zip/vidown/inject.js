// Vidown - Page Context Interceptor
// Injected into the MAIN world to intercept fetch, XHR, and MediaSource APIs
// Also parses API response bodies to extract video URLs from JSON
(function () {
  "use strict";

  const VIDOWN_MSG = "VIDOWN_MEDIA_DETECTED";
  const seen = new Map();

  const MEDIA_PATTERNS = [
    { regex: /\.m3u8(\?|#|$)/i, type: "hls" },
    { regex: /\.mpd(\?|#|$)/i, type: "dash" },
    { regex: /\.mp4(\?|#|$)/i, type: "mp4" },
    { regex: /\.webm(\?|#|$)/i, type: "webm" },
    { regex: /\.m4v(\?|#|$)/i, type: "mp4" },
    { regex: /\.ogv(\?|#|$)/i, type: "webm" },
    { regex: /\.flv(\?|#|$)/i, type: "flv" },
    { regex: /\.mkv(\?|#|$)/i, type: "mkv" },
    { regex: /\.(vtt|webvtt|srt|ttml|dfxp)(\?|#|$)/i, type: "subtitle" },
    { regex: /\.m4s(\?|#|$)/i, type: "dash-segment" },
  ];

  // CDN host patterns that serve video content
  const CDN_PATTERNS = [
    /bilivideo\.(com|cn|net)/i,
    /akamaized\.net.*upgcxcode/i,
    /upos-[a-z]+-mirror/i,
    /\.cloudfront\.net\/.*\.(mp4|webm|m3u8|ts)/i,
    /\.akamaihd\.net\/.*video/i,
    /vod[a-z]*\d*\.[a-z]+\.(com|net)/i,
    /\.pstatp\.com\/.*video/i,
    /\.tiktokcdn\.com\/.*video/i,
    /\.twimg\.com\/.*video/i,
    /video-weaver\..+\.hls\.ttvnw\.net/i,
    /\.mcdn\.net/i,
    /\/(subtitles?|captions?|tracks?)\/.*\.(vtt|srt|ttml|dfxp)(\?|#|$)/i,
  ];

  // URLs to completely ignore
  const BLACKLIST = [
    /\/generate_204/i,
    /\/api\/stats/i,
    /\/log_event/i,
    /\/ptracking/i,
    /\/qoe/i,
    /\/heartbeat/i,
    /\/alive/i,
    /\/ping/i,
    /googlevideo\.com\/initplayback/i,
    /\.googlesyndication\./i,
    /\.doubleclick\./i,
  ];

  const SUBTITLE_KEYS = new Set([
    "subtitle", "subtitles", "caption", "captions", "track", "tracks",
    "vtt", "srt", "subtitle_url", "subtitleUrl", "caption_url", "captionUrl",
  ]);

  function isBlacklisted(url) {
    return BLACKLIST.some((r) => r.test(url));
  }

  // YouTube SABR segments return ~31KB chunks, not full videos
  function isYouTubeSegment(url) {
    if (!/googlevideo\.com\/videoplayback/i.test(url)) return false;
    return /[?&](sabr=1|alr=yes|rn=\d)/i.test(url);
  }

  // API endpoints that return video URLs in JSON
  const API_PATTERNS = [
    /\/x\/player\/(wbi\/)?playurl/i,          // Bilibili
    /\/pgc\/player\/web\/playurl/i,            // Bilibili anime/movies
    /\/bstar\/web\/pgc\/player\/playurl/i,     // Bilibili.tv international
    /\/intl\/gateway\/web\/playurl/i,           // Bilibili.tv international
    /player\.vimeo\.com\/video\/\d+\/config/i, // Vimeo player config
    /vimeo\.com\/.*\/config(\?|$)/i,           // Vimeo embed config
    /\/api\/v\d+\/.*video/i,                    // Generic video APIs
    /\/manifest\.(m3u8|mpd|json)/i,            // Generic manifests
    /player.*\.json/i,                          // Various players
    /\/dash\//i,                                // DASH endpoints
    /\/hls\//i,                                 // HLS endpoints
  ];

  // Skip tiny segment files from display
  const SEGMENT_ONLY = [/\.ts(\?|#|$)/i];

  function isSegmentOnly(url) {
    return SEGMENT_ONLY.some((r) => r.test(url));
  }

  function isLikelyAudioUrl(url) {
    try {
      const u = new URL(url, location.href);
      const text = `${u.pathname} ${u.searchParams.get("mime") || ""} ${u.searchParams.get("codecs") || ""}`.toLowerCase();
      return /(^|[/?_.=&-])(audio|aac|m4a|mp3|mp4a|opus|vorbis)([/?_.=&-]|$)/i.test(text)
        || /(^|[/?_.=&-])a\d{1,3}([/?_.=&-]|$)/i.test(text);
    } catch {
      return /(^|[/?_.=&-])(audio|aac|m4a|mp3|mp4a|opus|vorbis)([/?_.=&-]|$)/i.test(String(url).toLowerCase());
    }
  }

  function report(url, type, quality) {
    if (!url || typeof url !== "string") return;
    const previous = seen.get(url);
    if (previous === type) return;
    seen.set(url, type);
    window.postMessage(
      { type: VIDOWN_MSG, url, mediaType: type, quality, source: "inject" },
      "*"
    );
  }

  // JW Player analytics ping carries manifest URL in `mu=` param.
  function tryExtractJwManifest(url) {
    try {
      if (!/jwpltx\.com\/.+ping\.gif/i.test(url)) return;
      const u = new URL(url);
      const mu = u.searchParams.get("mu");
      if (!mu) return;
      const manifest = decodeURIComponent(mu);
      if (!/^https?:\/\//i.test(manifest)) return;
      let type = "hls";
      if (/\.mpd(\?|#|$)/i.test(manifest)) type = "dash";
      else if (/\.(mp4|webm)(\?|#|$)/i.test(manifest)) type = "mp4";
      report(manifest, type, "jw-ping");
    } catch {}
  }

  function checkUrl(url) {
    if (!url || typeof url !== "string") return;
    try {
      url = new URL(url, location.href).href;
    } catch {
      return;
    }
    tryExtractJwManifest(url);
    if (seen.has(url)) return;
    if (isBlacklisted(url)) return;
    if (isYouTubeSegment(url)) return;

    try {
      const mime = (new URL(url).searchParams.get("mime") || "").toLowerCase();
      if (mime.startsWith("audio/")) {
        report(url, "audio", mime);
        return;
      }
      if (mime.includes("video/mp4")) {
        report(url, "mp4", mime);
        return;
      }
      if (mime.includes("video/webm")) {
        report(url, "webm", mime);
        return;
      }
    } catch {}

    if (isLikelyAudioUrl(url)) {
      report(url, "audio", "audio-url");
      return;
    }

    // Filename-keyword detection (master.txt, playlist.txt, /cdn/hls/<hash>/)
    if (/\.(vtt|webvtt|srt|ttml|dfxp)(\?|#|$)/i.test(url)) {
      report(url, "subtitle", "subtitle");
      return;
    }

    // Filename-keyword detection (master.txt, playlist.txt, /cdn/hls/<hash>/)
    if (/\/cdn\/hls\/[a-f0-9]+\//i.test(url) ||
        /\/(master|playlist|index|manifest)\.(txt|m3u8?)(\?|#|$)/i.test(url)) {
      report(url, "hls", "keyword");
      return;
    }
    if (/\/(master|playlist|index|manifest)\.mpd(\?|#|$)/i.test(url)) {
      report(url, "dash", "keyword");
      return;
    }

    // Check media file patterns
    for (const p of MEDIA_PATTERNS) {
      if (p.regex.test(url)) {
        if (p.type === "dash-segment") return;
        if (isSegmentOnly(url)) return;
        report(url, p.type);
        return;
      }
    }

    // Check CDN host patterns
    for (const cdn of CDN_PATTERNS) {
      if (cdn.test(url)) {
        let type = "video";
        if (/\.m3u8/i.test(url)) type = "hls";
        else if (/\.mpd/i.test(url)) type = "dash";
        else if (/\.m4s/i.test(url)) return;
        else if (/\.mp4/i.test(url)) type = "mp4";
        else if (/\.webm/i.test(url)) type = "webm";
        else if (/\.flv/i.test(url)) type = "flv";
        report(url, type);
        return;
      }
    }
  }

  // --- Deep scan JSON responses for video URLs ---

  function isApiUrl(url) {
    return API_PATTERNS.some((r) => r.test(url));
  }

  function extractUrlsFromJson(obj, depth) {
    if (depth > 8 || !obj) return;
    const results = [];

    if (typeof obj === "string") {
      // Check if it looks like a video URL
      if (
        (obj.startsWith("http") || obj.startsWith("//")) &&
        (MEDIA_PATTERNS.some((p) => p.regex.test(obj)) ||
          CDN_PATTERNS.some((p) => p.test(obj)) ||
          /\.(vtt|webvtt|srt|ttml|dfxp)(\?|#|$)/i.test(obj))
      ) {
        results.push(obj);
      }
      return results;
    }

    if (Array.isArray(obj)) {
      for (const item of obj) {
        results.push(...extractUrlsFromJson(item, depth + 1));
      }
      return results;
    }

    if (typeof obj === "object") {
      // Look for known video URL keys
      const urlKeys = [
        "url",
        "baseUrl",
        "base_url",
        "backupUrl",
        "backup_url",
        "src",
        "source",
        "file",
        "video_url",
        "playUrl",
        "play_url",
        "stream_url",
        "download_url",
        "media_url",
        "subtitle",
        "subtitles",
        "caption",
        "captions",
        "track",
        "tracks",
        "vtt",
        "srt",
        "subtitle_url",
        "subtitleUrl",
        "caption_url",
        "captionUrl",
      ];

      for (const key of Object.keys(obj)) {
        const val = obj[key];

        if ((urlKeys.includes(key) || SUBTITLE_KEYS.has(key)) && typeof val === "string") {
          if (val.startsWith("http") || val.startsWith("//")) {
            if (SUBTITLE_KEYS.has(key) || /\.(vtt|webvtt|srt|ttml|dfxp)(\?|#|$)/i.test(val)) {
              report(val.startsWith("//") ? "https:" + val : val, "subtitle", key);
            } else {
              results.push(val);
            }
          }
        } else if (Array.isArray(val) && (urlKeys.includes(key) || SUBTITLE_KEYS.has(key))) {
          // backupUrl can be an array of strings
          for (const item of val) {
            if (typeof item === "string" && (item.startsWith("http") || item.startsWith("//"))) {
              if (SUBTITLE_KEYS.has(key) || /\.(vtt|webvtt|srt|ttml|dfxp)(\?|#|$)/i.test(item)) {
                report(item.startsWith("//") ? "https:" + item : item, "subtitle", key);
              } else {
                results.push(item);
              }
            }
          }
        }

        // Recurse into nested objects
        if (typeof val === "object" && val !== null) {
          results.push(...extractUrlsFromJson(val, depth + 1));
        }
      }

      // Extract quality info from Bilibili DASH format
      if (obj.video && Array.isArray(obj.video)) {
        for (const v of obj.video) {
          const vUrl = v.baseUrl || v.base_url || v.url;
          if (vUrl) {
            const quality = [];
            if (v.width && v.height) quality.push(`${v.width}x${v.height}`);
            else if (v.id) quality.push(`quality:${v.id}`);
            if (v.codecs) quality.push(v.codecs);
            if (v.bandwidth)
              quality.push(
                `${(v.bandwidth / 1000000).toFixed(1)}Mbps`
              );
            report(vUrl, "mp4", quality.join(" "));
          }
        }
      }
      if (obj.audio && Array.isArray(obj.audio)) {
        for (const a of obj.audio) {
          const aUrl = a.baseUrl || a.base_url || a.url;
          if (aUrl) {
            report(aUrl, "audio", a.codecs || "audio");
          }
        }
      }

      // Bilibili durl format (FLV/MP4 direct)
      if (obj.durl && Array.isArray(obj.durl)) {
        for (const d of obj.durl) {
          if (d.url) {
            const size = d.size
              ? `${(d.size / 1048576).toFixed(1)}MB`
              : "";
            report(d.url, "mp4", size);
          }
        }
      }

      // Vimeo player config: request.files.{progressive,hls,dash}
      const vimeoFiles = obj?.request?.files || obj?.files;
      if (vimeoFiles && typeof vimeoFiles === "object") {
        if (Array.isArray(vimeoFiles.progressive)) {
          for (const p of vimeoFiles.progressive) {
            if (p.url) {
              const q = [
                p.quality || (p.height ? `${p.height}p` : ""),
                p.fps ? `${p.fps}fps` : "",
                p.width && p.height ? `${p.width}x${p.height}` : "",
              ].filter(Boolean).join(" ");
              report(p.url, "mp4", q || "vimeo");
            }
          }
        }
        if (vimeoFiles.hls?.cdns) {
          for (const cdn of Object.values(vimeoFiles.hls.cdns)) {
            if (cdn?.url) report(cdn.url, "hls", "vimeo HLS");
            else if (cdn?.json_url) report(cdn.json_url, "hls", "vimeo HLS");
          }
          if (vimeoFiles.hls.default_cdn) {
            const def = vimeoFiles.hls.cdns[vimeoFiles.hls.default_cdn];
            if (def?.url) report(def.url, "hls", "vimeo HLS default");
          }
        }
        if (vimeoFiles.dash?.cdns) {
          for (const cdn of Object.values(vimeoFiles.dash.cdns)) {
            if (cdn?.url) report(cdn.url, "dash", "vimeo DASH");
            else if (cdn?.json_url) report(cdn.json_url, "dash", "vimeo DASH");
          }
        }
      }
    }

    return results;
  }

  function parseAndExtract(text, requestUrl) {
    try {
      const json = JSON.parse(text);
      const urls = extractUrlsFromJson(json, 0);
      for (const u of urls) {
        let fullUrl = u;
        if (u.startsWith("//")) fullUrl = "https:" + u;
        if (isBlacklisted(fullUrl) || isYouTubeSegment(fullUrl)) continue;
        checkUrl(fullUrl);
        // Also report CDN URLs that checkUrl might classify as generic "video"
        if (!seen.has(fullUrl)) {
          report(fullUrl, "video");
        }
      }
    } catch {
      // Not JSON, check if it's an M3U8 playlist
      if (text.includes("#EXTM3U") || text.includes("#EXT-X-")) {
        report(requestUrl, "hls");
      }
      // Check if it's an MPD manifest
      if (text.includes("<MPD") || text.includes("urn:mpeg:dash")) {
        report(requestUrl, "dash");
      }
    }
  }

  // --- Intercept XMLHttpRequest ---

  const origXHROpen = XMLHttpRequest.prototype.open;
  const origXHRSend = XMLHttpRequest.prototype.send;

  XMLHttpRequest.prototype.open = function (method, url) {
    this._vidown_url = typeof url === "string" ? url : String(url);
    checkUrl(this._vidown_url);
    return origXHROpen.apply(this, arguments);
  };

  XMLHttpRequest.prototype.send = function () {
    const xhr = this;
    const url = xhr._vidown_url;

    if (url && isApiUrl(url)) {
      xhr.addEventListener("load", function () {
        try {
          if (xhr.responseType === "" || xhr.responseType === "text") {
            parseAndExtract(xhr.responseText, url);
          } else if (xhr.responseType === "json" && xhr.response) {
            const urls = extractUrlsFromJson(xhr.response, 0);
            for (const u of urls) {
              let fullUrl = u.startsWith("//") ? "https:" + u : u;
              checkUrl(fullUrl);
              if (!seen.has(fullUrl)) report(fullUrl, "video");
            }
          }
        } catch {
          // Ignore parse errors
        }
      });
    }

    return origXHRSend.apply(this, arguments);
  };

  // --- Intercept fetch with response body reading ---

  const origFetch = window.fetch;
  window.fetch = function (input, init) {
    let url;
    if (typeof input === "string") url = input;
    else if (input instanceof Request) url = input.url;
    else if (input?.url) url = input.url;

    if (url) checkUrl(url);

    const result = origFetch.apply(this, arguments);

    // If this is a known API endpoint, intercept the response
    if (url && isApiUrl(url)) {
      return result.then((response) => {
        // Clone the response so original consumer can still read it
        const clone = response.clone();
        clone
          .text()
          .then((text) => parseAndExtract(text, url))
          .catch(() => {});
        return response;
      });
    }

    return result;
  };

  // --- Intercept URL.createObjectURL for MediaSource ---

  const origCreateObjectURL = URL.createObjectURL;
  URL.createObjectURL = function (obj) {
    const blobUrl = origCreateObjectURL.apply(this, arguments);
    if (typeof MediaSource !== "undefined" && obj instanceof MediaSource) {
      report(blobUrl, "blob-mediasource");
    }
    return blobUrl;
  };

  // --- hls.js / Shaka / dash.js hooks: scan window for player instances and
  // pull manifest URL out of their internal state. Many sites lazy-init
  // players on user click and their fetches happen inside Web Workers that
  // bypass main-world fetch hooks. ---

  function pollForPlayerInstances() {
    // hls.js attaches as window.Hls (constructor) and instances are usually
    // assigned to ad-hoc variables. Most sites also attach to MediaElement
    // via .__hls or .hls property.
    document.querySelectorAll("video").forEach((v) => {
      const hls = v.__hls || v.hls || v._hls;
      if (hls && hls.url) {
        report(hls.url, "hls", "hls.js");
      }
      if (hls && hls.levels && Array.isArray(hls.levels)) {
        for (const lvl of hls.levels) {
          if (lvl?.url && lvl.url[0]) report(lvl.url[0], "hls", `hls.js variant ${lvl.height || ""}`);
        }
      }
      // Shaka player
      const shaka = v.__shaka || v.shakaPlayer;
      if (shaka && typeof shaka.getAssetUri === "function") {
        try {
          const uri = shaka.getAssetUri();
          if (uri) {
            const t = /\.m3u8/i.test(uri) ? "hls" : (/\.mpd/i.test(uri) ? "dash" : "video");
            report(uri, t, "shaka");
          }
        } catch {}
      }
      // dash.js
      const dashjs = v.__dashjs || v._dashjs;
      if (dashjs && typeof dashjs.getSource === "function") {
        try {
          const src = dashjs.getSource();
          if (src) report(src, "dash", "dash.js");
        } catch {}
      }
    });
  }

  // Poll a few times after page load — players init asynchronously
  let pollCount = 0;
  const pollTimer = setInterval(() => {
    pollForPlayerInstances();
    pollCount++;
    if (pollCount >= 20) clearInterval(pollTimer);
  }, 1500);

  // --- Intercept HTMLMediaElement.src setter ---

  function interceptSrcProperty(proto) {
    const descriptor = Object.getOwnPropertyDescriptor(proto, "src");
    if (!descriptor || !descriptor.set) return false;

    const origSet = descriptor.set;
    Object.defineProperty(proto, "src", {
      set: function (value) {
        checkUrl(value);
        return origSet.call(this, value);
      },
      get: descriptor.get,
      configurable: true,
      enumerable: true,
    });
    return true;
  }

  if (!interceptSrcProperty(HTMLVideoElement.prototype)) {
    if (!interceptSrcProperty(HTMLAudioElement.prototype)) {
      interceptSrcProperty(HTMLMediaElement.prototype);
    }
  }

  // --- MSE Buffer Capture ---
  // Many sites stream DRM-free media into MediaSource via Blob:// URLs and
  // never expose a manifest URL we can sniff. By proxying MediaSource +
  // SourceBuffer.appendBuffer we retain a copy of every chunk in
  // page-context state so the popup can offer a "Save buffer" action.
  try {
    const origMS = window.MediaSource;
    if (typeof origMS === "function" && origMS.prototype && origMS.prototype.addSourceBuffer) {
      const buffers = new Map(); // msId -> entry
      let msCounter = 0;

      const PatchedMS = new Proxy(origMS, {
        construct(target, args) {
          const inst = new target(...args);
          const msId = ++msCounter;
          const entry = {
            id: msId,
            sourceBuffers: new Map(),
            live: false,
            startedAt: Date.now(),
            pageUrl: location.href,
            pageTitle: document.title,
          };
          buffers.set(msId, entry);

          let sbCounter = 0;
          const origAdd = inst.addSourceBuffer.bind(inst);
          inst.addSourceBuffer = function (mime) {
            const sb = origAdd(mime);
            const sbId = ++sbCounter;
            const sbEntry = {
              id: sbId,
              mime: String(mime || ""),
              chunks: [],
              totalBytes: 0,
            };
            entry.sourceBuffers.set(sbId, sbEntry);
            const origAppend = sb.appendBuffer.bind(sb);
            sb.appendBuffer = function (data) {
              try {
                if (data && (data.byteLength > 0)) {
                  // Copy out so the original ArrayBuffer can be re-used by
                  // the decoder without our state becoming garbage.
                  const view = ArrayBuffer.isView(data) ? data : new Uint8Array(data);
                  const copy = view.buffer.slice(
                    view.byteOffset,
                    view.byteOffset + view.byteLength
                  );
                  sbEntry.chunks.push(copy);
                  sbEntry.totalBytes += copy.byteLength;
                }
              } catch (_) { /* swallow — never break playback */ }
              return origAppend(data);
            };
            return sb;
          };

          inst.addEventListener("sourceended", () => {
            entry.live = inst.duration === Infinity;
            entry.endedAt = Date.now();
          });

          // Tell the content script a new buffer started so the popup can
          // surface it even before any chunks land.
          window.postMessage({
            type: "VIDOWN_MSE_REGISTER",
            msId,
            pageUrl: entry.pageUrl,
            pageTitle: entry.pageTitle,
          }, "*");

          return inst;
        },
      });

      // Replace the global so player libraries pick up the proxy.
      window.MediaSource = PatchedMS;

      // Snapshot helper: returns a serializable summary of every captured
      // buffer in this page context.
      window.__vidownMSESnapshot = function () {
        const out = [];
        for (const [msId, e] of buffers) {
          const sbs = [];
          for (const [sbId, sb] of e.sourceBuffers) {
            sbs.push({
              id: sbId,
              mime: sb.mime,
              chunkCount: sb.chunks.length,
              bytes: sb.totalBytes,
            });
          }
          out.push({
            msId,
            sourceBuffers: sbs,
            live: e.live,
            startedAt: e.startedAt,
            endedAt: e.endedAt || null,
            pageTitle: e.pageTitle,
          });
        }
        return out;
      };

      // Materialize a captured stream as a Blob URL. The caller is responsible
      // for revoking it after the download finishes.
      window.__vidownMSEExport = function (msId, sbId) {
        const e = buffers.get(msId);
        if (!e) return null;
        const sb = e.sourceBuffers.get(sbId);
        if (!sb || sb.chunks.length === 0) return null;
        const mime = sb.mime || "video/mp4";
        const blob = new Blob(sb.chunks, { type: mime });
        return {
          url: URL.createObjectURL(blob),
          size: blob.size,
          mime,
          live: e.live,
        };
      };

      // Drop a captured stream (after the user saved it) so memory is freed.
      window.__vidownMSEDrop = function (msId, sbId) {
        const e = buffers.get(msId);
        if (!e) return false;
        if (sbId == null) {
          buffers.delete(msId);
          return true;
        }
        return e.sourceBuffers.delete(sbId);
      };
    }
  } catch (_) { /* ignore — never break the page */ }

  // --- Intercept source element src ---

  const sourceDescriptor = Object.getOwnPropertyDescriptor(
    HTMLSourceElement.prototype,
    "src"
  );
  if (sourceDescriptor && sourceDescriptor.set) {
    const origSourceSet = sourceDescriptor.set;
    Object.defineProperty(HTMLSourceElement.prototype, "src", {
      set: function (value) {
        checkUrl(value);
        return origSourceSet.call(this, value);
      },
      get: sourceDescriptor.get,
      configurable: true,
      enumerable: true,
    });
  }
})();
