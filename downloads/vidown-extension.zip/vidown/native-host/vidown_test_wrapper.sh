#!/bin/bash
echo "==== $(date) called by Chrome ====" >> "$HOME/vidown_test.log"
echo "USER=$(id -un) PWD=$(pwd) PATH=$PATH" >> "$HOME/vidown_test.log"
ls -la "$HOME" >> "$HOME/vidown_test.log" 2>&1
# Read length-prefix
LEN_BYTES=$(dd bs=4 count=1 2>/dev/null | od -An -tu4 | tr -d ' ')
echo "LEN=$LEN_BYTES" >> "$HOME/vidown_test.log"
dd bs=$LEN_BYTES count=1 2>/dev/null > "$HOME/vidown_test_in.bin"
echo "got input" >> "$HOME/vidown_test.log"
# Send fixed response
RESP='{"status":"ok","probe":"test_wrapper"}'
RLEN=${#RESP}
printf "$(printf '\\x%02x\\x%02x\\x%02x\\x%02x' $((RLEN & 0xff)) $((RLEN>>8 & 0xff)) $((RLEN>>16 & 0xff)) $((RLEN>>24 & 0xff)))$RESP"
echo "sent response, exiting" >> "$HOME/vidown_test.log"
