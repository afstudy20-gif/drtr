#!/usr/bin/env python3
"""Vidown native messaging host.

This process bridges the browser extension to yt-dlp over Chrome's native
messaging protocol. Stdout must contain only framed JSON messages; diagnostics
go to stderr.
"""

from __future__ import annotations

import json
import os
import signal
import struct
import sys
import threading
import traceback
from pathlib import Path
from typing import Any

# On macOS, GUI apps launched by Chrome do not inherit the shell's PATH.
# Inject common Homebrew and MacPorts bin directories so yt-dlp can locate ffmpeg.
if sys.platform == "darwin":
    for p in ["/opt/homebrew/bin", "/usr/local/bin"]:
        if p not in os.environ.get("PATH", ""):
            os.environ["PATH"] = p + os.pathsep + os.environ.get("PATH", "")


# Save the original binary stdout buffer for Chrome Native Messaging
REAL_STDOUT_BUFFER = sys.stdout.buffer

# Redirect sys.stdout to sys.stderr so any stray prints (e.g. from yt-dlp) do not corrupt the Chrome protocol
sys.stdout = sys.stderr

active_downloads: dict[str, threading.Event] = {}


def log(*parts: object) -> None:
    print("[vidown_host]", *parts, file=sys.stderr, flush=True)


def send_message(message: dict[str, Any]) -> None:
    payload = json.dumps(message, ensure_ascii=False).encode("utf-8")
    REAL_STDOUT_BUFFER.write(struct.pack("<I", len(payload)))
    REAL_STDOUT_BUFFER.write(payload)
    REAL_STDOUT_BUFFER.flush()


def read_message() -> dict[str, Any] | None:
    raw_length = sys.stdin.buffer.read(4)
    if not raw_length:
        return None
    if len(raw_length) != 4:
        raise EOFError("Incomplete native messaging length header")

    message_length = struct.unpack("<I", raw_length)[0]
    if message_length <= 0:
        return {}
    raw_message = sys.stdin.buffer.read(message_length)
    if len(raw_message) != message_length:
        raise EOFError("Incomplete native messaging payload")
    return json.loads(raw_message.decode("utf-8"))


def import_ytdlp():
    try:
        import yt_dlp  # type: ignore

        return yt_dlp, None
    except Exception as exc:
        return None, exc


def handle_check() -> None:
    yt_dlp, error = import_ytdlp()
    if error:
        send_message({
            "status": "error",
            "error": "yt-dlp is not installed. Run: python3 -m pip install -U yt-dlp",
            "details": str(error),
            "python": sys.executable,
        })
        return

    version = getattr(getattr(yt_dlp, "version", None), "__version__", "unknown")
    send_message({
        "status": "ok",
        "version": version,
        "python": sys.executable,
    })


def format_filesize(value: Any) -> int | None:
    try:
        if value is None:
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def format_label(fmt: dict[str, Any]) -> str:
    height = fmt.get("height")
    ext = fmt.get("ext") or ""
    note = fmt.get("format_note") or fmt.get("resolution") or ""
    fps = fmt.get("fps")
    parts = []
    if height:
        parts.append(f"{height}p")
    elif note:
        parts.append(str(note))
    else:
        parts.append(str(fmt.get("format_id", "format")))
    if fps:
        parts.append(f"{fps}fps")
    if ext:
        parts.append(str(ext))
    return " ".join(parts)


def format_kind(fmt: dict[str, Any]) -> str:
    vcodec = fmt.get("vcodec")
    acodec = fmt.get("acodec")
    has_video = bool(vcodec and vcodec != "none")
    has_audio = bool(acodec and acodec != "none")
    if has_video and has_audio:
        return "video+audio"
    if has_video:
        return "video"
    if has_audio:
        return "audio"
    return "unknown"


def simplify_format(fmt: dict[str, Any]) -> dict[str, Any]:
    filesize = format_filesize(fmt.get("filesize") or fmt.get("filesize_approx"))
    return {
        "id": str(fmt.get("format_id", "")),
        "label": format_label(fmt),
        "kind": format_kind(fmt),
        "ext": fmt.get("ext"),
        "height": fmt.get("height"),
        "width": fmt.get("width"),
        "fps": fmt.get("fps"),
        "vcodec": fmt.get("vcodec"),
        "acodec": fmt.get("acodec"),
        "filesize": filesize,
    }


def handle_formats(url: str | None) -> None:
    if not url:
        send_message({"status": "error", "error": "No URL provided"})
        return

    yt_dlp, error = import_ytdlp()
    if error:
        send_message({"status": "error", "error": "yt-dlp not installed"})
        return

    try:
        options = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            "noplaylist": True,
        }
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=False)

        if not info:
            send_message({"status": "error", "error": "Could not extract video info"})
            return

        formats = [
            simplify_format(fmt)
            for fmt in info.get("formats", [])
            if fmt.get("format_id")
        ]
        formats = [fmt for fmt in formats if fmt["kind"] != "unknown"]

        send_message({
            "status": "ok",
            "title": info.get("title") or "",
            "duration": info.get("duration"),
            "thumbnail": info.get("thumbnail"),
            "formats": formats,
        })
    except Exception as exc:
        log("formats failed:", traceback.format_exc())
        send_message({"status": "error", "error": str(exc)})


def safe_output_template(output_dir: str | None) -> str:
    if output_dir:
        base = Path(output_dir).expanduser()
    else:
        base = Path.home() / "Downloads"
    base.mkdir(parents=True, exist_ok=True)
    return str(base / "%(title).200B [%(id)s].%(ext)s")


def safe_playlist_template(output_dir: str | None) -> str:
    """Output template for playlist/channel downloads.

    Groups videos in a subdirectory named after the playlist and prefixes
    each file with a zero-padded index so the order on disk matches the
    source ordering.
    """
    if output_dir:
        base = Path(output_dir).expanduser()
    else:
        base = Path.home() / "Downloads"
    base.mkdir(parents=True, exist_ok=True)
    return str(
        base
        / "%(playlist_title,playlist_id|Playlist)S"
        / "%(playlist_index)03d - %(title).180B [%(id)s].%(ext)s"
    )


def percent_text(value: Any) -> str:
    try:
        return f"{float(value):.1f}%"
    except (TypeError, ValueError):
        return "0%"


def format_speed(speed: Any) -> str:
    try:
        speed = float(speed)
    except (TypeError, ValueError):
        return ""
    units = ["B/s", "KB/s", "MB/s", "GB/s"]
    idx = 0
    while speed >= 1024 and idx < len(units) - 1:
        speed /= 1024
        idx += 1
    return f"{speed:.1f} {units[idx]}"


def sanitize_path_segment(name: str) -> str:
    """Strip characters that are unsafe in a file path on macOS/Linux/Windows."""
    bad = '/\\:*?"<>|\0'
    cleaned = "".join("_" if c in bad else c for c in name).strip(" .")
    return cleaned or "Playlist"


def parse_playlist_items(spec: str | None, total: int) -> list[int]:
    """Resolve a yt-dlp style playlist_items spec (e.g. '1,3-5,8') to 1-based indices.

    Falls back to the full range when spec is empty or unparseable.
    """
    if not spec:
        return list(range(1, total + 1))
    result: list[int] = []
    for chunk in spec.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            try:
                start_s, end_s = chunk.split("-", 1)
                start = int(start_s) if start_s else 1
                end = int(end_s) if end_s else total
                for i in range(max(1, start), min(total, end) + 1):
                    if i not in result:
                        result.append(i)
            except ValueError:
                continue
        else:
            try:
                i = int(chunk)
                if 1 <= i <= total and i not in result:
                    result.append(i)
            except ValueError:
                continue
    return result or list(range(1, total + 1))


def wrap_progress_hook(
    inner,
    playlist_index: int,
    playlist_total: int,
    playlist_title: str,
):
    """Inject playlist meta into yt-dlp info_dict so playlist_meta() picks it up."""

    def hook(data: dict[str, Any]) -> None:
        info = data.get("info_dict") or {}
        info["playlist_index"] = playlist_index
        info["n_entries"] = playlist_total
        info["playlist_title"] = playlist_title
        data["info_dict"] = info
        inner(data)

    return hook


def playlist_meta(data: dict[str, Any]) -> dict[str, Any]:
    """Extract playlist position fields from a progress hook payload."""
    info = data.get("info_dict") or {}
    meta: dict[str, Any] = {}
    idx = info.get("playlist_index")
    total = info.get("n_entries") or info.get("playlist_count")
    title = info.get("playlist_title") or info.get("playlist")
    if idx:
        meta["playlist_index"] = idx
    if total:
        meta["playlist_total"] = total
    if title:
        meta["playlist_title"] = title
    return meta


def progress_hook(download_id: str, cancelled: threading.Event):
    def hook(data: dict[str, Any]) -> None:
        if cancelled.is_set():
            raise KeyboardInterrupt("Download cancelled")

        status = data.get("status")
        if status == "downloading":
            filepath = data.get("filename", "")
            filename = os.path.basename(filepath) if filepath else ""
            payload = {
                "status": "downloading",
                "id": download_id,
                "filename": filename,
                "percent": percent_text(data.get("_percent_str", "0").strip().replace("%", "")),
                "speed": data.get("_speed_str") or format_speed(data.get("speed")),
                "eta": data.get("_eta_str") or data.get("eta") or "",
                "downloaded": data.get("downloaded_bytes", 0),
                "total": data.get("total_bytes") or data.get("total_bytes_estimate") or 0,
            }
            payload.update(playlist_meta(data))
            send_message(payload)
        elif status == "finished":
            payload = {
                "status": "processing",
                "id": download_id,
                "filename": data.get("filename", ""),
            }
            payload.update(playlist_meta(data))
            send_message(payload)

    return hook


def flat_extract_playlist(yt_dlp, url: str) -> dict[str, Any]:
    """Enumerate playlist entries without resolving each video.

    Uses ``extract_flat='in_playlist'`` so YouTube's playlist endpoint is hit
    only once. Returns an empty entry list rather than raising when the
    playlist has no resolvable items.
    """
    flat_opts = {
        "quiet": True,
        "no_warnings": True,
        "extract_flat": "in_playlist",
        "skip_download": True,
        "ignoreerrors": True,
    }
    with yt_dlp.YoutubeDL(flat_opts) as ydl:
        info = ydl.extract_info(url, download=False) or {}
    entries = [e for e in (info.get("entries") or []) if e and e.get("id")]
    return {
        "title": info.get("title") or info.get("playlist_title") or "Playlist",
        "entries": entries,
    }


def entry_video_url(entry: dict[str, Any]) -> str:
    """Resolve a flat-extract entry to a canonical watch URL."""
    return (
        entry.get("webpage_url")
        or entry.get("url")
        or f"https://www.youtube.com/watch?v={entry['id']}"
    )


def run_playlist_download(
    yt_dlp,
    url: str,
    build_single_options,
    output_dir: str | None,
    download_id: str,
    cancelled: threading.Event,
    playlist_items: str | None,
) -> dict[str, Any]:
    """Flat-extract the playlist, then download each entry as a single video.

    This sidesteps yt-dlp's playlist iteration, which YouTube can refuse
    even when the individual videos are accessible. Each video gets its own
    YoutubeDL invocation, and playlist meta is injected into the progress
    hook so the popup can render ``Video X/Y``.
    """
    flat = flat_extract_playlist(yt_dlp, url)
    entries = flat["entries"]
    if not entries:
        raise RuntimeError("Playlist has no accessible videos")

    playlist_title = flat["title"]
    total = len(entries)
    selected_indices = parse_playlist_items(playlist_items, total)

    base_dir = Path(output_dir).expanduser() if output_dir else Path.home() / "Downloads"
    target_dir = base_dir / sanitize_path_segment(playlist_title)
    target_dir.mkdir(parents=True, exist_ok=True)

    send_message({
        "status": "downloading",
        "id": download_id,
        "playlist_title": playlist_title,
        "playlist_index": 0,
        "playlist_total": total,
        "percent": "0%",
        "filename": f"Starting playlist ({len(selected_indices)} videos)...",
    })

    succeeded = 0
    failed = 0

    for idx in selected_indices:
        if cancelled.is_set():
            break

        entry = entries[idx - 1]
        video_url = entry_video_url(entry)

        item_tmpl = str(target_dir / f"{idx:03d} - %(title).180B [%(id)s].%(ext)s")
        per_opts = build_single_options(item_tmpl)
        per_opts["progress_hooks"] = [
            wrap_progress_hook(
                progress_hook(download_id, cancelled),
                playlist_index=idx,
                playlist_total=total,
                playlist_title=playlist_title,
            )
        ]

        try:
            with yt_dlp.YoutubeDL(per_opts) as ydl:
                ydl.extract_info(video_url, download=True)
            succeeded += 1
        except KeyboardInterrupt:
            raise
        except Exception as exc:
            failed += 1
            log(f"playlist item {idx} ({entry.get('id')}) failed:", exc)
            send_message({
                "status": "item_failed",
                "id": download_id,
                "playlist_index": idx,
                "playlist_total": total,
                "playlist_title": playlist_title,
                "video_id": entry.get("id"),
                "error": str(exc),
            })

    return {
        "playlist_title": playlist_title,
        "playlist_total": total,
        "succeeded": succeeded,
        "failed": failed,
    }


def handle_download(
    url: str | None,
    format_id: str | None,
    output_dir: str | None,
    download_id: str,
    audio_format: str | None = None,
    subs_only: bool | None = None,
    noplaylist: bool = True,
    playlist_items: str | None = None,
    write_subs: bool = False,
) -> None:
    if not url:
        send_message({"status": "error", "id": download_id, "error": "No URL provided"})
        return

    yt_dlp, error = import_ytdlp()
    if error:
        send_message({"status": "error", "id": download_id, "error": f"yt-dlp not installed: {error}"})
        return

    cancelled = threading.Event()
    active_downloads[download_id] = cancelled

    try:
        is_playlist_job = not noplaylist

        def build_single_video_options(outtmpl: str) -> dict[str, Any]:
            opts: dict[str, Any] = {
                "format": format_id or "bv*+ba/bv*",
                "outtmpl": outtmpl,
                "noplaylist": True,
                "quiet": True,
                "no_warnings": True,
                "progress_hooks": [progress_hook(download_id, cancelled)],
                "merge_output_format": "mp4",
            }
            if audio_format:
                opts["format"] = format_id or "bestaudio/best"
                opts.pop("merge_output_format", None)
                opts["postprocessors"] = [{
                    "key": "FFmpegExtractAudio",
                    "preferredcodec": audio_format,
                    "preferredquality": "0",
                }]
            if subs_only:
                opts["skip_download"] = True
                opts["writesubtitles"] = True
                opts["writeautomaticsub"] = True
                opts["subtitleslangs"] = ["all"]
                opts["subtitlesformat"] = "srt/best"
                opts["postprocessors"] = [{
                    "key": "FFmpegSubtitlesConvertor",
                    "format": "srt",
                }]
                opts.pop("merge_output_format", None)
            elif write_subs:
                opts["writesubtitles"] = True
                opts["writeautomaticsub"] = True
                opts["subtitleslangs"] = ["all"]
                opts["subtitlesformat"] = "srt/best"
                opts["postprocessors"] = opts.get("postprocessors", []) + [{
                    "key": "FFmpegSubtitlesConvertor",
                    "format": "srt",
                }]
            return opts

        if is_playlist_job:
            result = run_playlist_download(
                yt_dlp=yt_dlp,
                url=url,
                build_single_options=build_single_video_options,
                output_dir=output_dir,
                download_id=download_id,
                cancelled=cancelled,
                playlist_items=playlist_items,
            )
            if cancelled.is_set():
                send_message({
                    "status": "cancelled",
                    "id": download_id,
                    "succeeded": result.get("succeeded", 0),
                    "failed": result.get("failed", 0),
                })
            else:
                send_message({
                    "status": "finished",
                    "id": download_id,
                    "title": result.get("playlist_title", ""),
                    "succeeded": result.get("succeeded", 0),
                    "failed": result.get("failed", 0),
                    "playlist_total": result.get("playlist_total", 0),
                })
            return

        options = build_single_video_options(safe_output_template(output_dir))

        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=True)

        if cancelled.is_set():
            send_message({"status": "cancelled", "id": download_id})
        else:
            send_message({
                "status": "finished",
                "id": download_id,
                "title": (info or {}).get("title", ""),
            })
    except KeyboardInterrupt:
        send_message({"status": "cancelled", "id": download_id})
    except Exception as exc:
        log("download failed:", traceback.format_exc())
        send_message({"status": "error", "id": download_id, "error": str(exc)})
    finally:
        active_downloads.pop(download_id, None)


def handle_pick_dir(initial: str | None) -> None:
    """Open the OS-native folder picker and return the chosen path.

    Uses ``osascript`` on macOS, ``zenity``/``kdialog`` on Linux. If no
    picker is available, returns the initial path as-is so the UI can still
    prompt the user to type a value manually.
    """
    import shutil
    import subprocess

    start = (initial or "").strip() or os.path.expanduser("~/Downloads")

    chosen: str | None = None
    error: str | None = None

    if sys.platform == "darwin":
        # osascript's choose folder returns an HFS-style path; coerce to POSIX.
        script = (
            'set initDir to POSIX file "{init}"\n'
            'tell application "System Events" to activate\n'
            'set chosen to choose folder with prompt "Pick Vidown download folder" '
            'default location initDir\n'
            'return POSIX path of chosen'
        ).format(init=start.replace('"', '\\"'))
        try:
            result = subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                text=True,
                timeout=120,
            )
            if result.returncode == 0:
                chosen = result.stdout.strip().rstrip("/") or None
            elif "User canceled" in (result.stderr or "") or result.returncode == 1:
                chosen = None
            else:
                error = result.stderr.strip() or f"osascript exit {result.returncode}"
        except Exception as exc:
            error = f"osascript failed: {exc}"
    elif sys.platform.startswith("linux"):
        for picker, args in (
            ("zenity", ["zenity", "--file-selection", "--directory", f"--filename={start}/"]),
            ("kdialog", ["kdialog", "--getexistingdirectory", start]),
        ):
            if shutil.which(picker):
                try:
                    result = subprocess.run(
                        args, capture_output=True, text=True, timeout=120
                    )
                    if result.returncode == 0:
                        chosen = result.stdout.strip() or None
                    break
                except Exception as exc:
                    error = f"{picker} failed: {exc}"
                    break
        else:
            error = "No folder picker available (install zenity or kdialog)"
    else:
        error = f"Folder picker not supported on {sys.platform}"

    if chosen:
        send_message({"status": "ok", "path": chosen})
    elif error:
        send_message({"status": "error", "error": error})
    else:
        send_message({"status": "cancelled"})


def handle_cancel(download_id: str | None) -> None:
    if not download_id:
        send_message({"status": "error", "error": "No download ID provided"})
        return
    event = active_downloads.get(download_id)
    if not event:
        send_message({"status": "error", "id": download_id, "error": "No active download with this ID"})
        return
    event.set()
    send_message({"status": "cancelling", "id": download_id})


def dispatch(message: dict[str, Any]) -> None:
    action = message.get("action")
    if action == "check":
        handle_check()
    elif action == "formats":
        handle_formats(message.get("url"))
    elif action == "download":
        download_id = str(message.get("id") or os.getpid())
        thread = threading.Thread(
            target=handle_download,
            args=(
                message.get("url"),
                message.get("format"),
                message.get("output_dir"),
                download_id,
                message.get("audio_format"),
                message.get("subs_only"),
                message.get("noplaylist", True),
                message.get("playlist_items"),
                message.get("write_subs", False),
            ),
            daemon=False,
        )
        thread.start()
    elif action == "cancel":
        handle_cancel(message.get("id"))
    elif action == "pick_dir":
        handle_pick_dir(message.get("initial"))
    else:
        send_message({"status": "error", "error": f"Unknown action: {action}"})


def shutdown(*_: object) -> None:
    for event in active_downloads.values():
        event.set()
    sys.exit(0)


def main() -> int:
    signal.signal(signal.SIGTERM, shutdown)
    if hasattr(signal, "SIGINT"):
        signal.signal(signal.SIGINT, shutdown)

    while True:
        message = read_message()
        if message is None:
            break
        try:
            dispatch(message)
        except Exception as exc:
            log("dispatch failed:", traceback.format_exc())
            send_message({"status": "error", "error": str(exc)})
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
