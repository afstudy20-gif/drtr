#!/bin/bash
# Vidown Native Messaging Host Wrapper
# Sets up PATH so that Homebrew, pyenv, and Python frameworks are accessible.

# Diagnostic log for native messaging launch issues. Lives in /tmp so it does
# not require any directory the wrapper creates itself.
VIDOWN_LOG="$HOME/vidown_wrapper.log"
{
  echo "==== $(date) PID=$$ ===="
  echo "USER=$(id -un) HOME=$HOME PWD=$(pwd)"
  echo "ARGS=$*"
  echo "PATH_ORIG=$PATH"
} >> "$VIDOWN_LOG" 2>&1

# Resolve this script's directory so the wrapper keeps working if the project
# is moved.
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Base PATH including Homebrew, local bin, pyenv, and standard paths
export PATH="/Users/yh/.pyenv/shims:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"

# Prefer the Python that ships with the installed yt-dlp binary, since it
# bundles the exact versions of extractor dependencies (pot providers, JS
# challenge solvers) the CLI ships with. Falls back to system Pythons.
BUNDLED_PY=""
if command -v yt-dlp &>/dev/null; then
  YTDLP_REAL="$(readlink -f "$(command -v yt-dlp)" 2>/dev/null || command -v yt-dlp)"
  YTDLP_SHEBANG="$(head -n 1 "$YTDLP_REAL" 2>/dev/null | sed 's/^#!//; s/[[:space:]].*//')"
  if [ -n "$YTDLP_SHEBANG" ] && [ -x "$YTDLP_SHEBANG" ]; then
    BUNDLED_PY="$YTDLP_SHEBANG"
  fi
fi

# Candidate Python paths that might have yt-dlp installed
CANDIDATES=(
  "$BUNDLED_PY"
  "/opt/homebrew/Cellar/yt-dlp/*/libexec/bin/python"
  "/Library/Frameworks/Python.framework/Versions/3.10/bin/python3"
  "/Library/Frameworks/Python.framework/Versions/3.12/bin/python3"
  "/Library/Frameworks/Python.framework/Versions/3.9/bin/python3"
  "/Users/yh/.pyenv/shims/python3"
  "/opt/homebrew/bin/python3"
  "/usr/local/bin/python3"
  "python3"
)

# Expand globs in candidate list (e.g. Cellar/yt-dlp/*/libexec/bin/python).
EXPANDED=()
for candidate in "${CANDIDATES[@]}"; do
  [ -z "$candidate" ] && continue
  for path in $candidate; do
    EXPANDED+=("$path")
  done
done

PYTHON_EXEC=""
for candidate in "${EXPANDED[@]}"; do
  # Check if candidate exists and can import yt_dlp
  if command -v "$candidate" &>/dev/null && "$candidate" -c "import yt_dlp" &>/dev/null; then
    PYTHON_EXEC="$candidate"
    break
  fi
done

# If no candidate has yt_dlp, check if there's any python3 at all to run the host
if [ -z "$PYTHON_EXEC" ]; then
  for candidate in "${EXPANDED[@]}"; do
    if command -v "$candidate" &>/dev/null; then
      PYTHON_EXEC="$candidate"
      break
    fi
  done
fi

# Fallback to python3 from PATH if absolutely nothing found
if [ -z "$PYTHON_EXEC" ]; then
  PYTHON_EXEC="python3"
fi

# If using a Framework Python, make sure its bin directory is in PATH so script can find pip-installed tools if needed
if [[ "$PYTHON_EXEC" == /Library/Frameworks/* ]]; then
  PYTHON_DIR="$(dirname "$PYTHON_EXEC")"
  export PATH="$PYTHON_DIR:$PATH"
fi

{
  echo "PYTHON_EXEC=$PYTHON_EXEC"
  echo "SCRIPT=$SCRIPT_DIR/vidown_host.py"
  echo "exists_py=$([ -x "$PYTHON_EXEC" ] && echo yes || echo NO)"
  echo "exists_script=$([ -f "$SCRIPT_DIR/vidown_host.py" ] && echo yes || echo NO)"
} >> "$VIDOWN_LOG" 2>&1

# Run the python host script; mirror stderr to the log so a crash is captured.
exec "$PYTHON_EXEC" "$SCRIPT_DIR/vidown_host.py" "$@" 2>>"$VIDOWN_LOG"
