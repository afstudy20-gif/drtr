#!/bin/bash
# Vidown Native Messaging Host Uninstaller

HOST_NAME="com.vidown.ytdlp"

echo "=== Vidown yt-dlp Host Uninstaller ==="
echo ""

remove_manifest() {
    local path="$1"
    if [ -f "$path" ]; then
        rm -f "$path"
        echo "[OK] Removed: $path"
    fi
}

if [[ "$OSTYPE" == "darwin"* ]]; then
    remove_manifest "$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts/$HOST_NAME.json"
    remove_manifest "$HOME/Library/Application Support/Google/Chrome Canary/NativeMessagingHosts/$HOST_NAME.json"
    remove_manifest "$HOME/Library/Application Support/Chromium/NativeMessagingHosts/$HOST_NAME.json"
    remove_manifest "$HOME/Library/Application Support/Microsoft Edge/NativeMessagingHosts/$HOST_NAME.json"
    remove_manifest "$HOME/Library/Application Support/BraveSoftware/Brave-Browser/NativeMessagingHosts/$HOST_NAME.json"
elif [[ "$OSTYPE" == "linux"* ]]; then
    remove_manifest "$HOME/.config/google-chrome/NativeMessagingHosts/$HOST_NAME.json"
    remove_manifest "$HOME/.config/chromium/NativeMessagingHosts/$HOST_NAME.json"
    remove_manifest "$HOME/.config/microsoft-edge/NativeMessagingHosts/$HOST_NAME.json"
    remove_manifest "$HOME/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts/$HOST_NAME.json"
fi

echo ""
echo "=== Uninstall Complete ==="
