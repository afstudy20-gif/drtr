@echo off
:: Vidown Native Messaging Host Installer for Windows
setlocal enabledelayedexpansion

echo === Vidown yt-dlp Host Installer ===
echo.

:: Check Python 3
where python >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python 3 is required but not found.
    echo Install it from https://www.python.org/downloads/
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('where python') do set PYTHON_PATH=%%i
echo [OK] Python found: %PYTHON_PATH%

:: Check yt-dlp
python -c "import yt_dlp" 2>nul
if %errorlevel% neq 0 (
    echo [!!] yt-dlp not found. Installing...
    python -m pip install -U yt-dlp
    echo [OK] yt-dlp installed
) else (
    for /f "tokens=*" %%v in ('python -c "import yt_dlp; print(yt_dlp.version.__version__)"') do set YTDLP_VER=%%v
    echo [OK] yt-dlp found: v!YTDLP_VER!
)

:: Get script directory
set SCRIPT_DIR=%~dp0
set HOST_SCRIPT=%SCRIPT_DIR%vidown_host.py

:: Get extension ID
echo.
echo Enter your Vidown extension ID (find it in chrome://extensions):
echo (Press Enter to allow all extensions - fine for personal use)
set /p EXT_ID=

if "%EXT_ID%"=="" (
    set ALLOWED_ORIGINS="chrome-extension://*/"
    echo [i] Allowing all extensions (development mode)
) else (
    set ALLOWED_ORIGINS="chrome-extension://%EXT_ID%/"
    echo [i] Allowing extension: %EXT_ID%
)

:: Create a batch wrapper so Chrome can launch it
set WRAPPER=%SCRIPT_DIR%vidown_host.bat
echo @echo off > "%WRAPPER%"
echo python "%HOST_SCRIPT%" %%* >> "%WRAPPER%"

:: Write manifest
set HOST_NAME=com.vidown.ytdlp
set MANIFEST_CONTENT={"name":"%HOST_NAME%","description":"Vidown yt-dlp Download Bridge","path":"%WRAPPER:\=\\%","type":"stdio","allowed_origins":[%ALLOWED_ORIGINS%]}

:: Registry keys for Chrome and Edge
echo.
echo Registering native messaging host...

:: Chrome
reg add "HKCU\Software\Google\Chrome\NativeMessagingHosts\%HOST_NAME%" /ve /t REG_SZ /d "%SCRIPT_DIR%%HOST_NAME%.json" /f >nul 2>&1
echo [OK] Chrome registry updated

:: Edge
reg add "HKCU\Software\Microsoft\Edge\NativeMessagingHosts\%HOST_NAME%" /ve /t REG_SZ /d "%SCRIPT_DIR%%HOST_NAME%.json" /f >nul 2>&1
echo [OK] Edge registry updated

:: Write manifest JSON file
echo %MANIFEST_CONTENT% > "%SCRIPT_DIR%%HOST_NAME%.json"
echo [OK] Manifest written to: %SCRIPT_DIR%%HOST_NAME%.json

echo.
echo === Installation Complete ===
echo.
echo Next steps:
echo   1. Load/reload the Vidown extension in your browser
echo   2. Open a video page and click the Vidown icon
echo   3. You should see 'yt-dlp connected' in the popup
echo.
pause
