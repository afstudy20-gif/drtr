#!/bin/bash
# Vidown Native Messaging Host Installer
# Registers the yt-dlp bridge for Chrome and Edge on macOS/Linux

set -e

HOST_NAME="com.vidown.ytdlp"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
HOST_SCRIPT="$SCRIPT_DIR/vidown_host.py"

echo "=== Vidown yt-dlp Host Installer ==="
echo ""

# Check Python 3
if ! command -v python3 &>/dev/null; then
    echo "ERROR: Python 3 is required but not found."
    echo "Install it from https://www.python.org/downloads/"
    exit 1
fi

PYTHON_PATH="$(command -v python3)"
echo "[OK] Python 3 found: $PYTHON_PATH"

# Check yt-dlp
if python3 -c "import yt_dlp" 2>/dev/null; then
    YTDLP_VER=$(python3 -c "import yt_dlp; print(yt_dlp.version.__version__)")
    echo "[OK] yt-dlp found: v$YTDLP_VER"
else
    echo "[!!] yt-dlp not found. Installing..."
    python3 -m pip install -U yt-dlp
    echo "[OK] yt-dlp installed"
fi

# Make host script executable
chmod +x "$HOST_SCRIPT"

# Detect extension ID from manifest.json (if loaded, user can also set manually)
# Use a wildcard for development; user should update after loading the extension
echo ""
echo "Enter your Vidown extension ID (find it in chrome://extensions):"
echo "(Press Enter to allow all extensions - fine for personal use)"
read -r EXT_ID

if [ -z "$EXT_ID" ]; then
    ALLOWED_ORIGINS='"chrome-extension://*/"'
    echo "[i] Allowing all extensions (development mode)"
else
    ALLOWED_ORIGINS="\"chrome-extension://$EXT_ID/\""
    echo "[i] Allowing extension: $EXT_ID"
fi

# Create the native messaging host manifest
create_manifest() {
    local target_dir="$1"
    mkdir -p "$target_dir"
    cat > "$target_dir/$HOST_NAME.json" <<MANIFEST
{
  "name": "$HOST_NAME",
  "description": "Vidown yt-dlp Download Bridge",
  "path": "$HOST_SCRIPT",
  "type": "stdio",
  "allowed_origins": [
    $ALLOWED_ORIGINS
  ]
}
MANIFEST
    echo "[OK] Manifest written to: $target_dir/$HOST_NAME.json"
}

echo ""

# Detect OS and install
if [[ "$OSTYPE" == "darwin"* ]]; then
    # macOS
    echo "Detected: macOS"

    # Chrome
    CHROME_DIR="$HOME/Library/Application Support/Google/Chrome/NativeMessagingHosts"
    if [ -d "$HOME/Library/Application Support/Google/Chrome" ]; then
        create_manifest "$CHROME_DIR"
    else
        echo "[--] Chrome not found, skipping"
    fi

    # Chrome Canary
    CANARY_DIR="$HOME/Library/Application Support/Google/Chrome Canary/NativeMessagingHosts"
    if [ -d "$HOME/Library/Application Support/Google/Chrome Canary" ]; then
        create_manifest "$CANARY_DIR"
    fi

    # Chromium
    CHROMIUM_DIR="$HOME/Library/Application Support/Chromium/NativeMessagingHosts"
    if [ -d "$HOME/Library/Application Support/Chromium" ]; then
        create_manifest "$CHROMIUM_DIR"
    fi

    # Edge
    EDGE_DIR="$HOME/Library/Application Support/Microsoft Edge/NativeMessagingHosts"
    if [ -d "$HOME/Library/Application Support/Microsoft Edge" ]; then
        create_manifest "$EDGE_DIR"
    else
        echo "[--] Edge not found, skipping"
    fi

    # Brave
    BRAVE_DIR="$HOME/Library/Application Support/BraveSoftware/Brave-Browser/NativeMessagingHosts"
    if [ -d "$HOME/Library/Application Support/BraveSoftware/Brave-Browser" ]; then
        create_manifest "$BRAVE_DIR"
    fi

elif [[ "$OSTYPE" == "linux"* ]]; then
    # Linux
    echo "Detected: Linux"

    # Chrome
    CHROME_DIR="$HOME/.config/google-chrome/NativeMessagingHosts"
    create_manifest "$CHROME_DIR"

    # Chromium
    CHROMIUM_DIR="$HOME/.config/chromium/NativeMessagingHosts"
    create_manifest "$CHROMIUM_DIR"

    # Edge
    EDGE_DIR="$HOME/.config/microsoft-edge/NativeMessagingHosts"
    create_manifest "$EDGE_DIR"

    # Brave
    BRAVE_DIR="$HOME/.config/BraveSoftware/Brave-Browser/NativeMessagingHosts"
    create_manifest "$BRAVE_DIR"

else
    echo "ERROR: Unsupported OS. Use install.bat for Windows."
    exit 1
fi

echo ""
echo "=== Installation Complete ==="
echo ""
echo "Next steps:"
echo "  1. Load/reload the Vidown extension in your browser"
echo "  2. Open a video page and click the Vidown icon"
echo "  3. You should see 'yt-dlp connected' in the popup"
echo ""
echo "To uninstall, run: ./uninstall.sh"
