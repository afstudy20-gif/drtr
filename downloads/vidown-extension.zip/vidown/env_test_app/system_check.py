import os
import sys
import platform

# Determine OS
current_os = platform.system()
# Determine current working directory
cwd = os.getcwd()
# Determine Python version
py_version = sys.version

# Write to system_info.txt
with open('system_info.txt', 'w') as f:
    f.write(f'Operating System: {current_os}\n')
    f.write(f'Current Working Directory: {cwd}\n')
    f.write(f'Python Version: {py_version}\n')