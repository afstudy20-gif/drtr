// Vidown - Content Script
// Bridges inject.js ↔ background.js and performs DOM scanning

(function () {
  "use strict";

  // --- Inject the page-context interceptor ---
  function injectScript() {
    const parent = document.head || document.documentElement;
    if (!parent) return;

    // Method 1: <script src="inject.js"> (preferred, works on normal pages)
    const s = document.createElement("script");
    s.src = chrome.runtime.getURL("inject.js");
    s.onload = () => s.remove();
    s.onerror = () => {
      // Method 2: inline <script> fallback for blob: frames or CSP-restricted pages
      s.remove();
      injectInline(parent);
    };
    parent.appendChild(s);
  }

  function injectInline(parent) {
    try {
      // Fetch inject.js content via the extension runtime and inline it
      fetch(chrome.runtime.getURL("inject.js"))
        .then((r) => r.text())
        .then((code) => {
          const s2 = document.createElement("script");
          s2.textContent = code;
          parent.appendChild(s2);
          s2.remove();
        })
        .catch(() => {
          // Method 3: ask background to use chrome.scripting.executeScript
          chrome.runtime.sendMessage({ type: "INJECT_FALLBACK" });
        });
    } catch {
      chrome.runtime.sendMessage({ type: "INJECT_FALLBACK" });
    }
  }

  injectScript();

  // --- MSE buffer bridge: route background requests to page-context helpers
  // (`window.__vidownMSESnapshot`/`__vidownMSEExport`) and forward replies. ---
  const pendingMseSnapshots = new Map();
  const pendingMseExports = new Map();
  let mseRequestCounter = 0;

  function pageEval(code) {
    const s = document.createElement("script");
    s.textContent = code;
    (document.head || document.documentElement || document.body).appendChild(s);
    s.remove();
  }

  function requestMseSnapshot() {
    return new Promise((resolve) => {
      const requestId = ++mseRequestCounter;
      pendingMseSnapshots.set(requestId, resolve);
      pageEval(`(() => {
        try {
          const snap = typeof window.__vidownMSESnapshot === "function"
            ? window.__vidownMSESnapshot()
            : [];
          window.postMessage({
            type: "VIDOWN_MSE_SNAPSHOT_RESULT",
            requestId: ${requestId},
            snapshot: snap,
          }, "*");
        } catch (e) {
          window.postMessage({
            type: "VIDOWN_MSE_SNAPSHOT_RESULT",
            requestId: ${requestId},
            snapshot: [],
          }, "*");
        }
      })();`);
      setTimeout(() => {
        if (pendingMseSnapshots.has(requestId)) {
          pendingMseSnapshots.delete(requestId);
          resolve([]);
        }
      }, 3000);
    });
  }

  function requestMseExport(msId, sbId) {
    return new Promise((resolve) => {
      const requestId = ++mseRequestCounter;
      pendingMseExports.set(requestId, resolve);
      pageEval(`(() => {
        try {
          const r = typeof window.__vidownMSEExport === "function"
            ? window.__vidownMSEExport(${JSON.stringify(msId)}, ${JSON.stringify(sbId)})
            : null;
          if (r) {
            window.postMessage({
              type: "VIDOWN_MSE_EXPORT_RESULT",
              requestId: ${requestId},
              ok: true,
              url: r.url,
              size: r.size,
              mime: r.mime,
            }, "*");
          } else {
            window.postMessage({
              type: "VIDOWN_MSE_EXPORT_RESULT",
              requestId: ${requestId},
              ok: false,
              error: "buffer not found or empty",
            }, "*");
          }
        } catch (e) {
          window.postMessage({
            type: "VIDOWN_MSE_EXPORT_RESULT",
            requestId: ${requestId},
            ok: false,
            error: String(e),
          }, "*");
        }
      })();`);
      setTimeout(() => {
        if (pendingMseExports.has(requestId)) {
          pendingMseExports.delete(requestId);
          resolve({ ok: false, error: "timeout" });
        }
      }, 15000);
    });
  }

  // --- Extract video title from page metadata ---
  function getPageVideoTitle() {
    // Priority order: og:title > twitter:title > cleaned document.title
    const ogTitle = document.querySelector('meta[property="og:title"]');
    if (ogTitle?.content) return ogTitle.content.trim();

    const twTitle = document.querySelector('meta[name="twitter:title"]');
    if (twTitle?.content) return twTitle.content.trim();

    // Clean document.title by removing common site suffixes
    let title = document.title || "";
    title = title
      .replace(/\s*[-–—|_]\s*(YouTube|Bilibili|哔哩哔哩|Vimeo|Twitch|TikTok|Twitter|X|Facebook|Instagram|Dailymotion|bilibili\.tv).*$/i, "")
      .replace(/\s*[-–—|_]\s*Watch.*$/i, "")
      .trim();

    return title || "";
  }

  // Only the top frame's title represents the page. Sub-frame titles
  // (e.g. iframe video players like vidlop) would otherwise overwrite the
  // real page title when their content script reports.
  const isTopFrame = (() => {
    try { return window.top === window; } catch { return false; }
  })();

  // Send page title to background whenever it changes (top frame only).
  let lastSentTitle = "";
  function sendPageTitle() {
    if (!isTopFrame) return;
    const title = getPageVideoTitle();
    if (title && title !== lastSentTitle) {
      lastSentTitle = title;
      chrome.runtime.sendMessage({
        type: "PAGE_TITLE",
        title,
        pageUrl: location.href,
      });
    }
  }

  // --- Debug bridge: page-context can postMessage VIDOWN_DEBUG_QUERY and
  // we relay the background's debug log + tabVideos back to the page.
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.type !== "VIDOWN_DEBUG_QUERY") return;
    chrome.runtime.sendMessage({ type: "GET_DEBUG_LOG" }, (resp) => {
      window.postMessage({ type: "VIDOWN_DEBUG_REPLY", payload: resp }, "*");
    });
  });

  // --- Diagnostic relay: lets page context probe arbitrary background
  // messages without having access to chrome.runtime. Used by automated
  // tests and the in-browser debugger.
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data?.type !== "VIDOWN_RELAY_REQUEST") return;
    const { requestId, payload } = event.data;
    chrome.runtime.sendMessage(payload, (resp) => {
      const err = chrome.runtime.lastError;
      window.postMessage(
        {
          type: "VIDOWN_RELAY_REPLY",
          requestId,
          response: resp,
          lastError: err ? err.message : null,
        },
        "*"
      );
    });
  });

  // --- Listen for messages from inject.js / record-driver.js ---
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;

    if (event.data?.type === "VIDOWN_MEDIA_DETECTED") {
      sendPageTitle();
      chrome.runtime.sendMessage({
        type: "MEDIA_DETECTED",
        url: event.data.url,
        mediaType: event.data.mediaType,
        quality: event.data.quality || null,
        source: event.data.source || "inject",
      });
      return;
    }

    if (event.data?.type === "VIDOWN_MSE_REGISTER") {
      sendPageTitle();
      chrome.runtime.sendMessage({
        type: "MSE_BUFFER_REGISTERED",
        msId: event.data.msId,
      });
      return;
    }

    if (event.data?.type === "VIDOWN_MSE_EXPORT_RESULT") {
      const { requestId, ok, url, size, mime, error } = event.data;
      pendingMseExports.get(requestId)?.({ ok, url, size, mime, error });
      pendingMseExports.delete(requestId);
      return;
    }

    if (event.data?.type === "VIDOWN_MSE_SNAPSHOT_RESULT") {
      const { requestId, snapshot } = event.data;
      pendingMseSnapshots.get(requestId)?.(snapshot);
      pendingMseSnapshots.delete(requestId);
      return;
    }

    if (event.data?.type === "VIDOWN_RECORD_STATUS") {
      chrome.runtime.sendMessage({
        type: "RECORD_STATUS_RELAY",
        payload: event.data,
      });
    }
  });

  // --- URL classification ---
  const MEDIA_PATTERNS = [
    { regex: /\.m3u8(\?|#|$)/i, type: "hls" },
    { regex: /\.mpd(\?|#|$)/i, type: "dash" },
    { regex: /\.mp4(\?|#|$)/i, type: "mp4" },
    { regex: /\.webm(\?|#|$)/i, type: "webm" },
    { regex: /\.m4v(\?|#|$)/i, type: "mp4" },
    { regex: /\.ogv(\?|#|$)/i, type: "webm" },
    { regex: /\.flv(\?|#|$)/i, type: "flv" },
    { regex: /\.mkv(\?|#|$)/i, type: "mkv" },
    { regex: /\.(vtt|webvtt|srt|ttml|dfxp)(\?|#|$)/i, type: "subtitle" },
  ];

  function classifyUrl(url) {
    if (!url || url.startsWith("data:")) return null;
    try {
      const u = new URL(url, location.href);
      const mime = (u.searchParams.get("mime") || "").toLowerCase();
      if (mime.startsWith("audio/")) return "audio";
      if (mime.includes("text/vtt") || mime.includes("application/x-subrip")) return "subtitle";
      if (mime.includes("video/mp4")) return "mp4";
      if (mime.includes("video/webm")) return "webm";
      const text = `${u.pathname} ${mime} ${u.searchParams.get("codecs") || ""}`.toLowerCase();
      if (/(^|[/?_.=&-])(audio|aac|m4a|mp3|mp4a|opus|vorbis)([/?_.=&-]|$)/i.test(text) ||
          /(^|[/?_.=&-])a\d{1,3}([/?_.=&-]|$)/i.test(text)) {
        return "audio";
      }
    } catch {}
    for (const p of MEDIA_PATTERNS) {
      if (p.regex.test(url)) return p.type;
    }
    return null;
  }

  const reportedUrls = new Set();

  function reportUrl(url, type, source, quality) {
    if (!url || reportedUrls.has(url)) return;
    reportedUrls.add(url);

    sendPageTitle();
    chrome.runtime.sendMessage({
      type: "MEDIA_DETECTED",
      url,
      mediaType: type,
      source: source || "dom-scan",
      quality: quality || undefined,
    });
  }

  function scanTextTracks(videoEl) {
    try {
      const tracks = videoEl.textTracks;
      if (!tracks || tracks.length === 0) return;
      for (let i = 0; i < tracks.length; i++) {
        const track = tracks[i];
        const src = videoEl.querySelectorAll("track")[i]?.src;
        if (src) {
          const label = track.label || track.language || "subtitle";
          reportUrl(src, "subtitle", "texttrack-api", label);
        }
      }
    } catch (_) { /* cross-origin may throw */ }
  }

  // --- DOM Scanning ---
  function scanElement(el) {
    // Check video elements
    if (el.tagName === "VIDEO" || el.tagName === "AUDIO") {
      const src = el.src || el.currentSrc;
      if (src) {
        if (src.startsWith("blob:")) {
          reportUrl(src, "blob", "dom-scan");
        } else {
          const type = classifyUrl(src);
          if (type) reportUrl(src, type, "dom-scan");
        }
      }
      // Check child source elements
      el.querySelectorAll("source").forEach((source) => {
        if (source.src) {
          const type = classifyUrl(source.src);
          if (type) reportUrl(source.src, type, "dom-scan");
        }
      });
      // Scan <track> children for subtitles/captions
      el.querySelectorAll("track").forEach((track) => {
        if (track.src) {
          const label = track.label || track.srclang || "subtitle";
          reportUrl(track.src, "subtitle", "dom-track", label);
        }
      });
      // Also check TextTrack API for dynamically added cues
      scanTextTracks(el);
    }

    // Check source/track elements directly
    if (el.tagName === "TRACK" && el.src) {
      const label = el.label || el.srclang || "subtitle";
      reportUrl(el.src, "subtitle", "dom-track", label);
    } else if (el.tagName === "SOURCE" && el.src) {
      const type = classifyUrl(el.src);
      if (type) reportUrl(el.src, type, "dom-scan");
    }

    // Check embed/object
    if (
      (el.tagName === "EMBED" || el.tagName === "OBJECT") &&
      (el.src || el.data)
    ) {
      const url = el.src || el.data;
      const type = classifyUrl(url);
      if (type) reportUrl(url, type, "dom-scan");
    }

    // Check iframes with video sources
    if (el.tagName === "IFRAME" && el.src) {
      const type = classifyUrl(el.src);
      if (type) reportUrl(el.src, type, "dom-scan");
    }
  }

  function scanDOM() {
    const selectors = "video, audio, source, track, embed, object, iframe";
    document.querySelectorAll(selectors).forEach(scanElement);
    scanPageContent();
  }

  // --- Content-based capture (FetchV-style "inject" mode) ---
  // Some sites encode the manifest URL inside HTML/JS strings and never
  // expose it through the player API. Sweep the document HTML and every
  // inline script for m3u8/mpd URLs and report what we find. The background
  // script will probe each one and discard non-manifests, so false positives
  // don't pollute the popup.
  const CONTENT_URL_REGEX =
    /https?:\/\/[^\s"'<>(){}\\]+?\.(m3u8|mpd)(\?[^\s"'<>(){}\\]*)?/gi;
  const scannedContentHashes = new Set();

  function hashString(str) {
    let h = 5381;
    for (let i = 0; i < str.length; i++) h = ((h << 5) + h + str.charCodeAt(i)) | 0;
    return h;
  }

  function scanText(text, source) {
    if (!text || text.length < 20) return;
    const slice = text.length > 200000 ? text.slice(0, 200000) : text;
    const fp = hashString(slice);
    if (scannedContentHashes.has(fp)) return;
    scannedContentHashes.add(fp);
    let m;
    CONTENT_URL_REGEX.lastIndex = 0;
    while ((m = CONTENT_URL_REGEX.exec(slice)) !== null) {
      const url = m[0];
      const ext = m[1].toLowerCase();
      const type = ext === "m3u8" ? "hls" : "dash";
      reportUrl(url, type, source);
    }
  }

  function scanPageContent() {
    try {
      const html = document.documentElement?.outerHTML || "";
      scanText(html, "content-scan");
      document.querySelectorAll("script:not([src])").forEach((s) => {
        scanText(s.textContent || "", "content-scan-script");
      });
    } catch (_) { /* ignore */ }
  }

  // --- MutationObserver ---
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (node.nodeType !== Node.ELEMENT_NODE) continue;
        scanElement(node);
        // Also scan children
        const selectors = "video, audio, source, track, embed, object";
        node.querySelectorAll?.(selectors)?.forEach(scanElement);
      }

      // Attribute changes on media elements
      if (
        mutation.type === "attributes" &&
        mutation.attributeName === "src" &&
        mutation.target.nodeType === Node.ELEMENT_NODE
      ) {
        scanElement(mutation.target);
      }
    }
  });

  // Start observing when DOM is ready
  function startObserver() {
    const target = document.body || document.documentElement;
    if (target) {
      observer.observe(target, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ["src", "data"],
      });
    }
  }

  // --- Periodic scanning ---
  let scanCount = 0;
  const MAX_SCANS = 10;

  function periodicScan() {
    scanDOM();
    scanCount++;
    if (scanCount < MAX_SCANS) {
      setTimeout(periodicScan, 3000);
    }
  }

  // --- Init ---
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", () => {
      startObserver();
      periodicScan();
      sendPageTitle();
    });
  } else {
    startObserver();
    periodicScan();
    sendPageTitle();
  }

  // Re-send title when it changes (SPA navigation)
  new MutationObserver(() => sendPageTitle()).observe(
    document.querySelector("title") || document.head || document.documentElement,
    { childList: true, subtree: true, characterData: true }
  );

  // --- In-video progress ring overlay ---
  // Shows a circular SVG progress indicator on the largest visible <video>
  // while an HLS/DASH download is in progress for this tab.
  const activeProgressOverlays = new Map();

  function findLargestVideo() {
    let best = null;
    let bestArea = 0;
    for (const v of document.querySelectorAll("video")) {
      const r = v.getBoundingClientRect();
      const area = r.width * r.height;
      if (area > bestArea) { best = v; bestArea = area; }
    }
    return best;
  }

  function ensureProgressRing(jobId) {
    if (activeProgressOverlays.has(jobId)) return activeProgressOverlays.get(jobId);
    const video = findLargestVideo();
    if (!video) return null;

    const wrapper = document.createElement("div");
    wrapper.className = "vidown-progress-ring-wrapper";
    wrapper.dataset.jobId = jobId;

    wrapper.innerHTML = `
      <svg viewBox="0 0 36 36" class="vidown-ring-svg">
        <path class="vidown-ring-bg" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
        <path class="vidown-ring-fill" stroke-dasharray="0, 100" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" />
      </svg>
      <div class="vidown-ring-text">0%</div>
    `;

    const style = document.createElement("style");
    style.textContent = `
      .vidown-progress-ring-wrapper {
        position: fixed; z-index: 2147483645;
        pointer-events: none; display: flex;
        align-items: center; justify-content: center;
      }
      .vidown-ring-svg {
        width: 56px; height: 56px;
        filter: drop-shadow(0 2px 6px rgba(0,0,0,0.5));
      }
      .vidown-ring-bg {
        fill: none; stroke: rgba(255,255,255,0.2);
        stroke-width: 3; stroke-linecap: round;
      }
      .vidown-ring-fill {
        fill: none; stroke: #e94560;
        stroke-width: 3; stroke-linecap: round;
        transition: stroke-dasharray 0.3s ease;
      }
      .vidown-ring-text {
        position: absolute; color: #fff;
        font-size: 11px; font-weight: 700;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        text-shadow: 0 1px 3px rgba(0,0,0,0.7);
      }
      .vidown-ring-done .vidown-ring-fill { stroke: #10b981; }
      .vidown-ring-error .vidown-ring-fill { stroke: #ef4444; }
    `;
    if (!document.querySelector("style[data-vidown-ring]")) {
      style.dataset.vidownRing = "1";
      (document.head || document.documentElement).appendChild(style);
    }

    document.body.appendChild(wrapper);

    const positionRing = () => {
      const rect = video.getBoundingClientRect();
      wrapper.style.cssText = `
        position: fixed; z-index: 2147483645; pointer-events: none;
        display: flex; align-items: center; justify-content: center;
        top: ${rect.top + 8}px; right: ${window.innerWidth - rect.right + 8}px;
        width: 56px; height: 56px;
      `;
    };
    positionRing();
    const resObs = new ResizeObserver(positionRing);
    resObs.observe(video);
    window.addEventListener("scroll", positionRing, true);

    activeProgressOverlays.set(jobId, { wrapper, positionRing, resObs, video });
    return activeProgressOverlays.get(jobId);
  }

  function updateProgressRing(jobId, percent, status) {
    const ring = ensureProgressRing(jobId);
    if (!ring) return;
    const fill = ring.wrapper.querySelector(".vidown-ring-fill");
    const text = ring.wrapper.querySelector(".vidown-ring-text");
    const pct = Math.min(Math.max(percent || 0, 0), 100);

    if (fill) fill.setAttribute("stroke-dasharray", `${pct}, 100`);
    if (text) text.textContent = `${Math.round(pct)}%`;

    ring.wrapper.classList.remove("vidown-ring-done", "vidown-ring-error");
    if (status === "done") {
      ring.wrapper.classList.add("vidown-ring-done");
      if (text) text.textContent = "✓";
      setTimeout(() => removeProgressRing(jobId), 3000);
    } else if (status === "error" || status === "cancelled") {
      ring.wrapper.classList.add("vidown-ring-error");
      if (text) text.textContent = "✗";
      setTimeout(() => removeProgressRing(jobId), 4000);
    }
  }

  function removeProgressRing(jobId) {
    const ring = activeProgressOverlays.get(jobId);
    if (!ring) return;
    ring.resObs.disconnect();
    ring.wrapper.remove();
    activeProgressOverlays.delete(jobId);
  }

  // --- Handle messages from popup / background ---
  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message.type === "RESCAN") {
      scanCount = 0;
      reportedUrls.clear();
      scanDOM();
      return false;
    }

    if (message.type === "MSE_SNAPSHOT_REQUEST") {
      requestMseSnapshot().then((snapshot) => sendResponse({ snapshot }));
      return true;
    }

    if (message.type === "MSE_EXPORT_REQUEST") {
      requestMseExport(message.msId, message.sbId).then((r) => sendResponse(r));
      return true;
    }

    if (message.type === "DOWNLOAD_PROGRESS_RING") {
      updateProgressRing(message.jobId, message.percent, message.status);
      return false;
    }

    return false;
  });

  // --- YouTube Extra Loop Button Features ---
  if (location.hostname.endsWith("youtube.com")) {
    const BTN_ID = "yt-loop-btn";

    const getVideo = () => document.querySelector("video.html5-main-video") || document.querySelector("video");

    const updateBtnState = (btn, video) => {
      if (!video) return;
      if (video.loop) {
        btn.classList.add("active");
        btn.setAttribute("aria-pressed", "true");
        btn.title = "Döngü: Açık (kapatmak için tıkla)";
      } else {
        btn.classList.remove("active");
        btn.setAttribute("aria-pressed", "false");
        btn.title = "Döngü: Kapalı (açmak için tıkla)";
      }
    };

    const toggleLoop = (btn) => {
      const video = getVideo();
      if (!video) return;
      video.loop = !video.loop;
      updateBtnState(btn, video);
    };

    const createButton = () => {
      const btn = document.createElement("button");
      btn.id = BTN_ID;
      btn.className = "ytp-button yt-loop-btn";
      btn.setAttribute("aria-label", "Videoyu tekrar çal (loop)");
      btn.innerHTML = `
        <svg height="100%" viewBox="0 0 36 36" width="100%" fill="#fff">
          <path d="M11 7v3H7v10h4v3l-6-4V11l6-4zm14 0l6 4v11l-6 4v-3h4V10h-4V7zM13 12h10v3l5-4-5-4v3H13v2zm10 12H13v-3l-5 4 5 4v-3h10v-2z" opacity="0"/>
          <path d="M7 7h16v4l5-5-5-5v4H5v8h2V7zm22 14H13v-4l-5 5 5 5v-4h18v-8h-2v6z" transform="translate(0,2)"/>
        </svg>
      `;
      btn.addEventListener("click", (e) => {
        e.stopPropagation();
        toggleLoop(btn);
      });
      return btn;
    };

    const insertButton = () => {
      if (document.getElementById(BTN_ID)) return;
      const leftControls = document.querySelector(".ytp-left-controls");
      if (!leftControls) return;
      const btn = createButton();
      const nextBtn = leftControls.querySelector(".ytp-next-button");
      if (nextBtn && nextBtn.nextSibling) {
        leftControls.insertBefore(btn, nextBtn.nextSibling);
      } else {
        leftControls.appendChild(btn);
      }
      const video = getVideo();
      if (video) updateBtnState(btn, video);
    };

    // Keep trying to insert the button using MutationObserver
    const loopObserver = new MutationObserver(() => insertButton());
    loopObserver.observe(document.documentElement, { childList: true, subtree: true });

    document.addEventListener("keydown", (e) => {
      if (e.target.matches("input, textarea, [contenteditable]")) return;
      if (e.key === "l" && e.shiftKey) {
        const btn = document.getElementById(BTN_ID);
        if (btn) toggleLoop(btn);
      }
    });

    const injectStyles = () => {
      const style = document.createElement("style");
      style.textContent = `
        .yt-loop-btn {
          background: transparent;
          border: none;
          cursor: pointer;
          width: 48px;
          height: 48px;
          padding: 0 8px;
          vertical-align: top;
          opacity: 0.9;
        }
        .yt-loop-btn:hover {
          opacity: 1;
        }
        .yt-loop-btn svg {
          width: 24px;
          height: 24px;
          display: inline-block;
          vertical-align: middle;
        }
        .yt-loop-btn.active svg path {
          fill: #3ea6ff;
        }
        .yt-loop-btn.active::after {
          content: "";
          position: relative;
          display: block;
          width: 18px;
          height: 2px;
          background: #3ea6ff;
          margin: -6px auto 0;
          border-radius: 2px;
        }
      `;
      (document.head || document.documentElement).appendChild(style);
    };

    // Run initially when DOM is ready
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", () => {
        injectStyles();
        insertButton();
      });
    } else {
      injectStyles();
      insertButton();
    }
  }
})();
