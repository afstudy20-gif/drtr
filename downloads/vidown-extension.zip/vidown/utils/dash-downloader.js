// Vidown - In-browser DASH (MPEG-DASH) Downloader
// Parses MPD manifest, picks video + audio representations, downloads init
// segment and media segments via SegmentTemplate/SegmentList/SegmentBase,
// concatenates into a fragmented MP4 (fmp4) blob.

(function () {
  "use strict";

  const DEFAULT_CONCURRENCY = 6;
  const SEGMENT_TIMEOUT_MS = 30000;
  const MAX_RETRIES = 3;
  const RATE_LIMIT_MAX_RETRIES = 10;
  const RATE_LIMIT_BACKOFF_BASE_MS = 2000;
  const RATE_LIMIT_BACKOFF_MAX_MS = 60000;

  // Global throttle gate shared across workers. See hls-downloader.js for
  // rationale: a single worker hitting 429 should pause every worker so the
  // server gets the breathing room it asked for.
  let globalThrottleUntil = 0;

  function parseRetryAfter(headerValue) {
    if (!headerValue) return null;
    const trimmed = String(headerValue).trim();
    const asInt = parseInt(trimmed, 10);
    if (Number.isFinite(asInt) && asInt >= 0) return asInt * 1000;
    const asDate = Date.parse(trimmed);
    if (Number.isFinite(asDate)) {
      const delta = asDate - Date.now();
      return delta > 0 ? delta : 0;
    }
    return null;
  }

  async function waitForGate(signal) {
    while (true) {
      const wait = globalThrottleUntil - Date.now();
      if (wait <= 0) return;
      if (signal && signal.aborted) throw new Error("Cancelled");
      await new Promise((r) => setTimeout(r, Math.min(wait, 500)));
    }
  }

  function bumpThrottleGate(ms) {
    const target = Date.now() + ms;
    if (target > globalThrottleUntil) globalThrottleUntil = target;
  }

  function resolveUrl(base, ref) {
    if (!ref) return base;
    try {
      return new URL(ref, base).toString();
    } catch {
      return ref;
    }
  }

  function parseDuration(iso) {
    if (!iso) return 0;
    const m = iso.match(/^PT(?:(\d+(?:\.\d+)?)H)?(?:(\d+(?:\.\d+)?)M)?(?:(\d+(?:\.\d+)?)S)?$/);
    if (!m) return 0;
    return (parseFloat(m[1] || "0") * 3600 +
            parseFloat(m[2] || "0") * 60 +
            parseFloat(m[3] || "0"));
  }

  function expandTemplate(tpl, values) {
    return tpl.replace(/\$(RepresentationID|Number|Bandwidth|Time)(?:%0(\d+)d)?\$/g,
      (_, name, pad) => {
        let v = values[name];
        if (v === undefined || v === null) return "";
        if (pad) {
          v = String(v).padStart(parseInt(pad, 10), "0");
        }
        return String(v);
      });
  }

  function parseRange(range) {
    if (!range) return null;
    const [start, end] = range.split("-").map((s) => parseInt(s, 10));
    return { start, end };
  }

  function inferContentType(adaptationSet, rep) {
    const explicit = adaptationSet.getAttribute("contentType");
    if (explicit) return explicit.toLowerCase();

    const mime = (
      rep.getAttribute("mimeType") ||
      adaptationSet.getAttribute("mimeType") ||
      ""
    ).toLowerCase();
    if (mime.startsWith("video/")) return "video";
    if (mime.startsWith("audio/")) return "audio";

    const codecs = (
      rep.getAttribute("codecs") ||
      adaptationSet.getAttribute("codecs") ||
      ""
    ).toLowerCase();
    if (/(avc1|avc3|hvc1|hev1|dvhe|dvh1|vp09|vp9|av01)/i.test(codecs)) return "video";
    if (/(mp4a|ac-3|ec-3|opus|vorbis|aac)/i.test(codecs)) return "audio";

    if (rep.getAttribute("width") || rep.getAttribute("height")) return "video";
    return "";
  }

  // Build segment list for a representation
  function buildSegments(rep, adaptationSet, period, mpdBaseUrl) {
    const baseUrlNode = rep.querySelector(":scope > BaseURL")
      || adaptationSet.querySelector(":scope > BaseURL")
      || period.querySelector(":scope > BaseURL");
    const baseUrl = baseUrlNode
      ? resolveUrl(mpdBaseUrl, baseUrlNode.textContent.trim())
      : mpdBaseUrl;

    const repId = rep.getAttribute("id");
    const bandwidth = parseInt(rep.getAttribute("bandwidth"), 10) || 0;

    // SegmentTemplate (most common)
    const tpl = rep.querySelector(":scope > SegmentTemplate")
      || adaptationSet.querySelector(":scope > SegmentTemplate")
      || period.querySelector(":scope > SegmentTemplate");

    if (tpl) {
      const initTpl = tpl.getAttribute("initialization");
      const mediaTpl = tpl.getAttribute("media");
      const startNumber = parseInt(tpl.getAttribute("startNumber") || "1", 10);
      const timescale = parseInt(tpl.getAttribute("timescale") || "1", 10);
      const duration = parseInt(tpl.getAttribute("duration") || "0", 10);
      const presentationDuration = parseDuration(period.getAttribute("duration"))
        || parseDuration(period.parentNode.getAttribute("mediaPresentationDuration"));

      const values = {
        RepresentationID: repId,
        Bandwidth: bandwidth,
      };

      const init = initTpl
        ? { url: resolveUrl(baseUrl, expandTemplate(initTpl, values)) }
        : null;

      // Timeline-based
      const timeline = tpl.querySelector(":scope > SegmentTimeline");
      const segments = [];
      if (timeline) {
        let time = 0;
        let number = startNumber;
        timeline.querySelectorAll(":scope > S").forEach((s) => {
          const t = s.getAttribute("t");
          const d = parseInt(s.getAttribute("d"), 10);
          const r = parseInt(s.getAttribute("r") || "0", 10);
          if (t !== null && t !== undefined && t !== "") time = parseInt(t, 10);
          for (let i = 0; i <= r; i++) {
            const segUrl = resolveUrl(
              baseUrl,
              expandTemplate(mediaTpl, { ...values, Number: number, Time: time })
            );
            segments.push({ url: segUrl });
            time += d;
            number++;
          }
        });
      } else if (duration > 0 && presentationDuration > 0) {
        const segDurationSec = duration / timescale;
        const count = Math.ceil(presentationDuration / segDurationSec);
        for (let i = 0; i < count; i++) {
          const number = startNumber + i;
          const time = i * duration;
          const segUrl = resolveUrl(
            baseUrl,
            expandTemplate(mediaTpl, { ...values, Number: number, Time: time })
          );
          segments.push({ url: segUrl });
        }
      }
      return { init, segments };
    }

    // SegmentList
    const segList = rep.querySelector(":scope > SegmentList")
      || adaptationSet.querySelector(":scope > SegmentList");
    if (segList) {
      const initEl = segList.querySelector(":scope > Initialization");
      const init = initEl
        ? {
            url: resolveUrl(baseUrl, initEl.getAttribute("sourceURL") || ""),
            byterange: initEl.getAttribute("range"),
          }
        : null;
      const segments = [];
      segList.querySelectorAll(":scope > SegmentURL").forEach((s) => {
        segments.push({
          url: resolveUrl(baseUrl, s.getAttribute("media") || ""),
          byterange: s.getAttribute("mediaRange"),
        });
      });
      return { init, segments };
    }

    // SegmentBase (single file w/ index range)
    const segBase = rep.querySelector(":scope > SegmentBase");
    if (segBase) {
      const initEl = segBase.querySelector(":scope > Initialization");
      const init = initEl
        ? { url: baseUrl, byterange: initEl.getAttribute("range") }
        : null;
      // Single-file representation: download whole file
      return { init, segments: [{ url: baseUrl }] };
    }

    // No segmenting info — single file
    return { init: null, segments: [{ url: baseUrl }] };
  }

  function parseMpd(xmlText, mpdUrl) {
    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlText, "application/xml");
    if (doc.querySelector("parsererror")) {
      throw new Error("Invalid MPD XML");
    }
    const mpd = doc.documentElement;

    // BaseURL on root
    const rootBase = mpd.querySelector(":scope > BaseURL");
    const baseUrl = rootBase
      ? resolveUrl(mpdUrl, rootBase.textContent.trim())
      : mpdUrl;

    const periods = mpd.querySelectorAll(":scope > Period");
    if (periods.length === 0) throw new Error("No Period in MPD");
    const period = periods[0];

    const representations = [];
    period.querySelectorAll(":scope > AdaptationSet").forEach((as) => {
      const lang = as.getAttribute("lang") || null;
      as.querySelectorAll(":scope > Representation").forEach((rep) => {
        const id = rep.getAttribute("id");
        const bw = parseInt(rep.getAttribute("bandwidth"), 10) || 0;
        const w = parseInt(rep.getAttribute("width"), 10) || null;
        const h = parseInt(rep.getAttribute("height"), 10) || null;
        const codecs = rep.getAttribute("codecs") || as.getAttribute("codecs") || "";
        const mime = rep.getAttribute("mimeType") || as.getAttribute("mimeType") || "";
        const contentType = inferContentType(as, rep);
        representations.push({
          id, bandwidth: bw, width: w, height: h, codecs, mime, contentType, lang,
          rep, adaptationSet: as, period,
        });
      });
    });

    representations.sort((a, b) => {
      const rank = (r) => r.contentType.includes("video") ? 0 : r.contentType.includes("audio") ? 2 : 1;
      const aV = rank(a);
      const bV = rank(b);
      if (aV !== bV) return aV - bV;
      return (b.bandwidth || 0) - (a.bandwidth || 0);
    });

    return { representations, baseUrl };
  }

  async function fetchManifest(url, signal) {
    const res = await fetch(url, {
      credentials: "include",
      cache: "no-store",
      signal,
    });
    if (!res.ok) throw new Error(`MPD HTTP ${res.status}`);
    return res.text();
  }

  async function fetchBytes(url, byterange, signal, retries = MAX_RETRIES) {
    let lastErr;
    let networkAttempts = 0;
    let rateLimitAttempts = 0;

    while (true) {
      await waitForGate(signal);

      try {
        const headers = {};
        if (byterange) headers.Range = `bytes=${byterange}`;
        const ctrl = new AbortController();
        const linked = () => ctrl.abort();
        if (signal) signal.addEventListener("abort", linked, { once: true });
        const timer = setTimeout(() => ctrl.abort(), SEGMENT_TIMEOUT_MS);
        try {
          const res = await fetch(url, {
            credentials: "include",
            cache: "no-store",
            headers,
            signal: ctrl.signal,
          });
          if (res.status === 429 || res.status === 503) {
            try { await res.arrayBuffer(); } catch (_) { /* ignore */ }
            const hint = parseRetryAfter(res.headers.get("retry-after"));
            const backoff = hint != null
              ? Math.min(hint, RATE_LIMIT_BACKOFF_MAX_MS)
              : Math.min(
                  RATE_LIMIT_BACKOFF_BASE_MS * Math.pow(2, rateLimitAttempts),
                  RATE_LIMIT_BACKOFF_MAX_MS
                );
            const jitter = Math.floor(Math.random() * 500);
            bumpThrottleGate(backoff + jitter);
            rateLimitAttempts++;
            lastErr = new Error(`HTTP ${res.status}`);
            if (rateLimitAttempts > RATE_LIMIT_MAX_RETRIES) throw lastErr;
            continue;
          }
          if (!res.ok && res.status !== 206) throw new Error(`HTTP ${res.status}`);
          return new Uint8Array(await res.arrayBuffer());
        } finally {
          clearTimeout(timer);
          if (signal) signal.removeEventListener("abort", linked);
        }
      } catch (e) {
        lastErr = e;
        if (signal && signal.aborted) throw e;
        networkAttempts++;
        if (networkAttempts > retries) throw lastErr;
        await new Promise((r) => setTimeout(r, 500 * networkAttempts));
      }
    }
  }

  async function downloadStream(spec, opts) {
    const { init, segments } = spec;
    const {
      concurrency = DEFAULT_CONCURRENCY,
      signal,
      onProgress,
      isPaused,
      label = "",
    } = opts;

    let initBytes = null;
    if (init && init.url) {
      initBytes = await fetchBytes(init.url, init.byterange, signal);
    }

    const results = new Array(segments.length);
    let completed = 0;
    let totalBytes = initBytes ? initBytes.byteLength : 0;
    let nextIndex = 0;
    let lastTime = Date.now();
    let lastBytes = totalBytes;

    async function worker() {
      while (nextIndex < segments.length) {
        if (signal && signal.aborted) throw new Error("Cancelled");
        while (isPaused && isPaused()) {
          if (signal && signal.aborted) throw new Error("Cancelled");
          await new Promise((r) => setTimeout(r, 200));
        }
        const myIndex = nextIndex++;
        const seg = segments[myIndex];
        const bytes = await fetchBytes(seg.url, seg.byterange, signal);
        results[myIndex] = bytes;
        completed++;
        totalBytes += bytes.byteLength;

        const now = Date.now();
        if (now - lastTime >= 250 || completed === segments.length) {
          const dt = (now - lastTime) / 1000;
          const speed = dt > 0 ? (totalBytes - lastBytes) / dt : 0;
          lastTime = now;
          lastBytes = totalBytes;
          if (onProgress) {
            onProgress({
              completed,
              total: segments.length,
              bytes: totalBytes,
              speed,
              label,
            });
          }
        }
      }
    }

    const n = Math.min(concurrency, Math.max(1, segments.length));
    const workers = [];
    for (let i = 0; i < n; i++) workers.push(worker());
    await Promise.all(workers);

    // Build the result as a Blob rather than a single Uint8Array. Multi-GB
    // streams would otherwise hit the V8 ArrayBuffer ceiling and fail with
    // "Array buffer allocation failed" during the merge step.
    const parts = initBytes ? [initBytes, ...results] : results;
    return new Blob(parts, { type: "application/octet-stream" });
  }

  async function listRepresentations(url, signal) {
    const xml = await fetchManifest(url, signal);
    const parsed = parseMpd(xml, url);
    return parsed.representations.map((r) => ({
      id: r.id,
      bandwidth: r.bandwidth,
      width: r.width,
      height: r.height,
      codecs: r.codecs,
      mime: r.mime,
      contentType: r.contentType,
      lang: r.lang,
      resolution: r.width && r.height ? `${r.width}x${r.height}` : null,
    }));
  }

  // Download a single representation by id (caller picks; if no id, takes
  // best video and merges with first audio if both present).
  async function download(opts) {
    const {
      url,
      videoId = null,
      audioId = null,
      concurrency,
      signal,
      onProgress,
      onPhase,
      isPaused,
    } = opts;

    if (onPhase) onPhase("playlist");
    const xml = await fetchManifest(url, signal);
    const parsed = parseMpd(xml, url);
    const reps = parsed.representations;
    if (reps.length === 0) throw new Error("No representations");

    const videoReps = reps.filter((r) => r.contentType.includes("video"));
    const audioReps = reps.filter((r) => r.contentType.includes("audio"));

    let chosenVideo = null;
    let chosenAudio = null;
    if (videoId) {
      const selected = reps.find((r) => r.id === videoId) || null;
      if (selected?.contentType.includes("audio")) chosenAudio = selected;
      else chosenVideo = selected;
    }
    if (audioId) chosenAudio = reps.find((r) => r.id === audioId) || null;
    if (!chosenVideo && videoReps.length > 0) chosenVideo = videoReps[0];
    if (!chosenAudio && audioReps.length > 0) chosenAudio = audioReps[0];

    if (!chosenVideo && !chosenAudio) {
      // Single-track stream
      if (reps[0].contentType.includes("audio")) chosenAudio = reps[0];
      else chosenVideo = reps[0];
    }

    if (!chosenVideo) {
      throw new Error("Selected DASH manifest is audio-only; no video representation found");
    }

    if (onPhase) onPhase("segments");

    const tracks = [];
    if (chosenVideo) {
      const spec = buildSegments(
        chosenVideo.rep, chosenVideo.adaptationSet, chosenVideo.period, parsed.baseUrl
      );
      tracks.push({ kind: "video", spec, rep: chosenVideo });
    }
    if (chosenAudio && (!chosenVideo || chosenAudio.id !== chosenVideo.id)) {
      const spec = buildSegments(
        chosenAudio.rep, chosenAudio.adaptationSet, chosenAudio.period, parsed.baseUrl
      );
      tracks.push({ kind: "audio", spec, rep: chosenAudio });
    }
    if (tracks.length === 0) throw new Error("No downloadable DASH tracks");

    // Compute combined progress across tracks
    const totalSegments = tracks.reduce((sum, t) => sum + t.spec.segments.length, 0);
    let segDone = 0;
    let bytesDone = 0;
    let lastTime = Date.now();
    let lastBytes = 0;

    function combinedProgress(p) {
      const now = Date.now();
      const dt = (now - lastTime) / 1000;
      const speed = dt > 0 ? (bytesDone + p.bytes - lastBytes) / dt : 0;
      if (now - lastTime >= 250 || segDone + p.completed === totalSegments) {
        lastTime = now;
        lastBytes = bytesDone + p.bytes;
        if (onProgress) {
          onProgress({
            completed: segDone + p.completed,
            total: totalSegments,
            bytes: bytesDone + p.bytes,
            speed,
            label: p.label,
          });
        }
      }
    }

    const buffers = [];
    for (const track of tracks) {
      const buf = await downloadStream(track.spec, {
        concurrency,
        signal,
        onProgress: combinedProgress,
        isPaused,
        label: track.kind,
      });
      buffers.push({ kind: track.kind, buffer: buf, rep: track.rep });
      segDone += track.spec.segments.length;
      bytesDone += buf.size;
    }

    if (onPhase) onPhase("merging");

    // For now: if both video+audio present, save them as separate fmp4 files
    // (browser-side mux of fmp4 v+a tracks needs MSE or muxer lib).
    // Single-track: just blob it.
    if (buffers.length === 1) {
      const isAudio = buffers[0].kind === "audio";
      // buffers[0].buffer is already a Blob from downloadSegmentList; just
      // re-wrap with the correct MIME type so the downloads API picks the
      // right extension.
      const finalBlob = new Blob([buffers[0].buffer], {
        type: isAudio ? "audio/mp4" : "video/mp4",
      });
      return {
        blob: finalBlob,
        ext: isAudio ? "m4a" : "mp4",
        bytes: finalBlob.size,
        segmentCount: totalSegments,
        chosen: { video: chosenVideo, audio: chosenAudio },
      };
    }

    const videoBlob = new Blob([buffers[0].buffer], { type: "video/mp4" });
    const audioBlob = new Blob([buffers[1].buffer], { type: "audio/mp4" });
    return {
      blob: videoBlob,
      audioBlob,
      ext: "mp4",
      bytes: videoBlob.size + audioBlob.size,
      segmentCount: totalSegments,
      chosen: { video: chosenVideo, audio: chosenAudio },
      multiTrack: true,
    };
  }

  window.DASHDownloader = {
    listRepresentations,
    download,
    parseMpd,
  };
})();
