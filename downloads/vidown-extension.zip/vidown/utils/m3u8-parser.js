// Vidown - Simple HLS M3U8 Parser
// Parses master playlists to extract quality variants

window.M3U8Parser = {
  parse(text) {
    if (!text || typeof text !== "string") return { variants: [], isMedia: false };

    const lines = text.split("\n").map((l) => l.trim());
    const isMaster = lines.some((l) => l.startsWith("#EXT-X-STREAM-INF"));

    if (!isMaster) {
      return { variants: [], isMedia: true, isMaster: false };
    }

    const variants = [];
    for (let i = 0; i < lines.length; i++) {
      if (!lines[i].startsWith("#EXT-X-STREAM-INF")) continue;

      const attrs = lines[i].substring("#EXT-X-STREAM-INF:".length);
      const variant = { url: null, bandwidth: null, resolution: null, codecs: null };

      // Parse BANDWIDTH
      const bwMatch = attrs.match(/BANDWIDTH=(\d+)/i);
      if (bwMatch) variant.bandwidth = parseInt(bwMatch[1], 10);

      // Parse RESOLUTION
      const resMatch = attrs.match(/RESOLUTION=(\d+x\d+)/i);
      if (resMatch) variant.resolution = resMatch[1];

      // Parse CODECS
      const codecMatch = attrs.match(/CODECS="([^"]+)"/i);
      if (codecMatch) variant.codecs = codecMatch[1];

      // Parse NAME
      const nameMatch = attrs.match(/NAME="([^"]+)"/i);
      if (nameMatch) variant.name = nameMatch[1];

      // Next non-comment line is the URL
      for (let j = i + 1; j < lines.length; j++) {
        if (lines[j] && !lines[j].startsWith("#")) {
          variant.url = lines[j];
          break;
        }
      }

      if (variant.url) {
        variants.push(variant);
      }
    }

    // Sort by bandwidth descending (highest quality first)
    variants.sort((a, b) => (b.bandwidth || 0) - (a.bandwidth || 0));

    return { variants, isMedia: false, isMaster: true };
  },

  formatBandwidth(bps) {
    if (!bps) return "Unknown";
    if (bps >= 1000000) return (bps / 1000000).toFixed(1) + " Mbps";
    if (bps >= 1000) return (bps / 1000).toFixed(0) + " Kbps";
    return bps + " bps";
  },
};
