// Vidown - Simple DASH MPD Parser
// Parses MPD manifests to extract available representations

window.MPDParser = {
  parse(xmlText) {
    if (!xmlText || typeof xmlText !== "string") return { representations: [] };

    const parser = new DOMParser();
    const doc = parser.parseFromString(xmlText, "application/xml");

    if (doc.querySelector("parsererror")) {
      return { representations: [], error: "Failed to parse MPD XML" };
    }

    const representations = [];
    const adaptationSets = doc.querySelectorAll("AdaptationSet");

    adaptationSets.forEach((as) => {
      const contentType =
        as.getAttribute("contentType") ||
        as.getAttribute("mimeType") ||
        "unknown";
      const lang = as.getAttribute("lang") || null;

      as.querySelectorAll("Representation").forEach((rep) => {
        const entry = {
          id: rep.getAttribute("id"),
          bandwidth: parseInt(rep.getAttribute("bandwidth"), 10) || null,
          width: parseInt(rep.getAttribute("width"), 10) || null,
          height: parseInt(rep.getAttribute("height"), 10) || null,
          mimeType:
            rep.getAttribute("mimeType") || as.getAttribute("mimeType") || null,
          codecs:
            rep.getAttribute("codecs") || as.getAttribute("codecs") || null,
          contentType,
          lang,
        };

        if (entry.width && entry.height) {
          entry.resolution = `${entry.width}x${entry.height}`;
        }

        representations.push(entry);
      });
    });

    // Sort: video first, then by bandwidth descending
    representations.sort((a, b) => {
      const aIsVideo = (a.contentType || a.mimeType || "").includes("video")
        ? 0
        : 1;
      const bIsVideo = (b.contentType || b.mimeType || "").includes("video")
        ? 0
        : 1;
      if (aIsVideo !== bIsVideo) return aIsVideo - bIsVideo;
      return (b.bandwidth || 0) - (a.bandwidth || 0);
    });

    return { representations };
  },

  formatBandwidth(bps) {
    if (!bps) return "Unknown";
    if (bps >= 1000000) return (bps / 1000000).toFixed(1) + " Mbps";
    if (bps >= 1000) return (bps / 1000).toFixed(0) + " Kbps";
    return bps + " bps";
  },
};
