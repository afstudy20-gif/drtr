// Vidown - In-browser HLS Downloader
// Fetches m3u8 master/media playlists, downloads .ts segments concurrently,
// decrypts AES-128 if present, concatenates into a single Blob.
// No native host required.

(function () {
  "use strict";

  const DEFAULT_CONCURRENCY = 6;
  const SEGMENT_TIMEOUT_MS = 30000;
  const MAX_RETRIES = 3;
  // 429/503 get a separate, much longer retry budget — the server is asking
  // us to slow down, not failing, and giving up on the last few segments of
  // a multi-GB download is the worst possible outcome.
  const RATE_LIMIT_MAX_RETRIES = 10;
  const RATE_LIMIT_BACKOFF_BASE_MS = 2000;
  const RATE_LIMIT_BACKOFF_MAX_MS = 60000;

  // Global throttle gate. When the server returns 429/503 with a Retry-After
  // (or even without one), every worker waits past this timestamp before
  // issuing the next request, so a burst from one worker doesn't pile on top
  // of another worker's burst.
  let globalThrottleUntil = 0;

  function parseRetryAfter(headerValue) {
    if (!headerValue) return null;
    const trimmed = String(headerValue).trim();
    const asInt = parseInt(trimmed, 10);
    if (Number.isFinite(asInt) && asInt >= 0) {
      return asInt * 1000;
    }
    const asDate = Date.parse(trimmed);
    if (Number.isFinite(asDate)) {
      const delta = asDate - Date.now();
      return delta > 0 ? delta : 0;
    }
    return null;
  }

  async function waitForGate(signal) {
    while (true) {
      const wait = globalThrottleUntil - Date.now();
      if (wait <= 0) return;
      if (signal && signal.aborted) throw new Error("Cancelled");
      await new Promise((r) => setTimeout(r, Math.min(wait, 500)));
    }
  }

  function bumpThrottleGate(ms) {
    const target = Date.now() + ms;
    if (target > globalThrottleUntil) globalThrottleUntil = target;
  }

  function resolveUrl(base, ref) {
    try {
      return new URL(ref, base).toString();
    } catch {
      return ref;
    }
  }

  function parseAttrList(str) {
    const out = {};
    const re = /([A-Z0-9-]+)=(?:"([^"]*)"|([^,]*))/gi;
    let m;
    while ((m = re.exec(str)) !== null) {
      out[m[1].toUpperCase()] = m[2] !== undefined ? m[2] : m[3];
    }
    return out;
  }

  function inferVariantKind(attrs, url) {
    const codecs = String(attrs.CODECS || "").toLowerCase();
    const hasVideoCodec = /(avc1|avc3|hvc1|hev1|dvhe|dvh1|vp09|vp9|av01)/i.test(codecs);
    const hasAudioCodec = /(mp4a|ac-3|ec-3|opus|vorbis|aac)/i.test(codecs);
    if (attrs.RESOLUTION || hasVideoCodec) return "video";
    if (hasAudioCodec && !hasVideoCodec) return "audio";
    if (/([/_-])(audio|aac|m4a|mp3)([._/?#-]|$)/i.test(url || "")) return "audio";
    return "unknown";
  }

  function parseMasterSubtitles(text, baseUrl) {
    const subtitles = [];
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line.startsWith("#EXT-X-MEDIA:")) continue;
      const attrs = parseAttrList(line.substring("#EXT-X-MEDIA:".length));
      if ((attrs.TYPE || "").toUpperCase() !== "SUBTITLES") continue;
      if (!attrs.URI) continue;
      subtitles.push({
        url: resolveUrl(baseUrl, attrs.URI),
        groupId: attrs["GROUP-ID"] || "",
        name: attrs.NAME || attrs.LANGUAGE || "subtitles",
        lang: attrs.LANGUAGE || attrs.NAME || "sub",
        default: String(attrs.DEFAULT || "").toUpperCase() === "YES",
        autoselect: String(attrs.AUTOSELECT || "").toUpperCase() === "YES",
        forced: String(attrs.FORCED || "").toUpperCase() === "YES",
      });
    }
    return subtitles;
  }

  function parseMasterAudio(text, baseUrl) {
    const audio = [];
    for (const raw of text.split(/\r?\n/)) {
      const line = raw.trim();
      if (!line.startsWith("#EXT-X-MEDIA:")) continue;
      const attrs = parseAttrList(line.substring("#EXT-X-MEDIA:".length));
      if ((attrs.TYPE || "").toUpperCase() !== "AUDIO") continue;
      if (!attrs.URI) continue;
      audio.push({
        url: resolveUrl(baseUrl, attrs.URI),
        groupId: attrs["GROUP-ID"] || "",
        name: attrs.NAME || attrs.LANGUAGE || "audio",
        lang: attrs.LANGUAGE || attrs.NAME || "audio",
        default: String(attrs.DEFAULT || "").toUpperCase() === "YES",
        autoselect: String(attrs.AUTOSELECT || "").toUpperCase() === "YES",
      });
    }
    return audio;
  }

  function parseMaster(text, baseUrl) {
    const lines = text.split(/\r?\n/);
    const variants = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();
      if (!line.startsWith("#EXT-X-STREAM-INF")) continue;
      const attrs = parseAttrList(line.substring("#EXT-X-STREAM-INF:".length));
      let urlLine = null;
      for (let j = i + 1; j < lines.length; j++) {
        const next = lines[j].trim();
        if (next && !next.startsWith("#")) {
          urlLine = next;
          break;
        }
      }
      if (!urlLine) continue;
      const resolvedUrl = resolveUrl(baseUrl, urlLine);
      variants.push({
        url: resolvedUrl,
        bandwidth: parseInt(attrs.BANDWIDTH || "0", 10),
        resolution: attrs.RESOLUTION || null,
        codecs: attrs.CODECS || null,
        name: attrs.NAME || null,
        audioGroup: attrs.AUDIO || null,
        subtitlesGroup: attrs.SUBTITLES || null,
        kind: inferVariantKind(attrs, resolvedUrl),
      });
    }
    variants.sort((a, b) => {
      const rank = { video: 0, unknown: 1, audio: 2 };
      const ar = rank[a.kind] ?? 1;
      const br = rank[b.kind] ?? 1;
      if (ar !== br) return ar - br;
      return (b.bandwidth || 0) - (a.bandwidth || 0);
    });
    return variants;
  }

  function parseMedia(text, baseUrl) {
    const lines = text.split(/\r?\n/);
    const segments = [];
    let currentKey = null;
    let currentInit = null;
    let mediaSequence = 0;
    let segIndex = 0;
    let pendingByteRange = null;
    let pendingDuration = 0;

    for (let i = 0; i < lines.length; i++) {
      const line = lines[i].trim();

      if (line.startsWith("#EXT-X-MEDIA-SEQUENCE:")) {
        mediaSequence = parseInt(line.substring(22), 10) || 0;
        segIndex = mediaSequence;
        continue;
      }

      if (line.startsWith("#EXT-X-KEY")) {
        const attrs = parseAttrList(line.substring("#EXT-X-KEY:".length));
        const method = (attrs.METHOD || "NONE").toUpperCase();
        if (method === "NONE") {
          currentKey = null;
        } else {
          currentKey = {
            method,
            uri: attrs.URI ? resolveUrl(baseUrl, attrs.URI) : null,
            iv: attrs.IV || null,
            keyformat: attrs.KEYFORMAT || "identity",
          };
        }
        continue;
      }

      if (line.startsWith("#EXT-X-MAP:")) {
        const attrs = parseAttrList(line.substring(11));
        currentInit = {
          uri: attrs.URI ? resolveUrl(baseUrl, attrs.URI) : null,
          byterange: attrs.BYTERANGE || null,
        };
        continue;
      }

      if (line.startsWith("#EXTINF:")) {
        pendingDuration = parseFloat(line.substring(8).split(",")[0]) || 0;
        continue;
      }

      if (line.startsWith("#EXT-X-BYTERANGE:")) {
        pendingByteRange = line.substring(17);
        continue;
      }

      if (!line || line.startsWith("#")) continue;

      segments.push({
        url: resolveUrl(baseUrl, line),
        duration: pendingDuration,
        byterange: pendingByteRange,
        key: currentKey,
        init: currentInit,
        sequence: segIndex,
      });
      segIndex++;
      pendingDuration = 0;
      pendingByteRange = null;
    }

    return segments;
  }

  async function fetchPlaylist(url, signal) {
    const res = await fetch(url, {
      credentials: "include",
      cache: "no-store",
      signal,
    });
    if (!res.ok) throw new Error(`Playlist HTTP ${res.status}`);
    return res.text();
  }

  async function fetchText(url, signal) {
    const res = await fetch(url, {
      credentials: "include",
      cache: "no-store",
      signal,
    });
    if (!res.ok) throw new Error(`Text HTTP ${res.status}`);
    return res.text();
  }

  async function fetchSegmentBytes(url, byteRange, signal, retries = MAX_RETRIES) {
    let lastErr;
    let networkAttempts = 0;
    let rateLimitAttempts = 0;

    while (true) {
      await waitForGate(signal);

      try {
        const headers = {};
        if (byteRange) {
          const [len, off] = byteRange.split("@");
          const offset = off ? parseInt(off, 10) : 0;
          const length = parseInt(len, 10);
          headers.Range = `bytes=${offset}-${offset + length - 1}`;
        }
        const ctrl = new AbortController();
        const linked = () => ctrl.abort();
        if (signal) signal.addEventListener("abort", linked, { once: true });
        const timer = setTimeout(() => ctrl.abort(), SEGMENT_TIMEOUT_MS);
        try {
          const res = await fetch(url, {
            credentials: "include",
            cache: "no-store",
            headers,
            signal: ctrl.signal,
          });
          if (res.status === 429 || res.status === 503) {
            // Drain body so the connection can be reused.
            try { await res.arrayBuffer(); } catch (_) { /* ignore */ }
            const hint = parseRetryAfter(res.headers.get("retry-after"));
            const backoff = hint != null
              ? Math.min(hint, RATE_LIMIT_BACKOFF_MAX_MS)
              : Math.min(
                  RATE_LIMIT_BACKOFF_BASE_MS * Math.pow(2, rateLimitAttempts),
                  RATE_LIMIT_BACKOFF_MAX_MS
                );
            // Jitter so workers don't re-synchronize on the same retry.
            const jitter = Math.floor(Math.random() * 500);
            bumpThrottleGate(backoff + jitter);
            rateLimitAttempts++;
            lastErr = new Error(`HTTP ${res.status}`);
            if (rateLimitAttempts > RATE_LIMIT_MAX_RETRIES) throw lastErr;
            continue;
          }
          if (!res.ok && res.status !== 206) {
            throw new Error(`HTTP ${res.status}`);
          }
          return new Uint8Array(await res.arrayBuffer());
        } finally {
          clearTimeout(timer);
          if (signal) signal.removeEventListener("abort", linked);
        }
      } catch (e) {
        lastErr = e;
        if (signal && signal.aborted) throw e;
        // Network errors / non-rate-limit HTTP errors use the original
        // short retry budget so true failures fail fast.
        networkAttempts++;
        if (networkAttempts > retries) throw lastErr;
        await new Promise((r) => setTimeout(r, 500 * networkAttempts));
      }
    }
  }

  function ivFromHex(hex) {
    const clean = hex.replace(/^0x/i, "");
    const bytes = new Uint8Array(16);
    const padded = clean.padStart(32, "0");
    for (let i = 0; i < 16; i++) {
      bytes[i] = parseInt(padded.substr(i * 2, 2), 16);
    }
    return bytes;
  }

  function ivFromSequence(seq) {
    const iv = new Uint8Array(16);
    const view = new DataView(iv.buffer);
    view.setUint32(8, Math.floor(seq / 0x100000000));
    view.setUint32(12, seq >>> 0);
    return iv;
  }

  const keyCache = new Map();

  async function fetchKey(uri, signal) {
    if (keyCache.has(uri)) return keyCache.get(uri);
    const res = await fetch(uri, { credentials: "include", signal });
    if (!res.ok) throw new Error(`Key HTTP ${res.status}`);
    const buf = await res.arrayBuffer();
    if (buf.byteLength !== 16) throw new Error("Invalid AES-128 key length");
    const cryptoKey = await crypto.subtle.importKey(
      "raw",
      buf,
      { name: "AES-CBC" },
      false,
      ["decrypt"]
    );
    keyCache.set(uri, cryptoKey);
    return cryptoKey;
  }

  async function decryptSegment(bytes, keyInfo, sequence, signal) {
    if (!keyInfo || keyInfo.method === "NONE") return bytes;
    if (keyInfo.method !== "AES-128") {
      throw new Error(`Unsupported encryption: ${keyInfo.method}`);
    }
    if (!keyInfo.uri) throw new Error("Key URI missing");
    const cryptoKey = await fetchKey(keyInfo.uri, signal);
    const iv = keyInfo.iv ? ivFromHex(keyInfo.iv) : ivFromSequence(sequence);
    const decrypted = await crypto.subtle.decrypt(
      { name: "AES-CBC", iv },
      cryptoKey,
      bytes
    );
    return new Uint8Array(decrypted);
  }

  // Concurrent worker pool
  async function downloadSegments(segments, opts) {
    const {
      concurrency = DEFAULT_CONCURRENCY,
      signal,
      onProgress,
      isPaused,
    } = opts;

    const results = new Array(segments.length);
    let completed = 0;
    let totalBytes = 0;
    const startTime = Date.now();
    let lastProgressTime = startTime;
    let lastProgressBytes = 0;

    let nextIndex = 0;

    async function worker() {
      while (nextIndex < segments.length) {
        if (signal && signal.aborted) throw new Error("Cancelled");
        while (isPaused && isPaused()) {
          if (signal && signal.aborted) throw new Error("Cancelled");
          await new Promise((r) => setTimeout(r, 200));
        }
        const myIndex = nextIndex++;
        const seg = segments[myIndex];
        const raw = await fetchSegmentBytes(seg.url, seg.byterange, signal);
        const decrypted = await decryptSegment(raw, seg.key, seg.sequence, signal);
        results[myIndex] = decrypted;
        completed++;
        totalBytes += decrypted.byteLength;

        const now = Date.now();
        const elapsedSinceLast = (now - lastProgressTime) / 1000;
        const speed = elapsedSinceLast > 0
          ? (totalBytes - lastProgressBytes) / elapsedSinceLast
          : 0;
        if (now - lastProgressTime >= 250 || completed === segments.length) {
          lastProgressTime = now;
          lastProgressBytes = totalBytes;
          if (onProgress) {
            const avgSegSize = totalBytes / completed;
            const remaining = segments.length - completed;
            const eta = speed > 0
              ? Math.round((avgSegSize * remaining) / speed)
              : 0;
            onProgress({
              completed,
              total: segments.length,
              bytes: totalBytes,
              speed,
              eta,
            });
          }
        }
      }
    }

    const workers = [];
    const n = Math.min(concurrency, segments.length);
    for (let i = 0; i < n; i++) workers.push(worker());
    await Promise.all(workers);
    return results;
  }

  function concatChunks(chunks, prepend) {
    let total = prepend ? prepend.byteLength : 0;
    for (const c of chunks) total += c.byteLength;
    const out = new Uint8Array(total);
    let offset = 0;
    if (prepend) {
      out.set(prepend, 0);
      offset = prepend.byteLength;
    }
    for (const c of chunks) {
      out.set(c, offset);
      offset += c.byteLength;
    }
    return out;
  }

  // Like concatChunks but builds a Blob directly. A single Uint8Array is
  // capped at ~2 GiB on V8 (and dies with "Array buffer allocation failed"
  // well before that under memory pressure), so anything large — multi-GB
  // HLS streams, especially — must avoid the contiguous allocation. Blob
  // stores its parts internally and never materializes them as one buffer.
  function concatToBlob(chunks, prepend, type) {
    const parts = prepend ? [prepend, ...chunks] : chunks;
    return new Blob(parts, { type });
  }

  async function readBlobHeader(blob, maxBytes) {
    const limit = Math.min(maxBytes, blob.size);
    if (limit === 0) return new Uint8Array(0);
    return new Uint8Array(await blob.slice(0, limit).arrayBuffer());
  }

  function asciiAt(bytes, offset, length) {
    if (!bytes || offset < 0 || offset + length > bytes.byteLength) return "";
    let out = "";
    for (let i = 0; i < length; i++) out += String.fromCharCode(bytes[offset + i]);
    return out;
  }

  function detectMp4Tracks(bytes) {
    const tracks = { hasVideo: false, hasAudio: false };
    if (!bytes || bytes.byteLength < 24) return tracks;
    for (let i = 4; i < bytes.byteLength - 16; i++) {
      if (asciiAt(bytes, i, 4) !== "hdlr") continue;
      const handler = asciiAt(bytes, i + 12, 4);
      if (handler === "vide") tracks.hasVideo = true;
      if (handler === "soun") tracks.hasAudio = true;
      if (tracks.hasVideo && tracks.hasAudio) break;
    }
    return tracks;
  }

  function inspectTsTracks(chunks) {
    const tracks = { hasVideo: false, hasAudio: false };
    if (typeof globalThis.muxjs === "undefined" || !muxjs.mp2t?.tools?.inspect) {
      return tracks;
    }
    for (const chunk of chunks.slice(0, 8)) {
      try {
        const info = muxjs.mp2t.tools.inspect(chunk);
        if (info?.video) tracks.hasVideo = true;
        if (info?.audio) tracks.hasAudio = true;
        if (tracks.hasVideo && tracks.hasAudio) break;
      } catch {}
    }
    return tracks;
  }

  // Transmux MPEG-TS chunks → fragmented MP4 using mux.js (must be loaded
  // before this script). Returns Uint8Array of init+media (single fmp4 file)
  // or throws if mux.js unavailable / transmux fails.
  function transmuxTsToMp4(tsChunks, onProgress) {
    if (typeof globalThis.muxjs === "undefined" || !muxjs.mp4 || !muxjs.mp4.Transmuxer) {
      throw new Error("mux.js not loaded");
    }
    return new Promise((resolve, reject) => {
      try {
        const transmuxer = new muxjs.mp4.Transmuxer({ remux: true, keepOriginalTimestamps: true });
        const out = [];
        let initSegment = null;

        transmuxer.on("data", (event) => {
          if (event.type === "combined" || event.type === "video" || !event.type) {
            if (event.initSegment && !initSegment) {
              initSegment = new Uint8Array(event.initSegment);
            }
            if (event.data) {
              out.push(new Uint8Array(event.data));
            }
          }
        });

        transmuxer.on("done", () => {
          if (!initSegment || out.length === 0) {
            reject(new Error("Transmux produced no output"));
            return;
          }
          // Avoid the contiguous Uint8Array — large streams (multi-GB)
          // would blow past the V8 ArrayBuffer limit.
          resolve(new Blob([initSegment, ...out], { type: "video/mp4" }));
        });

        // Feed TS chunks one by one; flush after.
        for (let i = 0; i < tsChunks.length; i++) {
          transmuxer.push(tsChunks[i]);
          if (onProgress) onProgress(i + 1, tsChunks.length);
        }
        transmuxer.flush();
      } catch (e) {
        reject(e);
      }
    });
  }

  // Extract raw AAC audio (ADTS) from MPEG-TS chunks. Demuxes the audio PID,
  // pulls AAC frames out of the PES, prepends ADTS header so the result is a
  // standalone .aac file (playable in any media player; transcode to MP3
  // outside the browser if needed).
  function extractAacFromTs(tsChunks) {
    if (typeof globalThis.muxjs === "undefined" || !muxjs.mp2t) {
      throw new Error("mux.js mp2t module not available");
    }
    // Use TransportPacketStream → TransportParseStream → ElementaryStream
    // → AacStream (from videojs/mux.js). Public API exposes only Transmuxer
    // for direct use; for AAC we still use Transmuxer and grab the audio
    // segment, which is fmp4 but contains AAC. Simplest portable path: run
    // Transmuxer in audio-only mode and save the fmp4 with .m4a (universally
    // playable + correctly tagged). True .aac extraction would require
    // re-implementing demux; .m4a covers the user need.
    return new Promise((resolve, reject) => {
      try {
        const transmuxer = new muxjs.mp4.Transmuxer({ remux: true });
        const out = [];
        let initSegment = null;
        transmuxer.on("data", (event) => {
          if (event.type === "audio") {
            if (event.initSegment && !initSegment) {
              initSegment = new Uint8Array(event.initSegment);
            }
            if (event.data) out.push(new Uint8Array(event.data));
          }
        });
        transmuxer.on("done", () => {
          if (!initSegment || out.length === 0) {
            reject(new Error("No audio track in stream"));
            return;
          }
          resolve(new Blob([initSegment, ...out], { type: "audio/mp4" }));
        });
        for (const c of tsChunks) transmuxer.push(c);
        transmuxer.flush();
      } catch (e) {
        reject(e);
      }
    });
  }

  async function fetchAndParse(url, signal) {
    const text = await fetchPlaylist(url, signal);
    const isMaster = /#EXT-X-STREAM-INF/.test(text);
    if (isMaster) {
      return {
        kind: "master",
        variants: parseMaster(text, url),
        audio: parseMasterAudio(text, url),
        subtitles: parseMasterSubtitles(text, url),
      };
    }
    return { kind: "media", segments: parseMedia(text, url) };
  }

  // Resolve a URL down to a media playlist. If master, pick variant by
  // resolution match or by index; if no index, pick highest bandwidth.
  async function resolveToMedia(url, variantUrl, signal) {
    const parsed = await fetchAndParse(url, signal);
    if (parsed.kind === "media") {
      return { variants: [], segments: parsed.segments, mediaUrl: url };
    }
    const variants = parsed.variants;
    if (variants.length === 0) throw new Error("No variants in master playlist");
    let chosen = variants.find((v) => v.kind !== "audio") || variants[0];
    if (variantUrl) {
      const match = variants.find((v) => v.url === variantUrl);
      if (match) chosen = match;
    }
    const inner = await fetchAndParse(chosen.url, signal);
    if (inner.kind !== "media") {
      throw new Error("Nested master playlist not supported");
    }
    return { variants, segments: inner.segments, mediaUrl: chosen.url, chosen };
  }

  async function listVariants(url, signal) {
    const parsed = await fetchAndParse(url, signal);
    if (parsed.kind === "master") return parsed.variants;
    return [];
  }

  function normalizeSubtitleName(text) {
    return String(text || "sub")
      .replace(/[<>:"/\\|?*\x00-\x1f]/g, "")
      .replace(/\s+/g, "_")
      .replace(/[^\w.-]+/g, "_")
      .replace(/^_+|_+$/g, "")
      .substring(0, 60) || "sub";
  }

  function mergeVttTexts(texts) {
    const cueBlocks = [];
    for (const text of texts) {
      const lines = String(text || "").split(/\r?\n/);
      const kept = [];
      for (const line of lines) {
        if (/^\s*WEBVTT/i.test(line)) continue;
        if (/^\s*X-TIMESTAMP-MAP:/i.test(line)) continue;
        kept.push(line);
      }
      const body = kept.join("\n").trim();
      if (body) cueBlocks.push(body);
    }
    return "WEBVTT\n\n" + cueBlocks.join("\n\n") + "\n";
  }

  async function downloadSubtitleTrack(track, signal) {
    const text = await fetchText(track.url, signal);
    if (!/#EXTM3U|#EXT-X-/i.test(text)) {
      return {
        ...track,
        ext: /\.srt(\?|#|$)/i.test(track.url) ? "srt" : "vtt",
        text,
        bytes: new TextEncoder().encode(text).byteLength,
      };
    }

    const segments = parseMedia(text, track.url);
    const texts = [];
    for (const seg of segments) {
      texts.push(await fetchText(seg.url, signal));
    }
    const merged = mergeVttTexts(texts);
    return {
      ...track,
      ext: "vtt",
      text: merged,
      bytes: new TextEncoder().encode(merged).byteLength,
    };
  }

  async function downloadSubtitles(opts) {
    const { url, variantUrl, signal } = opts;
    const text = await fetchPlaylist(url, signal);
    if (!/#EXT-X-STREAM-INF/.test(text)) return [];

    const subtitles = parseMasterSubtitles(text, url);
    if (subtitles.length === 0) return [];

    const variants = parseMaster(text, url);
    const chosen = variantUrl
      ? variants.find((v) => v.url === variantUrl)
      : variants.find((v) => v.kind !== "audio") || variants[0];
    const group = chosen?.subtitlesGroup || "";
    const selected = group
      ? subtitles.filter((s) => s.groupId === group)
      : subtitles;
    const tracks = selected.length ? selected : subtitles;

    const out = [];
    for (const track of tracks) {
      const downloaded = await downloadSubtitleTrack(track, signal);
      out.push({
        ...downloaded,
        safeName: normalizeSubtitleName(downloaded.lang || downloaded.name || "sub"),
      });
    }
    return out;
  }

  async function downloadAudioForVariant(opts) {
    const {
      url,
      variantUrl,
      signal,
      concurrency = DEFAULT_CONCURRENCY,
      onProgress,
      isPaused,
    } = opts;
    const text = await fetchPlaylist(url, signal);
    if (!/#EXT-X-STREAM-INF/.test(text)) return null;

    const variants = parseMaster(text, url);
    const audioTracks = parseMasterAudio(text, url);
    if (audioTracks.length === 0) return null;

    const chosen = variantUrl
      ? variants.find((v) => v.url === variantUrl)
      : variants.find((v) => v.kind !== "audio") || variants[0];
    const group = chosen?.audioGroup || "";
    const candidates = group
      ? audioTracks.filter((a) => a.groupId === group)
      : audioTracks;
    const track = candidates.find((a) => a.default) || candidates[0] || audioTracks[0];
    if (!track) return null;

    const parsed = await fetchAndParse(track.url, signal);
    if (parsed.kind !== "media" || parsed.segments.length === 0) return null;

    let initBytes = null;
    const firstInit = parsed.segments[0].init;
    if (firstInit && firstInit.uri) {
      initBytes = await fetchSegmentBytes(firstInit.uri, firstInit.byterange, signal);
    }

    const chunks = await downloadSegments(parsed.segments, {
      concurrency,
      signal,
      onProgress,
      isPaused,
    });
    const ext = initBytes ? "m4a" : "ts";
    const type = initBytes ? "audio/mp4" : "video/mp2t";
    const blob = concatToBlob(chunks, initBytes, type);
    return {
      ...track,
      blob,
      ext,
      bytes: blob.size,
    };
  }

  async function download(opts) {
    const {
      url,
      variantUrl,
      concurrency,
      signal,
      onProgress,
      onPhase,
      isPaused,
      outputFormat = "auto", // "auto" | "mp4" | "ts"
    } = opts;

    if (onPhase) onPhase("playlist");
    const resolved = await resolveToMedia(url, variantUrl, signal);
    if (resolved.segments.length === 0) {
      throw new Error("No segments found");
    }

    // Fetch init segment if EXT-X-MAP present
    let initBytes = null;
    const firstInit = resolved.segments[0].init;
    if (firstInit && firstInit.uri) {
      if (onPhase) onPhase("init");
      initBytes = await fetchSegmentBytes(firstInit.uri, firstInit.byterange, signal);
    }

    if (onPhase) onPhase("segments");
    const chunks = await downloadSegments(resolved.segments, {
      concurrency,
      signal,
      onProgress,
      isPaused,
    });

    // Three output paths:
    //  - fmp4 stream (init segment present): just concat → .mp4
    //  - MPEG-TS w/ mux.js available + outputFormat != "ts": transmux → .mp4
    //  - else: concat → .ts (VLC plays it; user can convert)
    if (initBytes) {
      if (onPhase) onPhase("merging");
      // Probe the leading 1 MiB to identify track types without materializing
      // the whole stream as one buffer.
      const probeBlob = concatToBlob(chunks, initBytes, "application/octet-stream");
      const header = await readBlobHeader(probeBlob, 1048576);
      const tracks = detectMp4Tracks(header);
      const isAudio = resolved.chosen?.kind === "audio" || (tracks.hasAudio && !tracks.hasVideo);
      if (isAudio && outputFormat !== "aac") {
        throw new Error("Selected HLS playlist is audio-only; no video track found");
      }
      const finalType = isAudio ? "audio/mp4" : "video/mp4";
      const finalBlob = concatToBlob(chunks, initBytes, finalType);
      return {
        blob: finalBlob,
        ext: isAudio ? "m4a" : "mp4",
        segmentCount: resolved.segments.length,
        bytes: finalBlob.size,
        chosen: resolved.chosen || null,
      };
    }

    if (outputFormat === "aac") {
      if (onPhase) onPhase("transmux");
      try {
        const audioBlob = await extractAacFromTs(chunks);
        return {
          blob: audioBlob,
          ext: "m4a",
          segmentCount: resolved.segments.length,
          bytes: audioBlob.size,
          chosen: resolved.chosen || null,
        };
      } catch (e) {
        throw new Error("Audio extract failed: " + (e.message || e));
      }
    }

    const wantMp4 = outputFormat !== "ts"
      && typeof globalThis.muxjs !== "undefined"
      && globalThis.muxjs.mp4
      && globalThis.muxjs.mp4.Transmuxer;

    const tsTracks = inspectTsTracks(chunks);
    if (!tsTracks.hasVideo && outputFormat !== "aac") {
      throw new Error("Selected HLS playlist is audio-only; no video track found");
    }

    if (wantMp4) {
      if (onPhase) onPhase("transmux");
      try {
        const mp4Blob = await transmuxTsToMp4(chunks, (done, total) => {
          if (onProgress) {
            onProgress({
              completed: done,
              total,
              bytes: 0,
              speed: 0,
              eta: 0,
              phase: "transmux",
            });
          }
        });
        const header = await readBlobHeader(mp4Blob, 1048576);
        const mp4Tracks = detectMp4Tracks(header);
        if (!mp4Tracks.hasVideo) {
          throw new Error("MP4 transmux produced no video track");
        }
        return {
          blob: mp4Blob,
          ext: "mp4",
          segmentCount: resolved.segments.length,
          bytes: mp4Blob.size,
          chosen: resolved.chosen || null,
        };
      } catch (e) {
        if (outputFormat === "mp4") throw new Error("MP4 transmux failed: " + (e.message || e));
        // Fall through to .ts on auto.
      }
    }

    if (onPhase) onPhase("merging");
    const tsBlob = concatToBlob(chunks, null, "video/mp2t");
    return {
      blob: tsBlob,
      ext: "ts",
      segmentCount: resolved.segments.length,
      bytes: tsBlob.size,
      chosen: resolved.chosen || null,
    };
  }

  window.HLSDownloader = {
    listVariants,
    downloadSubtitles,
    downloadAudioForVariant,
    download,
    parseMaster,
    parseMasterAudio,
    parseMasterSubtitles,
    parseMedia,
  };
})();
