// Vidown - HLS variant grouping
// Collapse multiple m3u8 entries from same stream (master + child playlists)
// into a single representative row. Adapted from omniget patterns.

(function () {
  "use strict";

  const MASTER_NAMES = new Set([
    "master", "playlist", "index", "main", "manifest", "stream",
  ]);

  const QUALITY_LABELS = new Set([
    "high", "medium", "low", "sd", "hd", "fhd", "uhd", "best", "auto",
    "video", "audio",
  ]);

  function getVariantToken(filename) {
    if (!filename) return "";
    const lower = String(filename).toLowerCase();
    const extStripped = lower.replace(/\.m3u8(\?.*)?$/, "")
                              .replace(/\.mpd(\?.*)?$/, "");
    const base = extStripped.split("?")[0];
    if (!base) return "";
    if (MASTER_NAMES.has(base)) return "master";
    if (/^\d{3,4}p?$/.test(base)) return "master";
    if (QUALITY_LABELS.has(base)) return "master";
    return base;
  }

  function getGroupKey(url) {
    try {
      const u = new URL(url);
      const parts = u.pathname.split("/");
      const filename = parts.pop() || "";
      const dir = parts.join("/");
      const variant = getVariantToken(filename);
      return `${u.origin}${dir}|${variant}`;
    } catch {
      return url;
    }
  }

  // Group an array of video entries. Streams (HLS/DASH) sharing a directory
  // are collapsed to a single representative chosen by:
  //   1) URL containing "master"/"playlist"/"index" wins
  //   2) Shortest path wins (master usually higher in tree)
  //   3) First seen
  function groupStreams(videos) {
    const groups = new Map();
    const out = [];

    for (const v of videos) {
      const t = (v.type || "").toLowerCase();
      if (t !== "hls" && t !== "dash") {
        out.push(v);
        continue;
      }
      const key = getGroupKey(v.url);
      const existing = groups.get(key);
      if (!existing) {
        groups.set(key, { entry: v, count: 1 });
        continue;
      }
      existing.count++;
      if (preferAsRepresentative(v.url, existing.entry.url)) {
        existing.entry = v;
      }
    }

    for (const { entry, count } of groups.values()) {
      out.push(count > 1 ? { ...entry, groupCount: count } : entry);
    }
    return out;
  }

  function preferAsRepresentative(candidate, current) {
    const isMasterName = (url) => {
      try {
        const fn = new URL(url).pathname.split("/").pop().toLowerCase();
        return /master|playlist|index|manifest/.test(fn);
      } catch { return false; }
    };
    const candIsMaster = isMasterName(candidate);
    const curIsMaster = isMasterName(current);
    if (candIsMaster && !curIsMaster) return true;
    if (!candIsMaster && curIsMaster) return false;

    // Prioritize video/master streams over audio-only streams
    const isAudioOnly = (url) => {
      const lower = url.toLowerCase();
      // If it contains "v" or "video" or "v1" etc. as a word/marker, it is video, not audio-only!
      const hasVideo = /[\W_](video|vid|v\d+)[\W_]/i.test(lower) || 
                       /[-_]v(\?|\.|$)/i.test(lower);
      if (hasVideo) return false;

      return /[\W_](audio|sound|aac|mp3|m4a)[\W_]/i.test(lower) || 
             /[\W_]a\d+[\W_]/i.test(lower) || 
             /[-_]a(\?|\.|$)/i.test(lower);
    };
    const candAudio = isAudioOnly(candidate);
    const curAudio = isAudioOnly(current);
    if (!candAudio && curAudio) return true;
    if (candAudio && !curAudio) return false;

    // Shorter URL wins (less specific = closer to master)
    return candidate.length < current.length;
  }

  window.HLSGrouping = {
    getVariantToken,
    getGroupKey,
    groupStreams,
  };
})();
