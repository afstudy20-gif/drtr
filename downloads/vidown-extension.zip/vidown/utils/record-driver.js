// Vidown - In-page Recording Driver
// Injected into the MAIN world via chrome.scripting.executeScript when the
// user clicks Record. Captures the largest visible <video> element using
// captureStream() + MediaRecorder, sends final WebM blob URL to extension.
//
// Supports two flows:
//   1. Quick start — record from current position until the user stops.
//   2. Trim mode  — pick a video on the page, set start/end times in a
//      small in-page modal, then record only that range. The video is
//      seeked to `start` and stopped automatically at `end`.
(function () {
  "use strict";

  if (window.__VIDOWN_RECORDER_ACTIVE) {
    window.postMessage({ type: "VIDOWN_RECORD_STATUS", status: "already-active" }, "*");
    return;
  }
  window.__VIDOWN_RECORDER_ACTIVE = true;

  // Recording options stashed by the popup before injection.
  const userOpts = window.__VIDOWN_RECORD_OPTS || {};
  const wantsTrim = userOpts.trim === true;

  function pickLargestVideo() {
    const videos = Array.from(document.querySelectorAll("video"));
    if (videos.length === 0) return null;
    let best = null;
    let bestArea = 0;
    for (const v of videos) {
      const r = v.getBoundingClientRect();
      const area = r.width * r.height;
      if (area > bestArea && !v.paused) {
        best = v;
        bestArea = area;
      }
    }
    if (!best) {
      for (const v of videos) {
        const r = v.getBoundingClientRect();
        const area = r.width * r.height;
        if (area > bestArea) {
          best = v;
          bestArea = area;
        }
      }
    }
    return best;
  }

  function formatSeconds(s) {
    s = Math.max(0, Math.floor(s));
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  }

  function parseSeconds(str) {
    const parts = str.split(":").map((n) => parseInt(n, 10));
    if (parts.length !== 3 || parts.some(Number.isNaN)) return null;
    return parts[0] * 3600 + parts[1] * 60 + parts[2];
  }

  function createTrimModal(video) {
    return new Promise((resolve) => {
      const overlay = document.createElement("div");
      overlay.style.cssText = `
        position: fixed; inset: 0;
        background: rgba(0,0,0,0.65);
        z-index: 2147483646;
        display: flex; align-items: center; justify-content: center;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      `;

      const modal = document.createElement("div");
      modal.style.cssText = `
        background: #1a1a30; color: #e0e0e0;
        border: 1px solid #2a2a4a; border-radius: 12px;
        padding: 20px; min-width: 320px; max-width: 90vw;
        box-shadow: 0 12px 40px rgba(0,0,0,0.5);
      `;

      const dur = Number.isFinite(video.duration) ? video.duration : null;
      const isLive = !dur;
      const durStr = isLive ? "Live" : formatSeconds(dur);

      modal.innerHTML = `
        <div style="font-size: 14px; font-weight: 700; margin-bottom: 12px;">Record clip</div>
        <div style="font-size: 11px; color: #888; margin-bottom: 12px;">
          Duration: <strong style="color:#ccc">${durStr}</strong>
        </div>
        ${isLive ? "" : `
          <div style="display: flex; gap: 8px; margin-bottom: 12px;">
            <label style="flex:1;">
              <div style="font-size:11px;color:#aaa;margin-bottom:4px;">Start</div>
              <input id="vd-start" type="time" step="1" value="00:00:00"
                     style="width:100%;padding:6px;background:#0f0f1a;border:1px solid #2a2a4a;border-radius:4px;color:#fff;font-family:ui-monospace,Menlo,monospace;">
            </label>
            <label style="flex:1;">
              <div style="font-size:11px;color:#aaa;margin-bottom:4px;">End</div>
              <input id="vd-end" type="time" step="1" value="${formatSeconds(dur)}"
                     style="width:100%;padding:6px;background:#0f0f1a;border:1px solid #2a2a4a;border-radius:4px;color:#fff;font-family:ui-monospace,Menlo,monospace;">
            </label>
          </div>
        `}
        <div style="display: flex; gap: 8px; justify-content: flex-end;">
          <button id="vd-cancel"
                  style="padding:7px 14px;background:#252545;border:none;border-radius:6px;color:#ccc;cursor:pointer;font-weight:600;">Cancel</button>
          <button id="vd-go"
                  style="padding:7px 14px;background:#e94560;border:none;border-radius:6px;color:#fff;cursor:pointer;font-weight:600;">Start recording</button>
        </div>
      `;

      overlay.appendChild(modal);
      document.body.appendChild(overlay);

      modal.querySelector("#vd-cancel").addEventListener("click", () => {
        overlay.remove();
        resolve(null);
      });

      modal.querySelector("#vd-go").addEventListener("click", () => {
        let start = null;
        let end = null;
        if (!isLive) {
          start = parseSeconds(modal.querySelector("#vd-start").value);
          end = parseSeconds(modal.querySelector("#vd-end").value);
          if (start == null || end == null || end <= start) {
            start = null;
            end = null;
          }
        }
        overlay.remove();
        resolve({ start, end });
      });

      overlay.addEventListener("click", (e) => {
        if (e.target === overlay) {
          overlay.remove();
          resolve(null);
        }
      });
    });
  }

  function postStatus(payload) {
    window.postMessage({ type: "VIDOWN_RECORD_STATUS", ...payload }, "*");
  }

  function fail(err) {
    postStatus({ status: "error", error: err });
    window.__VIDOWN_RECORDER_ACTIVE = false;
  }

  async function startRecorder(video, trim) {
    let stream;
    try {
      if (typeof video.captureStream === "function") {
        stream = video.captureStream();
      } else if (typeof video.mozCaptureStream === "function") {
        stream = video.mozCaptureStream();
      } else {
        throw new Error("captureStream not supported");
      }
    } catch (e) {
      return fail(e.message || String(e));
    }

    const mimeCandidates = [
      "video/webm;codecs=vp9,opus",
      "video/webm;codecs=vp8,opus",
      "video/webm",
      "video/mp4",
    ];
    let mimeType = "";
    for (const m of mimeCandidates) {
      if (MediaRecorder.isTypeSupported(m)) { mimeType = m; break; }
    }

    const chunks = [];
    let recorder;
    try {
      recorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);
    } catch (e) {
      return fail("MediaRecorder: " + (e.message || String(e)));
    }

    recorder.ondataavailable = (ev) => {
      if (ev.data && ev.data.size > 0) {
        chunks.push(ev.data);
        postStatus({
          status: "chunk",
          bytes: ev.data.size,
          total: chunks.reduce((a, c) => a + c.size, 0),
        });
      }
    };

    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: mimeType || "video/webm" });
      const url = URL.createObjectURL(blob);
      const ext = mimeType.includes("mp4") ? "mp4" : "webm";
      postStatus({ status: "done", url, size: blob.size, ext });
      window.__VIDOWN_RECORDER_ACTIVE = false;
      cleanupOverlay();
    };

    recorder.onerror = (e) => fail(e.error?.message || "Recorder error");

    // Trim: seek to start, watch for end.
    if (trim && Number.isFinite(trim.start)) {
      try { video.currentTime = trim.start; } catch (_) {}
      if (video.paused) { video.play().catch(() => {}); }
    }

    let endWatcher = null;
    if (trim && Number.isFinite(trim.end)) {
      endWatcher = () => {
        if (video.currentTime >= trim.end) {
          try { recorder.stop(); } catch (_) {}
          video.removeEventListener("timeupdate", endWatcher);
        }
      };
      video.addEventListener("timeupdate", endWatcher);
    }

    window.addEventListener("vidown-stop-record", () => {
      try { recorder.stop(); } catch (_) {}
      if (endWatcher) video.removeEventListener("timeupdate", endWatcher);
    }, { once: true });

    // Optional speed-up during recording (FetchV-style faster capture).
    if (Number.isFinite(userOpts.playbackRate) && userOpts.playbackRate > 1) {
      try { video.playbackRate = userOpts.playbackRate; } catch (_) {}
    }

    recorder.start(1000);
    postStatus({ status: "started", mimeType: mimeType || "auto", trim: trim || null });
  }

  let activeOverlay = null;
  function cleanupOverlay() {
    if (activeOverlay) {
      activeOverlay.remove();
      activeOverlay = null;
    }
  }

  (async () => {
    const video = pickLargestVideo();
    if (!video) {
      return fail("No <video> element found");
    }

    let trim = null;
    if (wantsTrim) {
      trim = await createTrimModal(video);
      if (!trim) {
        window.__VIDOWN_RECORDER_ACTIVE = false;
        postStatus({ status: "cancelled" });
        return;
      }
    }

    startRecorder(video, trim);
  })();
})();
